package com.ibm.urbancode.zos.common
/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

class PackageManifestXMLHelper {
	def fXmlParser;
	
	public PackageManifestXMLHelper() {
		fXmlParser = new XmlParser();
	}

	def getAllDeployDatasets(manifestFilePath) {
		def manifestFile = new File(manifestFilePath);
		if(!manifestFile.exists()){
			throw new IllegalArgumentException("${manifestFilePath} not found. Please make sure a Copy or FTP plug-in step is successfully executed before the Deploy plug-in step.");
		}
		
		def manifest = fXmlParser.parse(manifestFile);
		def resources = manifest.container;
		if(!resources || resources.size() < 1){
			throw new IllegalArgumentException("There is no datasets to deploy for this version");
		}
		
		def res = resources."@name";
		res = res*.trim();
		
		return res; 
	}
	
}
