#!/bin/sh
##############################################################################
##                                                                          ##
##  JVM Launcher for zOS                                                    ##
##                                                                          ##
##############################################################################
export LIBPATH=$LIBPATH:$1
echo "LIBPATH: $LIBPATH"
echo "$JAVA_HOME"/bin/java $JAVA_OPTS $ZOS_JAVA_OPTS "$2" "$3" "$4" "$5" "$6"
exec "$JAVA_HOME"/bin/java $JAVA_OPTS $ZOS_JAVA_OPTS "$2" "$3" "$4" "$5" "$6"