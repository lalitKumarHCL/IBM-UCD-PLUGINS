import groovy.text.GStringTemplateEngine

def file = "agent.install.properties.template";
println "[IBM UCD]: using properties template at " + file;

def outfile = "agent.install.properties";
println "[IBM UCD]: creating file at " + outfile;


try {
  def f = new File(file)
  def binding = ["agent_name":args[0], "hostname":args[1], "port":args[2] ]
  def engine = new GStringTemplateEngine()
  def template = engine.createTemplate(f).make(binding)
  def contents = template.toString()
  def out = new File(outfile)
  out.write(contents);

}
catch (Exception e) {
    println "Error deploying!";
    e.printStackTrace();
    System.exit(1);
}
