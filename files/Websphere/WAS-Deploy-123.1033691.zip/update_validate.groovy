/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2002-2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/
if(contentType.equals("app")) {
    if(!operation.equals("update")) {
        errors.operation = "Operation must be update when Content Type is Application!";
        errors.contentType = "Operation must be update when Content Type is Application!";
    }
    if(contentsuri) {
        errors.contentsuri = "Content URI must be empty when either Application or Partial Application is set for Content Type";
    }
} else if(contentType.equals("file")) {
    if(!contentsuri) {
        errors.contentsuri = "Content URI can not be empty when either File or Module File is set for Content Type";
    }
} else if(contentType.equals("modulefile")) {
    if(!contentsuri) {
        errors.contentsuri = "Content URI can not be empty when either File or Module File is set for Content Type";
    }
} else if(contentType.equals("partialapp")) {
    if(!operation.equals("update")) {
        errors.operation = "Operation must be update when Content Type is Partial Application!";
        errors.contentType = "Operation must be update when Content Type is Partial Application!";
    }
    if(contentsuri) {
        errors.contentsuri = "Content URI must be empty when either Application or Partial Application is set for Content Type";
    }
}
