/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2002-2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/

import com.urbancode.air.AirPluginTool;
import com.urbancode.air.plugin.websphere.WebSphereBatchScriptHelper

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();
def appName = props['appName'];
def contentType = props['contentType'];
def operation = props['operation'];
def contents = props['contents'];
def contentsuri = props['contentsuri'];
def argString = props['argString'];
def appEdition = props['appEdition']

StringBuilder builder = new StringBuilder();
builder.append("updateApplication(")
           .append("\"").append(appName).append("\"").append(",")
           .append("\"").append(appEdition?:"").append("\"").append(",")
           .append("\"").append(operation).append("\"").append(",")
           .append("\"").append(contentType).append("\"").append(",")
           .append("\"").append(contentsuri).append("\"").append(",")
           .append("\"").append(contents).append("\"").append(",")
           .append("\"\"").append(",")
           .append("\'").append(argString?:"").append("\'")
       .append(")")
command = builder.toString();

WebSphereBatchScriptHelper helper = new WebSphereBatchScriptHelper(props);
helper.execute(command);
