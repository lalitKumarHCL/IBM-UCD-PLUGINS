"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: useWVEBB.py
"""


disableHAM=0
enableHAM=0
enableNEWBB=1

def convertToList(inlist):
     outlist=[]
     if (len(inlist)>0 and inlist[0]=='[' and inlist[len(inlist)-1]==']'):
        inlist = inlist[1:len(inlist)-1]
        clist = inlist.split(" ")
     else:
        clist = inlist.split("\n")
     for elem in clist:
        elem=elem.rstrip();
        if (len(elem)>0):
           outlist.append(elem)
     return outlist


def doDisableHAM(servers):
   for server in servers:
       hamserver=AdminConfig.list("HAManagerService",server)
       if (hamserver != "" and hamserver != None):
          AdminConfig.modify(hamserver,[["enable","false"]])

def doEnableHAM(servers):
   for server in servers:
       hamserver=AdminConfig.list("HAManagerService",server)
       if (hamserver != "" and hamserver != None):
           AdminConfig.modify(hamserver,[["enable","true"]])


if (len(sys.argv)>0):
   if sys.argv[0] == "-disableHAM":
      disableHAM=1
   elif sys.argv[0] == "-enableHAM":
      enableHAM=1
   elif sys.argv[0] == "-useHAMBB":
      enableHAM=1
      enableNEWBB=0
   elif sys.argv[0] == "-mode":
		pass
   else:
      raise "unrecognized option: ",sys.argv[0]

cell = AdminConfig.getid("/Cell:/")
properties = convertToList(AdminConfig.showAttribute(cell,"properties"))
for property in properties:
     name = AdminConfig.showAttribute(property,"name")
     value = AdminConfig.showAttribute(property,"value")
     if (name == "WXDBulletinBoardProviderOption"):
         AdminConfig.remove(property)
if (enableNEWBB):
   AdminConfig.create("Property",cell,[["name","WXDBulletinBoardProviderOption"],["value","WXD"]])

if disableHAM>0:
   print "disabling hamanager on specified servers"
   servers=convertToList(AdminConfig.list("Server"))
   doDisableHAM(servers)
   servers=convertToList(AdminConfig.listTemplates("Server"))
   doDisableHAM(servers)

if enableHAM>0:
   print "enabling hamanager on all servers"
   servers=convertToList(AdminConfig.list("Server"))
   doEnableHAM(servers)
   servers=convertToList(AdminConfig.listTemplates("Server"))
   doEnableHAM(servers)

AdminConfig.save()
print "finished."
