"""
"""
class DynclusterTasks:
	
	def __init__(self):
		self.LOGGER = _Logger("DynclusterTasks", MessageManager.RB_WEBSPHERE_WVE)
	#endDef
		
	def createDynamicCluster(self, dynclusterName, clusterProperties, wveCommonProperties):
		print "Creating dynamic cluster: " + dynclusterName
		cellName = AdminControl.getCell()
		dynclusterId = AdminConfig.getid('/Cell:' + cellName + '/DynamicCluster:' + dynclusterName + '/')
		if (len(dynclusterId) == 0):
			membershipPolicy = clusterProperties['MEMBERSHIP_POLICY']
			if membershipPolicy == '':
				membershipPolicy = wveCommonProperties['DEFAULT_MEMBERSHIP_POLICY']
			AdminTask.createDynamicCluster(dynclusterName, ['-membershipPolicy', membershipPolicy])
		else:
			self.LOGGER.info('Dynamic cluster ' + dynclusterName + ' already exists...')
	#endDef
		
	def deleteDynamicCluster(self, dynclusterName):
		opMode = AdminTask.getDynamicClusterOperationalMode(dynclusterName)
		if opMode != 'manual':
			print 'Setting dynamic cluster ' + dynclusterName + ' operational mode to manual before deleting' 
			AdminTask.setDynamicClusterOperationalMode(dynclusterName, ['-operationalMode', 'manual'])			
			AdminHelper.saveAndSyncCell()
		print 'Deleting dynamic cluster: ' + dynclusterName
		AdminTask.deleteDynamicCluster(dynclusterName)
	#endDef
	
	def setDynamicClusterOperationalMode(self, dynclusterName,  clusterProperties, wveCommonProperties):
		operationalMode = wveCommonProperties['DYNAMIC_CLUSTER_OPERATIONAL_MODE']		
		if operationalMode == '':
			operationalMode = 'manual'
		print 'Setting operational mode as ' + operationalMode + ' for dynamic cluster: ' + dynclusterName
		AdminTask.setDynamicClusterOperationalMode(dynclusterName, ['-operationalMode', operationalMode])
	#endDef
#endDef

#####################################################################################
# MAIN
#####################################################################################

print "sys.argv = %s " % sys.argv
optDict, args = SystemUtils.getopt(sys.argv, 'action:;dynclusterName:;clusterProperties:;wveCommonProperties:;mode:')

mode = optDict['mode']
action = optDict['action']
dynclusterName = optDict['dynclusterName']

dynclusterTasks = DynclusterTasks()

if (mode == MODE_EXECUTE):
	if action == 'createCluster':
		clusterProperties = SystemUtils.getPropertyDict( optDict['clusterProperties'] )
		wveCommonProperties = SystemUtils.getPropertyDict( optDict['wveCommonProperties'] )
		dynclusterTasks.createDynamicCluster(dynclusterName, clusterProperties, wveCommonProperties)
	elif action == 'deleteCluster':
		dynclusterTasks.deleteDynamicCluster(dynclusterName)
	elif action == 'setOperationalMode':
		clusterProperties = SystemUtils.getPropertyDict( optDict['clusterProperties'] )
		wveCommonProperties = SystemUtils.getPropertyDict( optDict['wveCommonProperties'] )
		dynclusterTasks.setDynamicClusterOperationalMode(dynclusterName, clusterProperties, wveCommonProperties)
	else:
		raise "Unsupported action supplied: " + action
	AdminHelper.saveAndSyncCell()

else:
	raise "Unsupported MODE supplied: " + mode
#endIf
