--
-- Licensed Materials - Property of IBM
-- 5655-FLW (C) Copyright IBM Corporation 2006,2008.
-- All Rights Reserved.
-- US Government Users Restricted Rights- 
-- Use, duplication or disclosure restricted 
-- by GSA ADP Schedule Contract with IBM Corp.
--
-- Scriptfile to create tablespaces for DB2 UDB
-- Replace occurence or @location@ in this file with the location
-- where you want the tablespace containers to be stored, then run:
--      db2 connect to OBSVRDB
--      db2 -tf createTablespace_Observer.sql


---------------------------------
-- Create 4 K page tablespaces --
---------------------------------

CREATE TABLESPACE OBSVRTS
  MANAGED BY SYSTEM
  USING( '@location@/OBSVRTS' );

--
--
--
