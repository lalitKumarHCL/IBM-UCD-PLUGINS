-- BEGIN COPYRIGHT
-- *************************************************************************
-- Licensed Materials - Property of IBM 
-- 5724-L01, 5655-N53, 5724-I82, 5655-R15
-- Copyright IBM Corporation 2007. All rights reserved. 
-- US Government Users Restricted Rights - Use, duplication, or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.
-- *************************************************************************
-- END COPYRIGHT


-- *******************************************
-- Schema change from 6.1.x
-- *******************************************


-- *******************************************
-- create table RELN_VIEW_META_T and indexes
-- *******************************************


CREATE TABLE RELN_VIEW_META_T ( VIEW_NAME VARCHAR(255) NOT NULL,
				RELATIONSHIP_NAME VARCHAR(255) NOT NULL,
				ROLE_NAME VARCHAR(255) NOT NULL,
				VERSION VARCHAR(10) NOT NULL);
										
CREATE UNIQUE INDEX RELN_VIEW_I ON RELN_VIEW_META_T (RELATIONSHIP_NAME, ROLE_NAME);