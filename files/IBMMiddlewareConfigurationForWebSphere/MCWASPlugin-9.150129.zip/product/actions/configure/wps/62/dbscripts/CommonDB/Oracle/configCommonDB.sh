#!/bin/sh
#
# BEGIN COPYRIGHT
# *************************************************************************
# Licensed Materials - Property of IBM 
# 5724-L01, 5655-N53, 5724-I82, 5655-R15
# (C) Copyright IBM Corporation 2006. All rights reserved. 
# US Government Users Restricted Rights - Use, duplication, or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.
# *************************************************************************
# END COPYRIGHT
#------------------------------------------------------------------------------------------------------------------------------------------------------------
# Description:   Configure Oracle Database environment for CommonDB in occasion of Setup a new or existing database separately
#
# This file for use on Linux/Unix systems's bash
#------------------------------------------------------------------------------------------------------------------------------------------------------------

ls | egrep "[create][insert]Table_" | sed s/^/\@/ > files.sql
echo quit >> files.sql

sqlplus #DB_USER#@#DB_NAME# @files.sql

rm -f  files.sql