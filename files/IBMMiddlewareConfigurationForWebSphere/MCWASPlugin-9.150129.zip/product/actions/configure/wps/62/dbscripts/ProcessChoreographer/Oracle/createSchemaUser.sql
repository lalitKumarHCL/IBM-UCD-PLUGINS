--
-- Licensed Materials - Property of IBM
-- 5655-FLW (C) Copyright IBM Corporation 2008.
-- All Rights Reserved.
-- US Government Users Restricted Rights-
-- Use, duplication or disclosure restricted
-- by GSA ADP Schedule Contract with IBM Corp.
--
-- Scriptfile to create user for Oracle 9i, Oracle 10g, and Oracle 11g
-- Process this script using SQL*Plus
----------------------------------------------------------------------
-- The following variable needs to be changed for customization and
-- before running this script.
-- @SCHEMA@ = User name
-- @PASSWORD@ = Password
----------------------------------------------------------------------
-- Example: sqlplus scott/tiger@mydb @createSchemaUser.sql
-- or, at the sqlplus prompt, enter
-- SQL> @createUser.sql

CREATE USER @SCHEMA@ IDENTIFIED BY @PASSWORD@;
GRANT CONNECT, RESOURCE, UNLIMITED TABLESPACE TO @SCHEMA@;
GRANT JAVAUSERPRIV TO @SCHEMA@;
