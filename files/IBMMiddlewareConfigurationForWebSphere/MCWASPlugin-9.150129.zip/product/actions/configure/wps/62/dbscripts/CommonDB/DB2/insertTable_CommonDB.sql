-- BEGIN COPYRIGHT
-- *************************************************************************
-- Licensed Materials - Property of IBM 
-- 5724-L01, 5655-N53, 5724-I82, 5655-R15
-- (C) Copyright IBM Corporation 2004, 2006. All rights reserved. 
-- US Government Users Restricted Rights - Use, duplication, or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.
-- *************************************************************************
-- END COPYRIGHT

-- *******************************************
-- Populate data into SCHEMAVERSIONINFO
-- *******************************************

INSERT INTO SchemaVersionInfo VALUES ('recovery.ejb', #MajorVersion#, #MinorVersion#, #RefreshPackLevel#, #FixpackLevel#, 0);

INSERT INTO SchemaVersionInfo VALUES ('interfaceMediation', #MajorVersion#, #MinorVersion#, #RefreshPackLevel#, #FixpackLevel#, 0);

INSERT INTO SchemaVersionInfo VALUES ('relationshipService', #MajorVersion#, #MinorVersion#, #RefreshPackLevel#, #FixpackLevel#, 0);

INSERT INTO SchemaVersionInfo VALUES ('scheduler.wbi', #MajorVersion#, #MinorVersion#, #RefreshPackLevel#, #FixpackLevel#, 0);

INSERT INTO SchemaVersionInfo VALUES ('customization', #MajorVersion#, #MinorVersion#, #RefreshPackLevel#, #FixpackLevel#, 0);

INSERT INTO SchemaVersionInfo VALUES ('persistentlockmanager', #MajorVersion#, #MinorVersion#, #RefreshPackLevel#, #FixpackLevel#, 0);

INSERT INTO SchemaVersionInfo VALUES ('governance', #MajorVersion#, #MinorVersion#, #RefreshPackLevel#, #FixpackLevel#, 0);

INSERT INTO SchemaVersionInfo VALUES ('DirectDeploy', #MajorVersion#, #MinorVersion#, #RefreshPackLevel#, #FixpackLevel#, 0);

INSERT INTO SchemaVersionInfo VALUES ('WPS', #MajorVersion#, #MinorVersion#, #RefreshPackLevel#, #FixpackLevel#, 0);
