-- BEGIN COPYRIGHT
-- *************************************************************************
-- Licensed Materials - Property of IBM 
-- 5724-L01, 5655-N53, 5724-I82, 5655-R15
-- (C) Copyright IBM Corporation 2004, 2006, 2008. All rights reserved. 
-- US Government Users Restricted Rights - Use, duplication, or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.
-- *************************************************************************
-- END COPYRIGHT


-- *******************************************
-- create Oracle schema or user for WPS/WESB
-- *******************************************

-- Substitute correct password[DBPASS] value for the User[DBUSER]  used  during profile creation. 
-- Script must be run by SYSDBA privilaged user.

-- example: sqlplus scott/tiger@mydb @createSchema.sql
-- or, at the sqlplus prompt, enter
-- SQL> @createSchema.sql

CREATE USER @DBUSER@ IDENTIFIED BY @DBPASS@;
grant connect, resource, unlimited tablespace to @DBUSER@;
grant create view to @DBUSER@;
grant javauserpriv to @DBUSER@;

