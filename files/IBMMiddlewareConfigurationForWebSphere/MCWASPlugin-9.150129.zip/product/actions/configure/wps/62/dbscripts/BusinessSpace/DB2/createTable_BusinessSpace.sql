-- Licensed Materials - Property of IBM
-- 5724-M24
-- Copyright IBM Corporation 2007, 2009.  All Rights Reserved.
-- US Government Users Restricted Rights - Use, duplication or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.
-- -----------------------------------------------------------------------------
--
-- Script file to create tables for Business Space 6.2
--
-- Process this script in the DB2 command line processor
-- Example:
--    db2 connect to IBMBUSSP
--    db2 -tf createTable_BusinessSpace.sql
--

------------- bufferpool for regular tablespaces
CREATE BUFFERPOOL BP32K_BS IMMEDIATE SIZE 250 PAGESIZE 32 K;

------------- bufferpool for temp tablespace
CREATE BUFFERPOOL TMPBP32K_BS IMMEDIATE SIZE 250 PAGESIZE 32 K;

------------- tablespace for BSPACE (BS) 
CREATE REGULAR TABLESPACE BSPACE PAGESIZE 32 K  
MANAGED BY SYSTEM  USING ('@TSDIR@_BSPACE' ) 
EXTENTSIZE 8 OVERHEAD 10.5 PREFETCHSIZE 0 TRANSFERRATE 0.14 
BUFFERPOOL BP32K_BS DROPPED TABLE RECOVERY OFF;

------------- tablespace (temp) for sorts/joins
CREATE SYSTEM TEMPORARY TABLESPACE TMPTS32K_BS PAGESIZE 32 K  
MANAGED BY SYSTEM USING ('@TSDIR@_TMPTS32K_BS' ) 
EXTENTSIZE 8 OVERHEAD 10.5 PREFETCHSIZE 32 TRANSFERRATE 0.14 
BUFFERPOOL TMPBP32K_BS;


------------- tables

	CREATE TABLE @SCHEMA@.USER_DATA_T (
		  USER_ID                 VARCHAR(128) NOT NULL ,
		  USER_CONFIG             VARCHAR(4096) ,
		  IS_SUPER_USER           VARCHAR(1) ,
		  EXTENSION               BLOB(10K) ,
		  PRIMARY KEY ( USER_ID )
		) IN BSPACE;
	
	CREATE TABLE @SCHEMA@.SPACES (
		  ID                      VARCHAR(64) NOT NULL ,
		  NAME                    VARCHAR(128) NOT NULL ,
		  DESCRIPTION             VARCHAR(512) ,
		  OWNER                   VARCHAR(256) NOT NULL ,
		  USERS                   VARCHAR(4096) ,
		  EDITORS                 VARCHAR(4096) ,
		  THEMES                  VARCHAR(128) ,
		  ISLOCALIZED             VARCHAR(1) ,
		  TEMPLATE                VARCHAR(1) NOT NULL ,
		  EXTENSION               BLOB(10K) ,
		  PRIMARY KEY ( ID )
		) IN BSPACE ;
	
	CREATE TABLE @SCHEMA@.NLSINFO (
		  EXTENSION               BLOB(10K) ,
		  ID                      VARCHAR(64) NOT NULL ,
		  LOCALENAME              VARCHAR(64) NOT NULL ,
		  DESCRIPTION             VARCHAR(512) ,
		  NAME                    VARCHAR(128) NOT NULL ,
		  PRIMARY KEY ( ID, LOCALENAME )
		) IN BSPACE ;
	
	CREATE TABLE @SCHEMA@.PAGE (
		  ID                      VARCHAR(64) NOT NULL ,
		  SPACEID                 VARCHAR(64) NOT NULL ,
		  NAME                    VARCHAR(128) NOT NULL ,
		  DESCRIPTION             VARCHAR(512) ,
		  OWNER                   VARCHAR(256) NOT NULL ,
		  USERS                   VARCHAR(4096) ,
		  EDITORS                 VARCHAR(4096) ,
		  LAYOUT                  VARCHAR(128) ,
		  WIDGETS                 VARCHAR(4096) ,
		  ISLOCALIZED             VARCHAR(1) ,
		  RESTRICTED              VARCHAR(1) ,
		  TEMPLATE                VARCHAR(1) NOT NULL ,
		  EXTENSION               BLOB(10K) ,
		  PRIMARY KEY ( ID ) ,
		  FOREIGN KEY ( SPACEID )
			REFERENCES @SCHEMA@.SPACES ( ID )
			ON DELETE CASCADE
			ON UPDATE NO ACTION
		) IN BSPACE ;
	
	CREATE INDEX @SCHEMA@.I0000010 ON @SCHEMA@.PAGE ( OWNER ASC );
	CREATE INDEX @SCHEMA@.I0000011 ON @SCHEMA@.PAGE ( SPACEID ASC );
	
	CREATE TABLE @SCHEMA@.WIDGET (
		  ID                      VARCHAR(128) NOT NULL ,
		  NAME                    VARCHAR(128) ,
		  DEFINITIONID            VARCHAR(128) NOT NULL ,
		  STATE                   VARCHAR(32) ,
		  ISLOCALIZED             VARCHAR(1) ,
		  PREFERENCES             BLOB(1024K) ,
		  PRIMARY KEY ( ID )
		) IN BSPACE ;
	
	CREATE TABLE @SCHEMA@.REGISTERED_WIDGET (
		  EXTENSION               BLOB(10K) ,
		  ID_VERSION              VARCHAR(322) NOT NULL ,
		  ID                      VARCHAR(256) NOT NULL ,
		  VERSION                 VARCHAR(64) ,
		  TYPE                    VARCHAR(32) NOT NULL ,
		  NAME                    VARCHAR(256) ,
		  DESCRIPTION             VARCHAR(1024) ,
		  TOOLTIP                 VARCHAR(512) ,
		  HELP_URL                VARCHAR(512) ,
		  ICON_URL                VARCHAR(512) ,
		  PREVIEW_URL             VARCHAR(512) ,
		  PREVIEW_THUMBNAIL_URL   VARCHAR(512) ,
		  OWNER                   VARCHAR(256) ,
		  EMAIL                   VARCHAR(256) ,
		  SERVICE_ENDPOINTS       VARCHAR(4000) ,
		  WIDGET_ENDPOINT_ID      VARCHAR(389) ,
		  WIDGET_URL              VARCHAR(512) ,
		  VIEW_URL                VARCHAR(512) ,
		  EDIT_URL                VARCHAR(512) ,
		  ATTACHABLE              VARCHAR(8) ,
		  ATTACHMENT_URL          VARCHAR(512) ,
		  CATEGORY_ID             VARCHAR(256) NOT NULL ,
		  LAST_CHANGE             TIMESTAMP NOT NULL ,
		  PRIMARY KEY ( ID_VERSION )
		) IN BSPACE ;
	
	CREATE TABLE @SCHEMA@.REGISTERED_WIDGET_NLS (
		  EXTENSION               BLOB(10K) ,
		  ID_LOCALE               VARCHAR(356) NOT NULL ,
		  WIDGET_ID_VERSION       VARCHAR(322) ,
		  LOCALE                  VARCHAR(32) ,
		  NAME                    VARCHAR(256) ,
		  DESCRIPTION             VARCHAR(1024) ,
		  TOOLTIP                 VARCHAR(512) ,
		  HELP_URL                VARCHAR(512) ,
		  ICON_URL                VARCHAR(512) ,
		  PREVIEW_URL             VARCHAR(512) ,
		  PREVIEW_THUMBNAIL_URL   VARCHAR(512) ,
		  OWNER                   VARCHAR(256) ,
		  EMAIL                   VARCHAR(256) ,
		  PRIMARY KEY ( ID_LOCALE ) ,
		  FOREIGN KEY ( WIDGET_ID_VERSION )
			REFERENCES @SCHEMA@.REGISTERED_WIDGET ( ID_VERSION )
		    ON DELETE CASCADE
		) IN BSPACE ;
	
	CREATE TABLE @SCHEMA@.REGISTERED_CATEGORY (
		  EXTENSION               BLOB(10K) ,
		  ID                      VARCHAR(256) NOT NULL ,
		  ORDERING                SMALLINT ,
		  NAME                    VARCHAR(256) ,
		  DESCRIPTION             VARCHAR(1024) ,
		  TOOLTIP                 VARCHAR(512) ,
		  LAST_CHANGE             TIMESTAMP NOT NULL ,
		  PRIMARY KEY ( ID )
		) IN BSPACE ;
	
	CREATE TABLE @SCHEMA@.REGISTERED_CATEGORY_NLS (
		  EXTENSION               BLOB(10K) ,
		  ID_LOCALE               VARCHAR(290) NOT NULL ,
		  CATEGORY_ID             VARCHAR(256) NOT NULL ,
		  LOCALE                  VARCHAR(32) ,
		  NAME                    VARCHAR(256) ,
		  DESCRIPTION             VARCHAR(1024) ,
		  TOOLTIP                 VARCHAR(512) ,
		  PRIMARY KEY ( ID_LOCALE ) ,
		  FOREIGN KEY ( CATEGORY_ID )
			REFERENCES @SCHEMA@.REGISTERED_CATEGORY ( ID )
			ON DELETE CASCADE
		) IN BSPACE ;
	
	CREATE TABLE @SCHEMA@.REGISTERED_ENDPOINT (
		  EXTENSION               BLOB(10K) ,
		  ID_VERSION              VARCHAR(322) NOT NULL ,
		  ID                      VARCHAR(256) NOT NULL ,
		  TYPE                    VARCHAR(256) ,
		  VERSION                 VARCHAR(64) ,
		  URL                     VARCHAR(512) NOT NULL ,
		  NAME                    VARCHAR(256) ,
		  DESCRIPTION             VARCHAR(1024) ,
		  LAST_CHANGE             TIMESTAMP NOT NULL ,
		  PRIMARY KEY ( ID_VERSION )
		) IN BSPACE ;
	
	CREATE TABLE @SCHEMA@.REGISTERED_ENDPOINT_NLS (
		  EXTENSION               BLOB(10K) ,
		  ID_LOCALE               VARCHAR(356) NOT NULL ,
		  ENDPOINT_ID_VERSION     VARCHAR(322) NOT NULL ,
		  LOCALE                  VARCHAR(32) ,
		  NAME                    VARCHAR(256) ,
		  DESCRIPTION             VARCHAR(1024) ,
		  PRIMARY KEY ( ID_LOCALE ) ,
		  FOREIGN KEY ( ENDPOINT_ID_VERSION )
			REFERENCES @SCHEMA@.REGISTERED_ENDPOINT ( ID_VERSION )
			ON DELETE CASCADE
		) IN BSPACE ;
	
	CREATE TABLE @SCHEMA@.REGISTERED_WCCM_ENDPOINT (
		  EXTENSION               BLOB(10K) ,
		  ID_VERSION              VARCHAR(322) NOT NULL ,
		  LAST_CHANGE             VARCHAR(32) NOT NULL ,
		  PRIMARY KEY ( ID_VERSION )
		) IN BSPACE ;
	
	CREATE TABLE @SCHEMA@.REGISTRY_FILE (
		  EXTENSION               BLOB(10K) ,
		  FILEPATH_HOST           VARCHAR(770) NOT NULL ,
		  FILEPATH                VARCHAR(512) NOT NULL ,
		  FILE_TIMESTAMP          BIGINT NOT NULL ,
		  HOST_NAME               VARCHAR(256) NOT NULL ,
		  PRIMARY KEY ( FILEPATH_HOST )
		) IN BSPACE ;
