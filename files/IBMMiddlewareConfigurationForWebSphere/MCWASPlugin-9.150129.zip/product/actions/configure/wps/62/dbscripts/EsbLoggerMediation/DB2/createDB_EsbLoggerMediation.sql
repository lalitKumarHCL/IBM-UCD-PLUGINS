-- @start_restricted_prolog@
-- Licensed Materials - Property of IBM
-- 5724-I82 5724-L01 5655-N63 5655-R15
-- Copyright IBM Corporation 2004, 2006 All Rights Reserved.
-- US Government Users Restricted Rights- Use, duplication or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.
-- @end_restricted_prolog@
--
--
--
create database DB_NAME using codeset UTF-8 territory US;
--
                          