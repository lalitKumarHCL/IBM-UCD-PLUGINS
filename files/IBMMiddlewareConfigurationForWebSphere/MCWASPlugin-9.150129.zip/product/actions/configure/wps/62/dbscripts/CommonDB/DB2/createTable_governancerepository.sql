-----------------------------------------------
-- Licensed Materials - Property of IBM
--
-- 5724-R31, 5655-S30
--
-- (C) Copyright IBM Corp. 2006, 2008 All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
------------------------------------------------



-- ###############################################
-- WARNING
-- Do not perform any committable statements in this file
-- as they will be rolled back in the case where the user
-- drops the W_ tables and expects the system to bootstrap
-- the tables again but did not drop the sequences.  When
-- the CREATE SEQUENCE statements fail, the transation will
-- be rolled back along with any committable work.
-----------------------------------------------------------
----Create tables ,primary keys & indexes for  triplestore
-------------------------------------------------------------
 
CREATE TABLE w_lit_bool (
    id INTEGER NOT NULL, 
	litval SMALLINT )   
 IN USERSPACE1; 

ALTER TABLE w_lit_bool ADD PRIMARY KEY (id);

CREATE INDEX idx_obj_bool ON w_lit_bool (litval);

CREATE TABLE w_lit_double (
    id INTEGER NOT NULL, 
    litval DOUBLE )   
 IN USERSPACE1; 

ALTER TABLE w_lit_double ADD PRIMARY KEY (id);

CREATE INDEX idx_obj_dbl ON w_lit_double (litval);

CREATE TABLE w_lit_float (
    id INTEGER NOT NULL, 
    litval REAL )  
 IN USERSPACE1; 

ALTER TABLE w_lit_float ADD PRIMARY KEY (id);

CREATE INDEX idx_obj_flt ON w_lit_float (litval);

CREATE TABLE w_lit_int (
    id INTEGER NOT NULL, 
    litval INTEGER )  
 IN USERSPACE1; 


ALTER TABLE w_lit_int ADD PRIMARY KEY (id);

CREATE INDEX idx_obj_int ON w_lit_int (litval);


CREATE TABLE w_lit_long (
    id INTEGER NOT NULL, 
    litval BIGINT )  
 IN USERSPACE1; 

ALTER TABLE w_lit_long ADD PRIMARY KEY (id);

CREATE INDEX idx_obj_long ON w_lit_long (litval);


CREATE TABLE w_obj_lit_any (
    id INTEGER NOT NULL, 
    large LONG VARCHAR FOR BIT DATA, 
    hash VARCHAR(40), 
    type_uri VARCHAR(254) NOT NULL )  
 IN USERSPACE1; 

ALTER TABLE w_obj_lit_any ADD PRIMARY KEY (id);

CREATE INDEX idx_obj_any ON w_obj_lit_any (type_uri);


CREATE TABLE w_obj_lit_date (
    id INTEGER NOT NULL, 
    litval TIMESTAMP )  
 IN USERSPACE1; 

ALTER TABLE w_obj_lit_date ADD PRIMARY KEY (id);

CREATE INDEX idx_obj_date ON w_obj_lit_date (litval);


CREATE TABLE w_obj_lit_datetime (
    id INTEGER NOT NULL, 
    litval TIMESTAMP )  
 IN USERSPACE1; 


ALTER TABLE w_obj_lit_datetime ADD PRIMARY KEY (id);

CREATE INDEX idx_obj_time ON w_obj_lit_datetime (litval);


CREATE TABLE w_obj_lit_string (
    id INTEGER NOT NULL, 
    large LONG VARCHAR FOR BIT DATA, 
    litval VARCHAR(1024), 
    hash VARCHAR(40) )  
 IN USERSPACE1; 

ALTER TABLE w_obj_lit_string ADD PRIMARY KEY (id);

CREATE INDEX idx_obj_str ON w_obj_lit_string (hash);


CREATE TABLE w_obj_lit_plain (
    id INTEGER NOT NULL,
    large LONG VARCHAR FOR BIT DATA,
    litval VARCHAR(1024),
    hash VARCHAR(40),
    xml_lang VARCHAR(64) )
 IN USERSPACE1;

ALTER TABLE w_obj_lit_plain ADD PRIMARY KEY (id);

CREATE INDEX idx_obj_plain ON w_obj_lit_plain (hash);


CREATE TABLE w_namespace (
    id INTEGER NOT NULL, 
    namespace VARCHAR(254) NOT NULL )  
 IN USERSPACE1; 

ALTER TABLE w_namespace ADD PRIMARY KEY (id);

CREATE UNIQUE INDEX idx_namespace ON w_namespace (namespace ASC);


CREATE TABLE w_uri (
    id INTEGER NOT NULL, 
    uri VARCHAR(254) NOT NULL, 
    namespace_id INTEGER NOT NULL )  
 IN USERSPACE1; 

ALTER TABLE w_uri ADD PRIMARY KEY (id);

CREATE UNIQUE INDEX idx_uri ON w_uri (uri ASC);
CREATE UNIQUE INDEX idx_uri_by_ns ON w_uri (namespace_id, id);


CREATE TABLE w_statement (
    id INTEGER NOT NULL, 
    version_from INTEGER NOT NULL, 
    version_to INTEGER NOT NULL, 
    subj_id INTEGER NOT NULL, 
    pred_id INTEGER NOT NULL, 
    obj_id INTEGER NOT NULL, 
    obj_typ_cd INTEGER NOT NULL,
    partition_id INTEGER NOT NULL)  
 IN USERSPACE1; 

ALTER TABLE w_statement ADD PRIMARY KEY (id);

CREATE INDEX idx_smt_by_sbj ON w_statement (subj_id, version_from, version_to);
CREATE INDEX idx_smt_by_fvr ON w_statement (version_from);
CREATE INDEX idx_sbj_by_prp ON w_statement (pred_id, obj_id);
CREATE INDEX idx_smt_by_val ON w_statement (obj_id, subj_id);
CREATE INDEX idx_val_by_prp ON w_statement (subj_id, pred_id);


CREATE TABLE w_version (
    username VARCHAR(64) NOT NULL, 
    change_time TIMESTAMP NOT NULL, 
    cl_gid VARCHAR(36), 
    cl_lid VARCHAR(10), 
    schema_ns_id INTEGER, 
    schema_rev INTEGER, 
    id INTEGER NOT NULL,
    partition_id INTEGER NOT NULL )  
 IN USERSPACE1; 

ALTER TABLE w_version ADD PRIMARY KEY (id, partition_id);

CREATE INDEX idx_ver_schema ON w_version (schema_ns_id);

CREATE TABLE w_artifact_blob (
 id VARCHAR(254) NOT NULL, 
 content BLOB(1G), 
 deleted SMALLINT,
 PRIMARY KEY(id))
IN USERSPACE1; 
		
---------------------------------------------------------------------------------
-----Create Foreign keys on trplestore tables
---------------------------------------------------------------------------------

ALTER TABLE w_uri 
	ADD CONSTRAINT w_uri_fk_namesp FOREIGN KEY
		(namespace_id)
	REFERENCES w_namespace
		(id)
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	ENFORCED
	ENABLE QUERY OPTIMIZATION;


ALTER TABLE w_version 
	ADD CONSTRAINT w_ver_fk_namesp FOREIGN KEY
		(schema_ns_id)
	REFERENCES w_namespace
		(id)
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	ENFORCED
	ENABLE QUERY OPTIMIZATION;

-- The CREATE SEQUENCE statements are at the bottom here so that
-- developers can drop their tables and have them recreated on restart
-- without having to drop sequences also. This is because the DB2
-- Control Center does not provide a way to drop sequences.


CREATE SEQUENCE seq_w_lit_bool_id 
AS INTEGER START WITH 0 INCREMENT BY 1
NO MAXVALUE MINVALUE 1
NO CYCLE CACHE 20 ORDER;

CREATE SEQUENCE seq_w_lit_double_id 
 AS INTEGER START WITH 0 INCREMENT BY 1
 NO MAXVALUE MINVALUE 1
NO CYCLE CACHE 20 ORDER;

CREATE SEQUENCE seq_w_lit_float_id 
AS INTEGER START WITH 0 INCREMENT BY 1
 NO MAXVALUE MINVALUE 1
NO CYCLE CACHE 20 ORDER;

CREATE SEQUENCE seq_w_lit_int_id 
AS INTEGER START WITH 0 INCREMENT BY 1
NO MAXVALUE MINVALUE 1
NO CYCLE CACHE 20 ORDER;

CREATE SEQUENCE seq_w_lit_long_id 
AS INTEGER START WITH 0 INCREMENT BY 1
NO MAXVALUE MINVALUE 1
NO CYCLE CACHE 20 ORDER;

CREATE SEQUENCE seq_w_namespace_id
AS INTEGER START WITH 0 INCREMENT BY 1
NO MAXVALUE MINVALUE 1
NO CYCLE CACHE 20 ORDER;

CREATE SEQUENCE seq_w_obj_lit_any_id 
AS INTEGER START WITH 0 INCREMENT BY 1
NO MAXVALUE MINVALUE 1
NO CYCLE CACHE 20 ORDER;

CREATE SEQUENCE seq_w_obj_lit_date_id 
AS INTEGER START WITH 0 INCREMENT BY 1
NO MAXVALUE MINVALUE 1
NO CYCLE CACHE 20 ORDER;

CREATE SEQUENCE seq_w_obj_lit_datetime_id 
AS INTEGER START WITH 0 INCREMENT BY 1
NO MAXVALUE MINVALUE 1
NO CYCLE CACHE 20 ORDER;

CREATE SEQUENCE seq_w_obj_lit_plain_id 
AS INTEGER START WITH 0 INCREMENT BY 1
NO MAXVALUE MINVALUE 1
NO CYCLE CACHE 20 ORDER;

CREATE SEQUENCE seq_w_obj_lit_string_id 
AS INTEGER START WITH 0 INCREMENT BY 1
NO MAXVALUE MINVALUE 1
NO CYCLE CACHE 20 ORDER;

CREATE SEQUENCE seq_w_statement_id 
AS INTEGER START WITH 0 INCREMENT BY 1
NO MAXVALUE MINVALUE 1
NO CYCLE CACHE 20 ORDER;

CREATE SEQUENCE seq_w_uri_id 
AS INTEGER START WITH 0 INCREMENT BY 1
NO MAXVALUE MINVALUE 1
NO CYCLE CACHE 20 ORDER;

CREATE TABLE w_dbversion (
    subsystem VARCHAR(8) NOT NULL, 
    cur_version INTEGER NOT NULL )  
 IN USERSPACE1;

ALTER TABLE w_dbversion ADD PRIMARY KEY (subsystem);
