"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: coreGroupBridges.py
	
	This script creates core group bridge configuration
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java

from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from ConfigWriter import ConfigWriterException 
from ConfigWriter import ConfigWriter
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
from ConfigMediator import ConfigMediator

class CGBMediator:
	def createConfig(self, scope, scopeType, xmlFile, typeNames, excludedTypes, marker):
		scopeid = AdminConfig.getid(scope)
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
	
		if (len(scopeid) == 0):
			print "ERROR: unable to find parent scope: " + scopeid
			print "Cannot write WAS config. Returning without doing anything"
			return
		#endIf
		
		myConfigWriter = ConfigWriter()
		for typeName in typeNames:
			myConfigWriter.removeExistingConfig(scopeType, typeName, scopeid)
			nodeArray = xmlProp.getFilteredNodeArray(typeName)	
			for xmlNode in nodeArray:
				myConfigWriter.createWASObject(xmlNode, scopeid, excludedTypes)
				myConfigWriter.updateWASReferenceAttributes([xmlNode], xmlNode.getConfigId(), [])
			#endFor
		#endFor	
	#endDef
#endClass

'''
This is the function that is used by quick export to push the configuration data back to WAS
'''
def export(optDict=None):
	scope = optDict['wasscopetype']#AdminHelper.buildScope( optDict )
	
	propFile = optDict['properties'] 
	scopeType=optDict['scope']
	mode = optDict['mode']
	excludeTypes = optDict['excludedtypes']
	typeNames = [optDict['type']]
	marker = optDict['marker']
	
	thisMediator = CGBMediator()
	SCRIPT_LOGGER = _Logger("coreGroupBridgeSettings", MessageManager.RB_WEBSPHERE_WAS)
	thisMediator.createConfig(scope, scopeType, propFile, typeNames, excludeTypes, marker)
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'scope:;properties:;nodename:;scopename:;mode:' )
	
	# get scope
	scope = AdminHelper.buildScope( optDict )
	
	propFile = optDict['properties'] 
	scopeType=optDict['scope']
	
	mode = optDict['mode']
	excludeTypes = []
	typeNames = ["CoreGroupBridgeSettings"]
	marker = 'coreGroupBridges'
	
	thisMediator = CGBMediator()
	SCRIPT_LOGGER = _Logger("coreGroupBridgeSettings", MessageManager.RB_WEBSPHERE_WAS)
	if (mode == MODE_EXECUTE):
		print "Creating CoreGroupBridgeSettings in scope: " + scope
		thisMediator.createConfig(scope, scopeType, propFile, typeNames, excludeTypes, marker)
		AdminHelper.saveAndSyncCell()
	elif (mode == MODE_IMPORT):
		print "Importing CoreGroupBridgeSettings in scope: " + scope
		ConfigMediator.importConfig(scope, scopeType, propFile, marker, typeNames, excludeTypes)
	elif (mode == MODE_COMPARE):
		print "Comparing CoreGroupBridgeSettings in scope: " + scope
		ConfigMediator.compareConfig(scope, scopeType, propFile, marker, typeNames, excludeTypes)
	else:
		print "Unsupported MODE supplied: " + mode
	#endIf
#endIf