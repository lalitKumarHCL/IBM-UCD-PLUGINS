"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: deleteCluster.py
	
	This script deletes a cluster with the specified name
"""

import sys

"""
-----------------------------------------------------------------

"""

def deleteCluster (clusterName):
	
	if (len(clusterName) == 0 ):
		raise "Error: deleteCluster was not passed a cluster name. Exiting."
	
	print "Deleting cluster " + str(clusterName)
	#---------------------------------------------------------
	# We assume that there is only one cell, and we are on it
	#---------------------------------------------------------
	cellname = AdminControl.getCell()
		
	clusterid = AdminConfig.getid("/Cell:"+cellname+"/ServerCluster:"+clusterName+"/")		
	
	if str(clusterid) == "":
		print "Error: Cluster not found in WAS Config"
	  	raise ("The cluster " + clusterName + " could not be found in the WebSphere configuration. "
	  		+ "The cluster cannot be deleted. Please verify that the cluster exists.")
	#Delete the cluster
	AdminConfig.remove(clusterid)
	
#endDef
	
#-----------------------------------------------------------------
# Main
#-----------------------------------------------------------------
clusterLogger = _Logger("deleteCluster", MessageManager.RB_WEBSPHERE_WAS)

# relies on extra properties
##  -cellProperties configure.properties in CELL scope
##  -properties configure.properties in cluster scope for the new cluster
optDict, args = SystemUtils.getopt( sys.argv, 'scope:;properties:;nodename:;scopename:;mode:;cellProperties:' )

propFile=optDict['properties']
cellFile=optDict['cellProperties']

cellProps = SystemUtils.getPropertyDict(cellFile)
properties = SystemUtils.getPropertyDict(propFile)

clusterName = str(properties["CLUSTER_NAME"])

deleteCluster(clusterName)

# save the config
AdminHelper.saveAndSyncCell()


