"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: WAS40DataSources.py
	
	This script is used to create WAS40 JDBC Datasources...
"""


import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java

from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from ConfigWriter import ConfigWriterException 
from ConfigWriter import ConfigWriter
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

from ConfigValidator import ConfigValidator
from XmlProperty import InvalidXmlConfigException
import Globals

WAS40DataSourcesLogger = _Logger("WAS40DataSources", MessageManager.RB_WEBSPHERE_WAS)

class dsMediator:
	def createConfig(self, scope, scopeType, xmlFile, marker):
	
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
	
		scopeId = AdminConfig.getid( scope )
		typeName = "WAS40DataSource"
		
		myConfigWriter = ConfigWriter();
		myConfigWriter.removeExistingConfig(scopeType, typeName, scopeId)
	
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		for xmlNode in nodeArray:
			try:
				parentId = AdminHelper.findProviderId(xmlNode, scope, "JDBCProvider", "name")
				myConfigWriter.createWASObject(xmlNode, parentId, ["JDBCProvider", "builtin"])
			except InvalidXmlConfigException, e:
				jndiNameDisplay = xmlNode.getAttrValue("jndiName", Globals.ATTRIBUTE_VALUE_MISSING)
				##print "Error: JDBC Provider associated with this datasource has not been created.  "
				WAS40DataSourcesLogger.log("CRWSE1684E")
				##print "Check to ensure that required JDBCProviders have been created."
				WAS40DataSourcesLogger.log("CRWSE1685I")
				##print "       Unable to create JDBC Datasource with jndiName: " + jndiNameDisplay
				WAS40DataSourcesLogger.log("CRWSE1686I",[jndiNameDisplay])
				print "Caused by: " + str(e)
				raise e
			#endTry
		#endFor
	
	#endDef
	
	def augmentConfig(self, scope, scopeType, xmlFile, marker, configValidator):
	
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
	
		typeName = "WAS40DataSource"
		
		myConfigWriter = ConfigWriter();
		myConfigWriter.setUpdateReferences(1)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		scopeId = AdminConfig.getid(scope)
		for xmlNode in nodeArray:
			jndiNameDisplay = xmlNode.getAttrValue("jndiName", Globals.ATTRIBUTE_VALUE_MISSING)
			try:
				parentId = AdminHelper.findProviderId(xmlNode, scope, "JDBCProvider", "name")
				childId = configValidator.validateUniqueJndiName2(xmlNode, scopeId)
				if (childId is None):
					##print "Info: Creating " + typeName + " with jndiName: " + xmlNode.getAttrValue("jndiName")
					WAS40DataSourcesLogger.log("CRWWA2078I",[typeName,xmlNode.getAttrValue("jndiName")])
					myConfigWriter.createWASObject(xmlNode, parentId, ["JDBCProvider", "builtin"])
				else:
					if (SystemUtils.updateOnAugment()):
						## providerType is read-only and cannot be modified
						skipReadOnlyAttribute = SkipNamedAttribute("providerType")
						xmlNode.addSkipAttributeOnWriteFilter(skipReadOnlyAttribute)
						myConfigWriter.modify(childId, xmlNode, ["JDBCProvider", "builtin"])
					else:
						##print "Warning: " + typeName + " will not be created with jndiName: " + jndiNameDisplay
						WAS40DataSourcesLogger.log("CRWWA2081E",[typeName,jndiNameDisplay])
						
				#endIf
			except InvalidXmlConfigException, e:
				##print "Error: JDBC Provider associated with this datasource has not been created.  "
				WAS40DataSourcesLogger.log("CRWWA2081E")
				##print "Check to ensure that required JDBCProviders have been created."
				WAS40DataSourcesLogger.log("CRWWA2082I")
				##print "Unable to create JDBC Datasource with jndiName: " + jndiNameDisplay
				WAS40DataSourcesLogger.log("CRWWA2083I",[jndiNameDisplay,str(e)])
				#print "Caused by: " + str(e)
				raise e
			#endTry
		#endFor
	#endDef
	
	def importJDBCConfig(self, scope, scopeType, dataFile, marker):
		typeName = "WAS40DataSource"
		data = self.readConfigData(scope, scopeType, typeName, [])
		GenericConfigFileWriter.processBasicFile(dataFile, data, marker)
	#endDef
	
	def readConfigData(self, scope, scopeType, typeName, excludedTypes):
		myConfigReader = ConfigReader()
		data = []
		data.extend(myConfigReader.readConfigData(scope, scopeType, typeName))
		## filter out most attributes of JDBCProvider since it won't be written when we createConfig
		myConfigReader.stripElement(data, "provider", "JDBCProvider", ['name', Globals.RAFW_TYPE, Globals.WAS_KEY_ATTR_NAME])	
		return data
	#endDef
	
#endClass

def export(optDict=None):
	xmlFile  = optDict['properties'] 
	
	# get scope
	scope = optDict['wasscopetype']
	scopeType  = optDict['scope'] 
	typeName = optDict['type']
	marker = optDict['marker']
	thisMediator = dsMediator()
	
	mode = optDict['mode']
	thisMediator.createConfig(scope, scopeType, xmlFile, marker)
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	optDict, args = SystemUtils.getopt( sys.argv, 'type:;scope:;properties:;nodename:;scopename:;mode:' )
	
	xmlFile  = optDict['properties'] 
	
	# get scope
	scope = AdminHelper.buildScope( optDict )
	scopeType  = optDict['scope'] 
	typeName = "WAS40DataSource"
	marker = "WAS40DataSources"
	thisMediator = dsMediator()
	
	mode = optDict['mode']
	if (mode == MODE_EXECUTE):
		##print "Creating WAS 40 jdbc datasources in scope: " + scope
		WAS40DataSourcesLogger.log("CRWWA2084I",[scope])
		thisMediator.createConfig(scope, scopeType, xmlFile, marker)
	
		AdminHelper.saveAndSyncCell()
		
	elif (mode == MODE_AUGMENT):
		##print "Augmenting WAS 40 jdbc datasources in scope: " + scope
		WAS40DataSourcesLogger.log("CRWWA2085I",[scope])
		thisMediator.augmentConfig(scope, scopeType, xmlFile, marker, ConfigValidator())
	
		AdminHelper.saveAndSyncCell()
	
	elif (mode == MODE_IMPORT):
		##print "Importing WAS 40 jdbc datasources in scope: " + scope
		WAS40DataSourcesLogger.log("CRWWA2086I",[scope])
		thisMediator.importJDBCConfig(scope, scopeType, xmlFile, marker)
	
	elif (mode == MODE_COMPARE):
	   ## print "Comparing WAS 40 jdbc datasources in RAFW and WAS in scope: " + scope
	  WAS40DataSourcesLogger.log("CRWWA2087I",[scope]) 
	  ConfigMediator.compareConfig(scope, scopeType, xmlFile, marker, [typeName], [], thisMediator )
	
	else:
		##print "Unsupported MODE supplied: " + mode
		WAS40DataSourcesLogger.log("CRWWA0008W",[mode]) 
	#endIf
#endIf
