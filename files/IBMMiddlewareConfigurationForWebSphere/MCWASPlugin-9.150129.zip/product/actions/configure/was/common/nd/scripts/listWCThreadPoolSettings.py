"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: listWCThreadPoolSettings.py
	
	TODO: description
"""


import sys

print "{"

servers = AdminHelper.listServers()
for i in range( len(servers) ):
	svrName = AdminConfig.showAttribute(servers[i],'name')
	if ( svrName == "nodeagent" ): continue
	print "\t'%s' : {" % ( svrName )
	for wc in AdminConfig.list( 'WebContainer',servers[i] ).split( newline ):
		if ( len(wc) > 0):
			#print " ### %s ### " % AdminConfig.show( AdminConfig.showAttribute(wc,'transports') )
			wcThreadPool = AdminConfig.showAttribute(wc,'threadPool') 
			if ( wcThreadPool != None ):
				attrs = AdminConfig.show( wcThreadPool ).split( newline )
				for attr in attrs:
					strAttr = attr[1:len(attr)-1]
					key,value = strAttr.split( ' ' )
					print "\t\t '%s' : '%s', " % ( key,value )
				#endFor
			#endIf
		#endIf
	#endFor
	if ( (i+1) < len(servers) ): print "\t},"
	else: print "\t}"
#endFor
print "}"
