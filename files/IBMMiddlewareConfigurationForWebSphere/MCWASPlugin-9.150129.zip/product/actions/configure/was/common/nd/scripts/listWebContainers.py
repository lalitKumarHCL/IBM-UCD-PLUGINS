"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: listWebContainers.py
	
	TODO: description
"""


import sys
from org.python.modules import re

#opts,args = SystemUtils.getopt( sys.argv, 'o:' )

print "{"

for wc in AdminConfig.list( 'WebContainer' ).split( newline ):
	if (AdminConfig.showAttribute(wc, 'parentComponent').find("nodes") > 0):
		print "\t'%s' : {" % AdminConfig.showAttribute(wc, 'parentComponent').split("/")[5].split("|")[0]
	else:
		print "\t'%s' : {" % AdminConfig.showAttribute(wc, 'parentComponent').split("/")[3].split("|")[0]
	for contInst in AdminConfig.show( wc ).split( newline ):
		key,value = contInst[1:len(contInst)-1].split(" ", 1)
		print "\t\t'%s' : '%s'," % (key, value)
	#endFor
	print "\t},"
#endFor
#

print "}"
