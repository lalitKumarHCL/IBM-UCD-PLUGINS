"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: registerBaseNodeWithJobManager.py
	
	This script is to register base node with job manager
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f registerBaseNodeWithJobManager.py -host @{JOB_MANAGER_HOST} -port ${JOB_MANAGER_ADMIN_SECURE_PORT} -managedNodeName ${NODE_NAME} -user ${WAS_USERNAME} -password ${WAS_PASSWORD} 
"""


import sys

# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'job_manager_host:;job_manager_port:;managedNodeName:;nodeuser:;nodepassword:' )

jhost = optDict['job_manager_host']
jport = optDict['job_manager_port']
managedNodeName = optDict['managedNodeName']
nuser = optDict['nodeuser']
npassword = optDict['nodepassword']

AdminTask.registerWithJobManager("-host " + jhost + " -port " + str(jport) + " -managedNodeName " + managedNodeName + " -user " + nuser + " -password " + npassword )


#end main		


