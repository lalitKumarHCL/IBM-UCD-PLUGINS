"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: URLFactories.py
	
	TODO: description
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
	sys.modules['AdminControl'] = AdminControl
except:
	pass
import AdminConfig
import AdminTask
import AdminControl
import java

from AdminHelper import AdminHelper
from Logger import _Logger
from ConfigValidator import ConfigValidator
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigWriter import ConfigWriter
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

import Globals
from XmlProperty import InvalidXmlConfigException

URLFactoriesLogger = _Logger("URLFactories", MessageManager.RB_WEBSPHERE_WAS)

class dsMediator:

	def createConfig(self, scope, scopeType, xmlFile, marker, typeName, augment=0):
	
		myConfigWriter = ConfigWriter();
		configValidator = ConfigValidator()
		scopeId = AdminConfig.getid( scope )
		if (not augment):
			myConfigWriter.removeExistingConfig(scopeType, typeName, scopeId)
			
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)	
		if ( nodeArray != None):
			for xmlNode in nodeArray:
				jndiNameDisplay = xmlNode.getAttrValue("jndiName", Globals.ATTRIBUTE_VALUE_MISSING)
				try:
					parentId = AdminHelper.findProviderId(xmlNode, scope, "URLProvider", "name")
					if (augment):
						myConfigWriter.setUpdateReferences(1)
						childId = configValidator.validateUniqueJndiName2(xmlNode, scopeId)
						if (childId is None):
							##print "Info: Creating " + typeName + " with jndiName " + jndiNameDisplay
							URLFactoriesLogger.log("CRWWA2066I",[typeName,jndiNameDisplay])
							myConfigWriter.createWASObject(xmlNode, parentId, ["URLProvider", "builtin"])
						else:
							if (SystemUtils.updateOnAugment()):
								myConfigWriter.modify(childId, xmlNode, ["URLProvider", "builtin"])
							else:
								##print "Warning: " + typeName + " will not be created with jndiName " + jndiNameDisplay
								URLFactoriesLogger.log("CRWWA2067I",[typeName,jndiNameDisplay])
						#endIf
					else:
						##print "Info: Creating " + typeName + " with jndiName " + jndiNameDisplay
						URLFactoriesLogger.log("CRWWA2066I",[typeName,jndiNameDisplay])
						myConfigWriter.createWASObject(xmlNode, parentId)
					#endIf
				except InvalidXmlConfigException, e:
					##print "Error: URL Provider associated with this factory has not been created.  "
					URLFactoriesLogger.log("CRWWA2068E")
					##print "       Check to ensure that required URLProviders have been created."
					URLFactoriesLogger.log("CRWWA2069I")
					##print "       The URL Factory can not be created with jndiName: " + jndiNameDisplay
					URLFactoriesLogger.log("CRWWA2070I",[jndiNameDisplay,str(e)])
					#print "Caused by: " + str(e)
					raise e
				#endTry
			#endFor
		#endIf
	#endDef

	def readConfigData(self, scope, scopeType, typeName, excludeTypes):
		myConfigReader = ConfigReader()
		data = []
		data.extend(myConfigReader.readConfigData(scope, scopeType, typeName))
		## filter out most attributes of URLProvider since it won't be written when we createConfig
		myConfigReader.stripElement(data, "provider", "URLProvider", ['name', Globals.RAFW_TYPE, Globals.WAS_KEY_ATTR_NAME])	
		return data
	#endDef
	
#endClass

def export(optDict=None):
	scope = optDict['wasscopetype']
	scopeType = optDict['scope']
	
	#cell = AdminConfig.list( 'Cell' )
	#cellName = AdminConfig.showAttribute( cell,"name" )
	cellName = AdminControl.getCell()
	mode = optDict['mode']
	xmlFile  = optDict['properties']
	thisMediator = dsMediator()
	typeName = optDict['type'] 
	excludedTypes = optDict['excludedtypes']
	marker = optDict['marker']
	
	thisMediator.createConfig(scope, scopeType, xmlFile, marker, typeName)
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	optDict, args = SystemUtils.getopt( sys.argv, 'type:;scope:;properties:;nodename:;scopename:;mode:' )
	
	# get scope
	scope = AdminHelper.buildScope( optDict )
	scopeType = optDict['scope']
	
	#cell = AdminConfig.list( 'Cell' )
	#cellName = AdminConfig.showAttribute( cell,"name" )
	cellName = AdminControl.getCell()
	mode = optDict['mode']
	xmlFile  = optDict['properties']
	thisMediator = dsMediator()
	typeName = "URL" 
	excludedTypes = []
	marker = "URLFactories"
	
	if (mode == MODE_EXECUTE):
		##print "Creating URL Factories in scope: " + scope
		URLFactoriesLogger.log("CRWWA2071I",[scope])
		thisMediator.createConfig(scope, scopeType, xmlFile, marker, typeName)
		AdminHelper.saveAndSyncCell()
	
	elif (mode == MODE_AUGMENT):
		##print "Augmenting URL Factories in scope: " + scope
		URLFactoriesLogger.log("CRWWA2072I",[scope])
		thisMediator.createConfig(scope, scopeType, xmlFile, marker, typeName, 1)
		AdminHelper.saveAndSyncCell()
	
	elif (mode == MODE_IMPORT):
		##print "Importing URL Factories in scope: " + scope
		URLFactoriesLogger.log("CRWWA2073I",[scope])
		ConfigMediator.importConfig(scope, scopeType, xmlFile, marker, [typeName], [], thisMediator )
	elif (mode == MODE_COMPARE):
		##print "Comparing URL Factories in RAFW and WAS in scope: " + scope
		URLFactoriesLogger.log("CRWWA2074I",[scope])
		ConfigMediator.compareConfig(scope, scopeType, xmlFile, marker, [typeName], excludedTypes, thisMediator )
	else:
		##print "Unsupported MODE supplied: " + mode
		URLFactoriesLogger.log("CRWWA0008W",[mode])
	#endIf
#endIf