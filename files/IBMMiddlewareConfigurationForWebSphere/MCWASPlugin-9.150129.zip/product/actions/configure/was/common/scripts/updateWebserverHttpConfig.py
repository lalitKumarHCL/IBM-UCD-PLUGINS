"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: updateWebserverHttpConfig.py
	
	This script will udate HTTP config on each web server defined in web_servers
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py 
		-webservers ${SCOPE_HOME}/web_servers.xml --
			xml file describing the web servers to update
		-nd_profile_home ${ND_WAS_HOME}/profiles/${ND_PROFILE_NAME}
"""


import sys
import java.io.File as File
import javax.management as Mgmt 
from 	org.python.modules import re
import  org.w3c.dom.Node as Node
from ConfigReaderException import ConfigReaderException

LOGGER = _Logger("updateWebserverHttpConfig", MessageManager.RB_WEBSPHERE_WAS)

## 
## gets the http configuration from the web server
##
def downloadConfigFile(cellName, nodeName, serverName, configFile, destFilePath):
	LOGGER.traceEnter([cellName,nodeName,serverName,configFile,destFilePath])
	destFile = File(destFilePath)
	## when the web server and the dmgr are on the same host, the jmx download
	## operation becomes an uploadFile operation which fails if the file already exists
	## remove the file first
	fullPathDestFile = File(tmpConfigRoot + destFilePath)
	if (fullPathDestFile.exists()):
		LOGGER.debug("Removing local config file before downloading latest: " + fullPathDestFile.getAbsolutePath())
		fullPathDestFile.delete()
	#endIf

	objectNameStr = AdminControl.completeObjectName("WebSphere:*,type=WebServer")
	objectName = Mgmt.ObjectName(objectNameStr) 

	cArgs = []
	cArgs.append(cellName)
	cArgs.append(nodeName)
	cArgs.append(serverName)
	cArgs.append(configFile)
	cArgs.append(destFile)
	sigArgs = []
	sigArgs.append("java.lang.String")
	sigArgs.append("java.lang.String")
	sigArgs.append("java.lang.String")
	sigArgs.append("java.lang.String")
	sigArgs.append("java.io.File")
	#print "downloading file " + destFilePath
	LOGGER.log("CRWWA5038I",[destFilePath])
	
	debugArgs = ""
	for debugArg in cArgs:
		debugArgs = debugArgs + "'" + str(debugArg) + "',"
	#endFor
	LOGGER.trace("AdminControl.invoke_jmx(objectName, 'download',[" + debugArgs + "],['java.lang.String','java.lang.String','java.lang.String','java.lang.String','java.io.File'])")


	# From a java perspective this is:
	# WebServer.download(cellName, nodeName, serverName, configFile, destFile)
	AdminControl.invoke_jmx(objectName, 'download', cArgs, sigArgs)
	LOGGER.traceExit()
#endDef

## 
## uploads the http configuration to the web server
## 
def uploadConfigFile(cellName, nodeName, serverName, configFile, srcFilePath):
	LOGGER.traceEnter([cellName, nodeName, serverName, configFile, srcFilePath])
	srcFile = File(srcFilePath)

	objectNameStr = AdminControl.completeObjectName("WebSphere:*,type=WebServer")
	objectName = Mgmt.ObjectName(objectNameStr) 

	cArgs = []
	cArgs.append(cellName)
	cArgs.append(nodeName)
	cArgs.append(serverName)
	cArgs.append(srcFile)
	cArgs.append(configFile)
	sigArgs = []
	sigArgs.append("java.lang.String")
	sigArgs.append("java.lang.String")
	sigArgs.append("java.lang.String")
	sigArgs.append("java.io.File")
	sigArgs.append("java.lang.String")
	#print "uploading file " + srcFilePath
	
	debugArgs = ""
	for debugArg in cArgs:
		debugArgs = debugArgs + "'" + str(debugArg) + "',"
	#endFor
	LOGGER.trace("AdminControl.invoke_jmx(objectName, 'upload',[" 
				+ debugArgs 
				+ "],['java.lang.String','java.lang.String','java.lang.String','java.io.File','java.lang.String'])")

	# From a java perspective this is:
	# WebServer.upload(cellName, nodeName, serverName, srcFile, configFile)
	AdminControl.invoke_jmx(objectName, 'upload', cArgs, sigArgs)
	LOGGER.traceExit()
#endDef

##
## Modifies the httpd configuration file locally (on the Dmgr node)
##
def processFile(fullFilePath, uniqueAttrs, multipleAttrs, xmlChildren):
	LOGGER.traceEnter([fullFilePath, uniqueAttrs, multipleAttrs, xmlChildren])

	iFileId = open( fullFilePath,"r" )
	oFileId = open( fullFilePath + ".out", "w")

	foundTokens = {}
	foundChildren = {}
	subElemEndMarker = ""
	hasRAFWProcessedBefore = "false"

	iLines = iFileId.readlines()
	for iLine in iLines:
		
		if (len(subElemEndMarker) > 0) :
			# processing subelement
			## if the line begins with </subElem> then this is end of xml stanza
			## or the line doesn't begin with subElem (like space)
			if (iLine == subElemEndMarker):
				# end of sub-element
				subElemEndMarker = ""
				writeSubElement(oFileId, subXmlChild)
				# write the new line back into the file
				oFileId.write("\n")
			#endIf
		else:
			
			## handle Unique Attributes (attributes that can have 1 value)
			## existing values are overwritten
			##
			#for key in uniqueAttrs.keys():
			#	if (re.compile("^(#)?" + key).search(iLine)):
			#		# replace the line with our new line
			#		iLine = key + " " + uniqueAttrs[key] + "\n"
			#		print "Replacing line begining with " + key + " with " + iLine
			#		foundTokens[key] = "true"
			#	#endIf
			##endFor

			for key in uniqueAttrs.keys():
				if not re.compile("^#").search(iLine):
					 if re.compile(key).search(iLine):
						# replace the line with our new line
						iLine = key + " " + uniqueAttrs[key] + "\n"
						#print "Replacing line beginning with " + key + " with " + iLine
						LOGGER.log("CRWWA5039I",[key,iLine])
						foundTokens[key] = "true"
					#endIf
				#endIf
			#endFor

			## handle Multiple Attributes (attributes that can have multiple values)
			## existing values are not overwritten
			##
			for key in multipleAttrs.keys():
				if (re.compile("^(#)?" + key).search(iLine)):
					# only replace if this line is an exact match
					values = multipleAttrs[key]
					for i in range(len(values)):
						if (re.compile("^(#)?" + key + " " + values[i]).search(iLine)):
							#print "Replacing line containing " + iLine
							LOGGER.log("CRWWA5040I",[iLine])
							iLine = key + " " + values[i] + "\n"
							foundTokens[key + "." + str(i)] = "true"
						#endIf
					#endFor
				#endIf
			#endFor
		
			## Handle sub elements
			for xmlChild in xmlChildren:
				xmlChildNodeName = xmlChild.getNodeName()
				##
				## Inject an XML stanza
				##
				if (xmlChildNodeName == "xmlNode"):
					xmlChildXmlName = xmlChild.getAttributes().getNamedItem('name').getNodeValue()
					## process xml element
					if (re.compile("^<" + xmlChildXmlName).search(iLine)):
						# save the state to that of processing a sub element
						subElemEndMarker = "</" + xmlChildXmlName.split(' ')[0] + ">\n"
						foundChildren[xmlChildXmlName] = "true"
						# save the xmlChild to write at the end of the block
						subXmlChild = xmlChild
					#endIf
				else:
					##
					## handle Multiple Attributes (attributes that can have multiple values)
					## existing values ARE overwritten
					##
					if (re.compile("^(#)?" + xmlChildNodeName).search(iLine)):
						# save the state to that of processing a sub element
						subElemEndMarker = "\n"
						foundChildren[xmlChildNodeName] = "true"
						# save the xmlChild to write at the end of the block
						subXmlChild = xmlChild
					#endIf
				#endIf
			#endFor

			## Determine if RAFW has processed this file before, 
			## so that we don't add the RAFW sub header more than once
			if (iLine == "###### Elements Added by RAFW ######\n"):
				hasRAFWProcessedBefore = "true"
			#endIf

			# if we haven't encountered a sub element, write the line to output
			if (len(subElemEndMarker) == 0) :
				oFileId.write(iLine)
			#endIf

		#endIf

	#endFor

	if (hasRAFWProcessedBefore == "false"):
		oFileId.write("\n\n")
		oFileId.write("###### Elements Added by RAFW ######\n")
	#endIf

	## Add any uniqueAttributes that were not found
	for key in uniqueAttrs.keys():
		if (not foundTokens.has_key(key)):
			aLine = key + " " + uniqueAttrs[key]
			#print "Adding line: " + aLine
			LOGGER.log("CRWWA5041I",[aLine])
			oFileId.write(aLine + "\n")
		#endIf
	#endFor

	## Add any multiple Attributes that were not found
	for key in multipleAttrs.keys():
		values = multipleAttrs[key]
		for i in range(len(values)):
			if (not foundTokens.has_key(key + "." + str(i))):
				aLine = key + " " + values[i]
				#print "Adding line: " + aLine
				LOGGER.log("CRWWA5041I",[aLine])
				oFileId.write(aLine + "\n")
			#endIf
		#endFor
	#endFor

	## Add any sub elements that were not found
	for xmlChild in xmlChildren:
		xmlChildNodeName = xmlChild.getNodeName()

		if (xmlChildNodeName == "xmlNode"):
			xmlChildNodeName = xmlChild.getAttributes().getNamedItem('name').getNodeValue()
		#endIf
		if (not foundChildren.has_key(xmlChildNodeName)):
			writeSubElement(oFileId, xmlChild)
		#endIf
	#endFor

	iFileId.close()
	oFileId.close()
	LOGGER.traceExit()
#endDef

##
## Writes the sub element <xml> stanza to the open file descriptor
## If stanza is <xmlNode name="XXX"> then <XXX> </XXX> are printed around the 
## child contents
##
def writeSubElement(oFileId, xmlChild):
	LOGGER.traceEnter([oFileId, xmlChild])
	subName = xmlChild.getNodeName()
	if (subName == "xmlNode"):
		xmlChildNodeName = xmlChild.getAttributes().getNamedItem('name').getNodeValue()
		#print "adding elements for: " + xmlChildNodeName
		LOGGER.log("CRWWA5042I",[xmlChildNodeName])

		oFileId.write("<" + xmlChildNodeName + ">" + "\n")
		writeTextContents(oFileId, xmlChild)
		oFileId.write("</" + xmlChildNodeName.split(' ')[0] + ">" + "\n")
		
	else:
		#print "adding elements for: " + subName
		LOGGER.log("CRWWA5042I",[subName])
		writeTextContents(oFileId, xmlChild)
	#endIf
	LOGGER.traceExit()
#endDef

##
## Writes the text contents of an <xml> stanza to the open file descriptor
##
def writeTextContents(oFileId, xmlChild):
	LOGGER.traceEnter([oFileId, xmlChild])
	childrenList = xmlChild.getChildNodes()
	for ix in range( childrenList.getLength() ):
		xmlNode = childrenList.item(ix)
		if (xmlNode.getNodeType() == Node.TEXT_NODE):
			## strip the whitespace from each line
			subValues = xmlNode.getNodeValue().split( newline )
			for subValue in subValues:
				if (len(subValue.strip()) > 0):
					oFileId.write(subValue.strip() + "\n")
				#endIf
			#endFor
		#endIf
	#endFor
	LOGGER.traceExit()
#endDef

##
## returns all xml children from the parent as an array
## Filters out UniqueAttrs and MultipleAttrs
##
def getValidXmlChildren(parent):
	LOGGER.traceEnter([parent])
	childNodes = parent.getChildrenArray()
	nodeArray = []
	for xmlPropNode in childNodes:
		xmlNode = xmlPropNode.getXmlNode()
		## Only get nodes that are child elements, not TEXT nodes
		if ( xmlNode.getNodeType() == Node.ELEMENT_NODE ):
			## Filter out UniqueAttrs and MultipleAttrs
			if (xmlNode.getNodeName() != "UniqueAttrs" and xmlNode.getNodeName() != "MultipleAttrs"):
				nodeArray.append(xmlNode)
			#endIf
		#endIf
	#endFor
	LOGGER.traceExit(nodeArray)
	return nodeArray
#endDef

"""
	Gets the httpd.conf file configured for this web server
	
	@raise ConfigReaderException if the configuration cannot be found
"""
def getConfigFile(nodeName, serverName):
	LOGGER.traceEnter([nodeName, serverName])
	configType = "WebServer"
	scope = "/Cell:" + cellName + "/Node:" + nodeName + "/Server:" + serverName + "/"
	serverId = AdminConfig.getid(scope)
	webServers = AdminConfig.list(configType, serverId).split(newline)
	if (len(webServers) > 0):
		webServer = webServers[0]
		configFile = AdminConfig.showAttribute(webServer, "configurationFilename" )
		if (len(configFile) > 0):
			LOGGER.traceExit(configFile)
			return configFile
		#endIf
	#endIf
	raise ConfigReaderException("Unable to determine full path to HTTP configuration file for webserver: " 
							+ serverName + " on node: " + nodeName)

#endDef
	
# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'webservers:;mode:;nd_profile_home:' )

# parse the properties into props
xmlWebServers = ConfigFileReader.openXmlConfig( optDict['webservers'] )
ndProfileHome  = optDict['nd_profile_home'] 
tmpConfigRoot = ndProfileHome + "/config/temp"
LOGGER.trace("Working under directory: " + tmpConfigRoot)

cellName = AdminControl.getCell()
##print "Updating webserver global directives for cell:" + cellName
LOGGER.log("CRWWA2062I",[cellName])

## for each webserver
nodeArray = xmlWebServers.getFilteredNodeArray('WSConfig')
for xmlWebServer in nodeArray:

	nodeName = xmlWebServer.getAttrValue("node") 
	serverName = xmlWebServer.getAttrValue("name") 
	if (xmlWebServer.hasAttr("configurationFile")):
		configFile = xmlWebServer.getAttrValue("configurationFile") 
		LOGGER.log("CRWWA2063I" ,[configFile])
	else:
		configFile = getConfigFile(nodeName, serverName)
		LOGGER.log("CRWWA2064I",[configFile])
	#endIf

	## destFile will be relative to tmpConfigRoot
	destFilePath = "/" + nodeName + "/" + serverName + "/httpd.conf"

	downloadConfigFile(cellName, nodeName, serverName, configFile, destFilePath)

	xmlHttp = xmlWebServer.getFilteredChildrenArray("HttpConfig")[0]

	xmlUniqueAttrs = xmlHttp.getFilteredChildrenArray("UniqueAttrs")
	if (len(xmlUniqueAttrs) > 0):
		uniqueAttrs = xmlUniqueAttrs[0].buildNodeAttrsDict()
	else:
		LOGGER.log("CRWWA2065I")
		uniqueAttrs = {}
	#endIf

	xmlMultipleAttrs = xmlHttp.getFilteredChildrenArray("MultipleAttrs")
	if (len(xmlMultipleAttrs) > 0):
		multipleAttrs = {}
		for xmlAttrs in xmlMultipleAttrs:
			attrs = xmlAttrs.buildNodeAttrsDict()
			for key in attrs.keys():
				if (not multipleAttrs.has_key(key)):
					multipleAttrs[key] = []
				#endIf	
				multipleAttrs[key].append(attrs[key])
			#endFor
		#endFor
	else:
		LOGGER.log("CRWSE1673I")
		multipleAttrs = {}
	#endIf

	xmlHttpChildren = getValidXmlChildren(xmlHttp)

	processFile(tmpConfigRoot + destFilePath, uniqueAttrs, multipleAttrs, xmlHttpChildren)

	uploadConfigFile(cellName, nodeName, serverName, configFile, destFilePath + ".out")

#endFor


