"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

    
    File name: siBusModifier.py
    
    TODO: Utility class used to create/modify SIBuses and their infrastructure.
"""


class SibusModifier:
    
    """ Retrieves SIBus information from SIBus.xml """
    def getBuses(self, xmlFile, marker, typeName):
        SCRIPT_LOGGER.traceEnter([xmlFile, typeName])
        siBuses = []
        xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
        xmlProp = xmlProp.findRAFWContainerNode(marker)
        nodeArray = xmlProp.getFilteredNodeArray(typeName) 
        # {[siBusName : permittedChain : [name, name, name]], [siBusName : permittedChain : [name, name, name]]}    
        for xmlNode in nodeArray:
            siBus = {}
            attrs = xmlNode.buildNodeAttrs()
            for attr in attrs:
                key = attr[0]
                value = attr[1]
                siBus[key] = value
                # process SIBus children
            chains = self.getPermittedChains('SIBPermittedChain', xmlNode)
            foreignBuses = self.getForeignBuses('SIBForeignBus', xmlNode)
            if chains != None:
                siBus['chains'] = chains
            if foreignBuses != None:
                siBus['foreignBuses'] = foreignBuses
            siBuses.append(siBus)
        return siBuses
        SCRIPT_LOGGER.traceExit()
    #endDef
        
    """ Retrieves MessagingEngine information from SIBus.xml """
    def getMessagingEngines(self, xmlFile, marker, typeName):
        SCRIPT_LOGGER.traceEnter([xmlFile, typeName])
        messagingEngines = []
        xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
        xmlProp = xmlProp.findRAFWContainerNode(marker)
        nodeArray = xmlProp.getFilteredNodeArray(typeName)
        for xmlNode in nodeArray:
            messagingEngine = {}
            attrs = xmlNode.buildNodeAttrs()
            for attr in attrs:
                key = attr[0]
                value = attr[1]
                messagingEngine[key] = value
            # process SIBus children
            sibLinks = self.getSIBLinks('SIBGatewayLink', xmlNode)
            if sibLinks != None:
                messagingEngine['sibLinks'] = sibLinks    
            mqLinks = self.getMQLinks('SIBMQLink', xmlNode)
            if mqLinks != None:
                messagingEngine['mqLinks'] = mqLinks    
            messagingEngines.append(messagingEngine)
        return messagingEngines
    #endDef

    def getSIBLinks(self,nodeType,xmlNode):
        SCRIPT_LOGGER.traceEnter([nodeType,xmlNode])
        aList = []
        for xmlChild in xmlNode.getFilteredChildrenArray(nodeType):
            sibLink = {}
            if(xmlChild != None):
                attrs = xmlChild.buildNodeAttrs()
                for attr in attrs:
                    key = attr[0]
                    value = attr[1]
                    if key != None and value != '' and value != None:
                        sibLink[key] = value
                aList.append(sibLink)
        return aList
        SCRIPT_LOGGER.traceExit()
                
    def getMQLinks(self,nodeType,xmlNode):
        SCRIPT_LOGGER.traceEnter([nodeType,xmlNode])
        aList = []
        for xmlChild in xmlNode.getFilteredChildrenArray(nodeType):
            mqLink = {}
            if(xmlChild != None):
                attrs = xmlChild.buildNodeAttrs()
                for attr in attrs:
                    key = attr[0]
                    value = attr[1]
                    if key != 'receiverChannels' and key != 'senderChannels' and key != None and value != '' and value != None:
                        mqLink[key] = value
                receiverChannels = self.getChildNodesAsDict('SIBMQLinkReceiverChannel', xmlChild)
                senderChannels = self.getChildNodesAsDict('SIBMQLinkSenderChannel', xmlChild)
                mqLink['receiverChannels'] = receiverChannels
                mqLink['senderChannels'] = senderChannels
                aList.append(mqLink)
        return aList
        SCRIPT_LOGGER.traceExit()

    def getChildNodesAsDict(self,nodeType,xmlNode):
        SCRIPT_LOGGER.traceEnter([nodeType,xmlNode])
        aDict = None
        for xmlChild in xmlNode.getFilteredChildrenArray(nodeType):
            attrs = xmlChild.buildNodeAttrs()
            aDict = xmlChild.buildNodeAttrsDict()
        SCRIPT_LOGGER.traceExit()
        return aDict
                
    def getPermittedChains(self,nodeType,xmlNode):
        SCRIPT_LOGGER.traceEnter([nodeType,xmlNode])
        aList = []
        for xmlChild in xmlNode.getFilteredChildrenArray(nodeType):
            attrs = xmlChild.buildNodeAttrs()
            aList.append(xmlChild.getAttrValue('name'))
        SCRIPT_LOGGER.traceExit()
        return aList
    
    def getForeignBuses(self,nodeType,xmlNode):
        SCRIPT_LOGGER.traceEnter([nodeType,xmlNode])
        aList = []
        for xmlChild in xmlNode.getFilteredChildrenArray(nodeType):
            foreignBus = {}
            attrs = xmlChild.buildNodeAttrs()
            for attr in attrs:
                key = attr[0]
                value = attr[1]
                if key != None and value != '' and value != None:
                    foreignBus[key] = value
            aList.append(foreignBus)
        SCRIPT_LOGGER.traceExit()
        return aList

    def modifySIBusLinks(self, siBusName, foreignBusName, messagingEngine):
        SCRIPT_LOGGER.traceEnter([siBusName, foreignBusName, messagingEngine])
        #does this messaging engine have sibLinks or mqLinks?
        #a messaging engine cah only have one or the other
        sibLinks = messagingEngine.get('sibLinks')
        mqLinks = messagingEngine.get('mqLinks')
        #map AdminConfig names to AdminTask properties
        commandParameterList = []
        deleteCommandParameterList = []
        commandParameterList.append(self.createAdminTaskCommandString('bus', messagingEngine.get('busName')))
        commandParameterList.append(self.createAdminTaskCommandString('messagingEngine', messagingEngine.get('name')))
        deleteCommandParameterList.extend(commandParameterList)
        commandParameterList.append(self.createAdminTaskCommandString('foreignBusName', foreignBusName))

        if(sibLinks != None):
            self.modifySIBusSIBLink(commandParameterList, deleteCommandParameterList, sibLinks)
        if(mqLinks != None):
            self.modifySIBusMQLink(commandParameterList, deleteCommandParameterList, mqLinks)
        
    def modifySIBusSIBLink(self, commandList, deleteCommandList, sibLinks):
        SCRIPT_LOGGER.traceEnter([commandList, deleteCommandList, sibLinks])
        for sibLink in sibLinks:
            # sibLink -> name
            deleteCommandList.append(self.createAdminTaskCommandString('sibLink',sibLink.get('name')))
            sibLinkKeys = sibLink.keys()
            for key in sibLinkKeys:
                value = sibLink.get(key)
                if value != None:
                    interim = self.createAdminTaskCommandString(key, value)
                    if interim != None:
                        commandList.append(interim)
            commandOptions = ''.join(commandList)
            deleteCommandOptions = ''.join(deleteCommandList)
            #delete SIBLink
            AdminTask.deleteSIBLink([deleteCommandOptions])
            #create SIBLink
            AdminTask.createSIBLink([commandOptions])
        SCRIPT_LOGGER.traceExit()
        
    #
    # Most of the data for SIBus MQLinks can be loaded dynamically, but some can not.  These
    # data usually use different names for AdminTask than are returned by AdminConfig.
    #
    # mqLink attribute does not work for AdminTask delete command mqLink -> name
    # qmName attribute does not work for AdminTask create command qmName -> queueManagerName
    # protocolName attribute does not work for AdminTaks create command protocolName -> senderChannelTransportChain
    #    
    def modifySIBusMQLink(self, commandList, deleteCommandList, mqLinks):
        SCRIPT_LOGGER.traceEnter([commandList, deleteCommandList, mqLinks])
        for mqLink in mqLinks:
            # mqLink -> name
            deleteCommandList.append(self.createAdminTaskCommandString('mqLink',mqLink.get('name')))

            # qmName -> queueManagerName
            senderChannels = mqLink.get('senderChannels')
            receiverChannels = mqLink.get('receiverChannels')
            mqLinkKeys = mqLink.keys()
            for key in mqLinkKeys:
                if key != 'senderChannels' and key != 'receiverChannels':
                    value = mqLink.get(key)
                    if key != None and value != '' and value != None:
                        if key != 'qmName':
                            interim = self.createAdminTaskCommandString(key, value)
                            if interim != None:
                                commandList.append(interim)
                        else:
                            interim = self.createAdminTaskCommandString('queueManagerName',value)
                            commandList.append(interim)
            senderKeys = senderChannels.keys()
            # protocolName -> senderChannelTransportChain
            for senderKey in senderKeys:
                if senderKey != 'WASKey':
                    value = senderChannels.get(senderKey)
                    if senderKey != None and value != '' and value != None:
                        if senderKey != 'protocolName':
                            interim = self.createAdminTaskCommandString(senderKey, value)
                            if interim != None:
                                commandList.append(interim)
                        else:
                            interim = self.createAdminTaskCommandString('senderChannelTransportChain', value)
                            commandList.append(interim)
            receiverKeys = receiverChannels.keys()
            for receiverKey in receiverKeys:
                if receiverKey != 'WASKey':
                    value = receiverChannels.get(receiverKey)
                    if receiverKey != None and value != '' and value != None:
                        interim = self.createAdminTaskCommandString(receiverKey, value)
                        if interim != None:
                            commandList.append(interim)
            commandOptions = ''.join(commandList)
            deleteCommandOptions = ''.join(deleteCommandList)
            #delete MQLink
            AdminTask.deleteSIBMQLink([deleteCommandOptions])
            #create MQLink                
            AdminTask.createSIBMQLink([commandOptions])
        SCRIPT_LOGGER.traceExit()

    # create a string that can be used with AdminTask
    # filters out uuid and targetUuid values
    def createAdminTaskCommandString(self, key, value):
        if key == 'uuid' or key == 'targetUuid':
            return None 
        else:
            key = key.strip()
            value = value.strip()
            interimCommandString = ' -' + key + " '" + value + "'"
            return interimCommandString
                        
    """
        Finds object ids which are of the same type as the supplied xmlNode
        and contain values for the same attribute in the xmlNode.
        
        Blank values are ignored.  
        
        The WAS objectId is returned if found, else None
    """
    def _findObjectId(self, xmlNode):
        SCRIPT_LOGGER.traceEnter([xmlNode])
        configType = xmlNode.getNodeNameFixed()
        SCRIPT_LOGGER.debug("Looking up for the configType = " + str(configType))
        myConfigReader = ConfigReader()
        for objId in AdminConfig.list(configType).split(newline):
            if (len(objId) > 0):
                wasAttrs = myConfigReader.show(objId)
                ## match the attributes values which were passed in
                ## return the objId if we have a match
                if (self._compareIgnoringBlanks(xmlNode.buildNodeAttrsDict(), wasAttrs)):
                    SCRIPT_LOGGER.traceExit(objId)
                    return objId
                #endIf
            #endIf
        #endFor
        SCRIPT_LOGGER.traceExit(None)
        return None
    #endDef

    #create a dict of siBuses that also have foreign buses
    def mapSiBusToForeignBus(self,siBuses):
        myForeignBuses = {}
        for siBus in siBuses:
            foreignBuses = siBus.get('foreignBuses')
            if(foreignBuses != None):
                siBusName = siBus.get('name')
                for foreignBus in foreignBuses:
                    foreignBusName = foreignBus.get('name')
                    myForeignBuses[siBusName] = foreignBusName
        return myForeignBuses
#endClass

SCRIPT_LOGGER = _Logger("siBusModifier", MessageManager.RB_WEBSPHERE_WAS)
optDict, args = SystemUtils.getopt( sys.argv, 'version:;scope:;properties:;nodename:;scopename:;mode:;script_name:;action:' )

version= optDict['version']
# get scope
scopeType=optDict['scope']
scope = AdminHelper.buildScope( optDict )

propFile = optDict['properties'] 

mode = optDict['mode']
action = optDict['action']

thisSIBusModifier = SibusModifier()
marker = "siBus"

if (mode == MODE_EXECUTE):
    print "Modifying SIBus in scope: " + scope
    siBuses = thisSIBusModifier.getBuses(propFile, marker, 'SIBus')
    messagingEngines = thisSIBusModifier.getMessagingEngines(propFile, marker, 'SIBMessagingEngine')
    myForeignBusDict = thisSIBusModifier.mapSiBusToForeignBus(siBuses)
    if(action == 'was_common_configure_sibus_mq_links'):
        for messagingEngine in messagingEngines:
            mySiBusName = messagingEngine.get('busName')
            if(myForeignBusDict.has_key(mySiBusName)):
                myForeignBus = myForeignBusDict[mySiBusName]
                thisSIBusModifier.modifySIBusLinks(mySiBusName,myForeignBus,messagingEngine)
    if(action == 'was_common_configure_sibus_sib_links'):
        for messagingEngine in messagingEngines: 
            mySiBusName = messagingEngine.get('busName')
            if(myForeignBusDict.has_key(mySiBusName)):
                myForeignBus = myForeignBusDict[mySiBusName]
                thisSIBusModifier.modifySIBusLinks(mySiBusName,myForeignBus,messagingEngine)
    AdminHelper.saveAndSyncCell()
else:
    print "Unsupported MODE supplied: " + mode
#endIf