"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: showPMIStat.py
	
	TODO: description
"""

from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

showPMIStatLogger = _Logger("showPMIStat", MessageManager.RB_WEBSPHERE_WAS)

optDict, args = SystemUtils.getopt( sys.argv, 'scope:;pmimbean:;statid:;scopename:' )

def kvPair( kvarr ):
	thisDict = {}
	for pair in kvarr:
		key,value = pair.split('=')
		thisDict[key] = value
	#endFor
	return thisDict
#endDef

def grabStats( serverName,optDict ):
	perfMbean = AdminControl.queryNames( 'process=' + serverName + ',type=Perf,*' )
	jvmMbean  = AdminControl.queryNames( 'process=' + serverName + ',type=' + 
														optDict['pmimbean'] + ',*' )
	perfMbeanO = AdminControl.makeObjectName( perfMbean )
	jvmMbeanO  = AdminControl.makeObjectName( jvmMbean )
	
	
	bool = java.lang.Boolean( 'recursive' )
	
	parramsArray    = [ jvmMbeanO, bool ]
	signaturesArray = [ 'javax.management.ObjectName','java.lang.Boolean' ]
	
	jvmInfo    = AdminControl.invoke_jmx( perfMbeanO, "getStatsObject", parramsArray,signaturesArray )
	
	return kvPair( jvmInfo.getStatistic(int(optDict['statid'])).toString().split(',') )
#endDef	



if ( optDict['scope'] == "server" ):
	serverName = optDict['scopename']

	hash = grabStats( serverName, optDict )

	print " --## %s ##--" % (serverName)
	for key in hash.keys():
		print "%15s => %70s" % (key,hash[key])
	#endFor
elif ( optDict['scope'] == "node" ):
	pass
elif ( optDict['scope'] == "cluster" ):
	for server in listClusterServers( optDict['scopename'] ):
		serverName = AdminConfig.showAttribute(server,'memberName')
		hash = grabStats( serverName, optDict )
		print " --## %s ##--" % (serverName)
		for key in hash.keys():
			print "%15s => %70s" % (key,hash[key])
		#endFor
	#endFor
elif ( optDict['scope'] == "cell" ):
	pass
else:
	#print "%s is an unknown scope type: Exiting!" % (optDict['scope'])
	showPMIStatLogger.log("CRWWA5033I",[(optDict['scope'])])
#endIf
