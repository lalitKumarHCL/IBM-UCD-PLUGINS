"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: updateWebserverCerts.py
	
	This script is will extract all certs defined in sslCerts and import them into each webserver defined in web_servers
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f updateWebserverCerts.py 
		-certs ${SCOPE_HOME}/sslCerts.xml -- 
			xml file containing the keystores and certificate alias to extract and import into the web servers
		-webservers ${SCOPE_HOME}/web_servers.xml --
			xml file describing the web servers to import the certs into
		-nd_profile_home ${ND_WAS_HOME}/profiles/${ND_PROFILE_NAME}
		-basepath ${RAFW_HOME}/work  --
			directory where extracted certificates will be stored
"""


import sys
import os
from FileHelper import *

from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

updateWebserverCertsLogger = _Logger("updateWebserverCerts", MessageManager.RB_WEBSPHERE_WAS)
#---------
#  Extracts the Self Signed Cert from the specified keyStore
#---------
def extractCert (scopeName, keyStoreName, certName, basePath) :

	## Extract the cert
	certFilePath = basePath + "/" + certName + ".arm"
	FileHelper.rm(certFilePath)
	##print "Extracting Self Signed Cert: " + certName + " to path: " + certFilePath
	updateWebserverCertsLogger.log("CRWWA2059I",[certName,certFilePath])
	taskAttrs = ['-keyStoreName', keyStoreName,
		'-certificateAlias', certName,
		'-certificateFilePath', certFilePath,
		'-base64Encoded', 'true']
	taskAttrs = addScope(taskAttrs, scopeName)
	AdminTask.extractCertificate(taskAttrs)
	return certFilePath

#endDef

def importSignerCerts(scopeName, keyStoreName, signerCerts, certAliases) :

	taskAttrs = ['-keyStoreName', keyStoreName]
	taskAttrs = addScope(taskAttrs, scopeName)

	certs = AdminTask.listSignerCertificates(taskAttrs).split( newline )
	
	## delete the default and certs this task creates if they exist
	for cert in certs:
		for certAttr in cert.split('] ['):
			if (certAttr.split(' ', 1)[0] == "alias"):
				existCertName = certAttr.split(' ', 1)[1]
				if (existCertName != "" ):
					##print "Deleting Signer Cert: " + existCertName
					updateWebserverCertsLogger.log("CRWWA2060I",[existCertName])
					if (re.compile("^\[").search(existCertName)):
						existCertName = existCertName[1:len(existCertName)-1]
					taskAttrs = ['-keyStoreName', keyStoreName, '-certificateAlias', existCertName]
					taskAttrs = addScope(taskAttrs, scopeName)
					AdminTask.deleteSignerCertificate(taskAttrs)
			#endIf
		#endFor
	#endFor

	for certAlias in certAliases:
		signerCertPath = signerCerts[certAlias]
		taskAttrs = ['-keyStoreName', keyStoreName,
			'-certificateAlias', certAlias,
			'-certificateFilePath', signerCertPath,
			'-base64Encoded', 'true']
		taskAttrs = addScope(taskAttrs, scopeName)
		##print "Adding Signer Cert: " + certAlias + " from path: " + signerCertPath
		updateWebserverCertsLogger.log("CRWWA2061I",[certAlias,signerCertPath])
		AdminTask.addSignerCertificate(taskAttrs)
	#endFor

#endDef

## Adds an attribute name/value to the supplied attrsList
def addAttr(attrsList, attrName, attrValue):
	attrsList.append(attrName)
	attrsList.append(attrValue)
	return attrsList
#endDef

## Adds an attribute keyStoreScope and supplied value to the supplied attrsList
## if the supplied scopeName is set
def addScope(attrsList, scopeName):
	if (scopeName != "") :
		attrsList.append('-keyStoreScope')
		attrsList.append(scopeName)
	#endIf
	return attrsList
#endDef

# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'certs:;basepath:;webservers:;mode:;nd_profile_home:' )

# parse the properties into props
xmlCerts = ConfigFileReader.openXmlConfig( optDict['certs'] )
xmlWebServers = ConfigFileReader.openXmlConfig( optDict['webservers'] )

basePath  = optDict['basepath'] 

cellName = AdminControl.getCell()
#print "Updating webserver signer certs for cell:" + cellName
updateWebserverCertsLogger.log("CRWWA5036I",[cellName])

certFilePaths = {}
certAliases = []

## Extract all certs defined in xmlCerts
nodeArray = xmlCerts.getFilteredNodeArray('KeyStore')
for xmlNode in nodeArray:
  	keystoreName = xmlNode.getAttrValue("keyStoreName") 
        keystoreScope = ""
        if (xmlNode.hasAttr("scopeName")):
                keystoreScope = xmlNode.getAttrValue("scopeName")
        #endIf
	certArray = xmlNode.getFilteredChildrenArray('SelfSignedCert')
	for xmlCert in certArray:
  		certAlias = xmlCert.getAttrValue("certificateAlias") 
		certFilePath = extractCert (keystoreScope, keystoreName, certAlias, basePath)
		certFilePaths[certAlias] = certFilePath
		certAliases.append(certAlias)
	#endFor
#endFor

## now import the extracted certs into the trust stores for each webserver node
nodeArray = xmlWebServers.getFilteredNodeArray('WSConfig')
for xmlNode in nodeArray:
  	nodeName = xmlNode.getAttrValue("node") 
  	serverName = xmlNode.getAttrValue("name") 
	scopeId = "(cell):" + cellName + ":(node):" + nodeName + ":(server):" + serverName
	#print "scopeId=" + scopeId
	updateWebserverCertsLogger.log("CRWWA5031I",[scopeId])
	importSignerCerts(scopeId, "CMSKeyStore", certFilePaths, certAliases) 

#endFor

AdminHelper.saveAndSyncCell()

## propogate keyring to web servers
objectName = AdminControl.completeObjectName("WebSphere:*,type=PluginCfgGenerator")
profileRoot = optDict['nd_profile_home'] 
for xmlNode in nodeArray:
  	nodeName = xmlNode.getAttrValue("node") 
  	serverName = xmlNode.getAttrValue("name") 
	commandArgs="[" + profileRoot + "/config " 
	commandArgs += cellName + " " + nodeName + " " + serverName + "]" 
	#print "propagating keyring with args: " + commandArgs
	updateWebserverCertsLogger.log("CRWWA5037I",[commandArgs])
	AdminControl.invoke(objectName, 'propagateKeyring', commandArgs)
#endFor


