"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: JDBCDataSources.py
	
	This script is used to create JDBC Datasources...
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java

from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from AdminHelper import AdminHelper
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from ConfigWriter import ConfigWriterException 
from ConfigWriter import ConfigWriter
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

from ConfigValidator import ConfigValidator
from XmlProperty import InvalidXmlConfigException
import Globals

JDBCDataSourcesLogger = _Logger("JDBCDataSources", MessageManager.RB_WEBSPHERE_WAS)

class dsMediator:

	def __init__(self):
		self.parentType="JDBCProvider"
		self.parentName="name"
	#endDef
	
	def augmentConfig(self, scope, scopeType, xmlFile, marker, typeName, excludedTypes, configValidator):
	
		self.myConfigWriter = ConfigWriter()
		self.myConfigValidator = configValidator
		self.typeName = typeName
		self.scope = scope
		
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)	
		
		for xmlNode in nodeArray:
			self._createConfigObject(xmlNode)
		#endFor
	#endDef
	
	def createConfig(self, scope, scopeType, xmlFile, marker, typeName, excludedTypes):
	
		self.myConfigWriter = ConfigWriter()
		self.myConfigValidator = ConfigValidator()
		self.typeName = typeName
		self.scope = scope
		
		scopeId = AdminConfig.getid( scope )
		self.myConfigWriter.removeExistingConfig(scopeType, typeName, scopeId, excludedTypes)
	
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)	
		
		for xmlNode in nodeArray:
			self._createConfigObject(xmlNode)
		#endFor
	
	#endDef
	
	def _createConfigObject(self, xmlNode):
		jndiNameDisplay = xmlNode.getAttrValue("jndiName", Globals.ATTRIBUTE_VALUE_MISSING)
		try:
			scopeId = AdminConfig.getid(scope)
			parentId = AdminHelper.findProviderId(xmlNode, self.scope, self.parentType, self.parentName, "builtin")
			childId = self.myConfigValidator.validateUniqueJndiName2(xmlNode, scopeId)
			if (childId is None):
				##print "Info: Creating " + self.typeName + " with jndiName " + jndiNameDisplay
				JDBCDataSourcesLogger.log("CRWWA1125I",[self.typeName,jndiNameDisplay])
				self.myConfigWriter.createWASObject(xmlNode, parentId, [self.parentType, "builtin"])
			else:
				if (SystemUtils.updateOnAugment()):
					## provider type is read-only and cannot be modified
					skipReadOnlyAttribute = SkipNamedAttribute("providerType")
					xmlNode.addSkipAttributeOnWriteFilter(skipReadOnlyAttribute)
					self.myConfigWriter.modify(childId, xmlNode, [self.parentType, "builtin"])
				else:
					##print "Warning: " + self.typeName + " will not be created."
					JDBCDataSourcesLogger.log("CRWWA1125W",[self.typeName])
			#endIf
		except InvalidXmlConfigException, e:
			##print "Error: JDBC Provider associated with this datasource has not been created.  "
			JDBCDataSourcesLogger.log("CRWWA1118E")
			##print "Check to ensure that required JDBCProviders have been created."
			JDBCDataSourcesLogger.log("CRWWA1119I")
			##print "Failed to create JDBC Datasource with jndiName:" + jndiNameDisplay
			JDBCDataSourcesLogger.log("CRWWA1120I")
			raise e
		#endTry
	#endDef
	
	def readConfigData(self, scope, scopeType, typeName, excludedTypes):
		
		myConfigReader = ConfigReader()
		data = []
		data.extend(myConfigReader.readConfigData(scope, scopeType, typeName, excludedTypes))
		## filter out most attributes of JDBCProvider since it won't be written when we createConfig
		myConfigReader.stripElement(data, "provider", "JDBCProvider", ['name', Globals.RAFW_TYPE, Globals.WAS_KEY_ATTR_NAME])	
		return data
	
	#endDef
	
#endClass

def export(optDict=None):
	global scope
	scope = optDict['wasscopetype']
	scopeType = optDict['scope']
	
	cell = AdminConfig.list( 'Cell' )
	cellName = AdminConfig.showAttribute( cell,"name" )
	mode = optDict['mode']
	xmlFile  = optDict['properties']
	
	thisMediator = dsMediator()
	typeName = optDict['type']
	excludedTypes = optDict['excludedtypes']
	marker = optDict['marker']
	
	thisMediator.createConfig(scope, scopeType, xmlFile, marker, typeName, excludedTypes)
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	optDict, args = SystemUtils.getopt( sys.argv, 'type:;scope:;properties:;nodename:;scopename:;mode:' )
	
	# get scope
	scope = AdminHelper.buildScope( optDict )
	scopeType = optDict['scope']
	
	cell = AdminConfig.list( 'Cell' )
	cellName = AdminConfig.showAttribute( cell,"name" )
	mode = optDict['mode']
	xmlFile  = optDict['properties']
	
	thisMediator = dsMediator()
	typeName = "DataSource"
	excludedTypes = ["DefaultEJBTimerDataSource"]
	marker = "JDBCDataSources"
	
	if (mode == MODE_EXECUTE):
		##print "Creating datasources in scope: " + scope
		JDBCDataSourcesLogger.log("CRWWA1121I")
		thisMediator.createConfig(scope, scopeType, xmlFile, marker, typeName, excludedTypes)
		AdminHelper.saveAndSyncCell()
		
	elif (mode == MODE_AUGMENT):
		##print "Augmenting datasources in scope: " + scope
		JDBCDataSourcesLogger.log("CRWWA1122I",[scope])
		thisMediator.augmentConfig(scope, scopeType, xmlFile, marker, typeName, excludedTypes, ConfigValidator())
		AdminHelper.saveAndSyncCell()
	
	elif (mode == MODE_IMPORT):
		##print "Importing datasources in scope: " + scope
		JDBCDataSourcesLogger.log("CRWWA1123I",[scope])
		ConfigMediator.importConfig(scope, scopeType, xmlFile, marker, [typeName], excludedTypes, thisMediator )
	elif (mode == MODE_COMPARE):
		##print "Comparing datasources in RAFW and WAS in scope: " + scope
		JDBCDataSourcesLogger.log("CRWWA1124I",[scope])
		ConfigMediator.compareConfig(scope, scopeType, xmlFile, marker, [typeName], excludedTypes, thisMediator )
	else:
		##print "Unsupported MODE supplied: " + mode
		JDBCDataSourcesLogger.log("CRWWA0008W",[mode])
		
	#endIf
#endIf

