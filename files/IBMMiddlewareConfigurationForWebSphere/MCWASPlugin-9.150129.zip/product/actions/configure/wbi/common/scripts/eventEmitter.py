"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: eventEmitter.py
"""


import sys

class eventEmitter:

	def createConfig(self, scope, scopeType, xmlFile, marker, typeNames, excludedTypes):
		eventEmitterLogger.traceEnter([scope, scopeType, xmlFile, marker, typeNames, excludedTypes])
		self.myConfigWriter = ConfigWriter()
		self.myConfigValidator = ConfigValidator()
		#self.typeNames = typeNames
		self.scope = scope
		
		scopeId = AdminConfig.getid( scope )
		for typeName in typeNames:
			#print "type name: " + typeName
			self.myConfigWriter.removeExistingConfig(scopeType, typeName, scopeId, excludedTypes)
			xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
			xmlProp = xmlProp.findRAFWContainerNode(marker)
			nodeArray = xmlProp.getFilteredNodeArray(typeName)	
			if (typeName == "EventInfrastructureProvider"):
				for xmlNode in nodeArray:
					self.myConfigWriter.createWASObject(xmlNode, scopeId)
			else:
				for xmlNode in nodeArray:
					self._createConfigObject(xmlNode)
		#endFor
		eventEmitterLogger.traceExit()
	#endDef
	
	def _createConfigObject(self, xmlNode):
		eventEmitterLogger.traceEnter([xmlNode])
		try:
			parentId = AdminHelper.findProviderId(xmlNode, self.scope, "EventInfrastructureProvider", "name")
			print "parentId: " + parentId
			self.myConfigWriter.createWASObject(xmlNode, parentId, ["EventInfrastructureProvider", "builtin"])
		except InvalidXmlConfigException, e:
			print "Error: "
			raise e
		#endTry
		eventEmitterLogger.traceExit()
	#endDef

# parse the options into optDict
optDict, args = SystemUtils.getopt(sys.argv, 'type:;scope:;properties:;scopename:;mode:;action:;clusterName:;contextRoot:')

# get scope
scopeType = optDict['scope']
scope = AdminHelper.buildScope( optDict )
xmlFile = optDict['properties']
mode = optDict['mode']
action = optDict['action']

eventEmitterLogger = _Logger("eventEmitter", MessageManager.RB_WEBSPHERE_BPM)

#typeNames = ['EventInfrastructureProvider','EmitterFactoryProfile','FilterFactoryProfile','EventGroupProfileList']
typeNames = ['EventBusTransmissionProfile','EventServerProfile','DataStoreProfile','JMSTransmissionProfile','EmitterFactoryProfile','FilterFactoryProfile','EventGroupProfileList']

excludedTypes = []
thisEventEmitter = eventEmitter()
marker = 'eventEmitter'

print mode

if (mode == MODE_EXECUTE):
	#print "Creating EventEmitter in scope: " + scope
	eventEmitterLogger.log("CRWBP0200I",[scope])
	thisEventEmitter.createConfig(scope, scopeType, xmlFile, marker, typeNames, excludedTypes)
	AdminHelper.saveAndSyncCell()

elif (mode == MODE_IMPORT):
	#print "Importing EventEmitter in scope: " + scope
	eventEmitterLogger.log("CRWBP0201I",[scope])
	ConfigMediator.importConfig(scope, scopeType, xmlFile, marker, typeNames, excludedTypes)

elif (mode == MODE_COMPARE):
	#print "Comparing EventEmitter in RAFW and WAS in cell: " + cellName
	eventEmitterLogger.log("CRWBP0202I",[cellName])
	ConfigMediator.compareConfig(scope, scopeType, xmlFile, marker, typeNames, excludedTypes)
else:
	#print "Unsupported MODE supplied: " + mode
	eventEmitterLogger.log("CRWBP0203I",[mode])
#endIf
