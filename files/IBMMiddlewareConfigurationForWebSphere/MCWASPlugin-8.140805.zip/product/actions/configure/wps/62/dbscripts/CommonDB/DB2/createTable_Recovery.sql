-- BEGIN COPYRIGHT
-- *************************************************************************
-- Licensed Materials - Property of IBM
-- 5724-L01, 5655-N53, 5724-I82, 5655-R15
-- Copyright IBM Corporation 2004, 2008. All rights reserved.
-- US Government Users Restricted Rights - Use, duplication, or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.
-- *************************************************************************
-- END COPYRIGHT

-- *******************************************
-- create table FailedEvents and indexes
-- *******************************************
CREATE TABLE FailedEvents
  (MsgId			VARCHAR (255) NOT NULL,
   Destination_Module_Name	VARCHAR (255),
   Destination_Component_Name	VARCHAR (255),
   Destination_Method_Name	VARCHAR (255),
   Source_Module_Name		VARCHAR (255),
   Source_Component_Name	VARCHAR (255),
   ResubmitDestination		VARCHAR (512),
   InteractionType		VARCHAR (128),
   ExceptionDetails		VARCHAR (1024),
   SessionId			VARCHAR (255),
   CorrelationId		VARCHAR (255),
   DeploymentTarget		VARCHAR (200),
   FailureTime			TIMESTAMP NOT NULL,
   Status			INTEGER NOT NULL,
   EsQualified			SMALLINT,
   EventType		VARCHAR (10));

ALTER TABLE FailedEvents
   ADD CONSTRAINT PK_FailedEvents PRIMARY KEY (MsgId);

CREATE INDEX INX_FEDest ON FailedEvents
  (Destination_Module_Name,
   Destination_Component_Name,
   Destination_Method_Name);

CREATE INDEX INX_FESrc ON FailedEvents
  (Source_Module_Name,
   Source_Component_Name);

CREATE INDEX INX_FESID ON FailedEvents (SessionId);

CREATE INDEX INX_FEFTime ON FailedEvents (FailureTime);

CREATE INDEX INX_FEESQualified ON FailedEvents (EsQualified);

CREATE INDEX INX_FEEventType ON FailedEvents (EventType);


-- *******************************************
-- create table FailedEventBOTypes and indexes
-- *******************************************
CREATE TABLE FailedEventBOTypes
  (MsgId		VARCHAR (255) NOT NULL,
   BOType		VARCHAR (255) NOT NULL,
   Argument_Position	INTEGER NOT NULL);

ALTER TABLE FailedEventBOTypes
   ADD CONSTRAINT PK_FailedEventBO PRIMARY KEY (MsgId, Argument_Position);

ALTER TABLE FailedEventBOTypes
   ADD CONSTRAINT FK_FailedEventBO FOREIGN KEY (MsgId) REFERENCES FailedEvents(MsgId);

CREATE INDEX FailedEventBOTp ON FailedEventBOTypes (BOType);

-- *******************************************
-- create table FailedEventMessage and indexes
-- *******************************************
CREATE TABLE FailedEventMessage
  (MsgId		VARCHAR (255) NOT NULL,
   JserviceMessage	BLOB (1G));

ALTER TABLE FailedEventMessage
   ADD CONSTRAINT PK_FailedEventMSG PRIMARY KEY (MsgId);

ALTER TABLE FailedEventMessage
   ADD CONSTRAINT FK_FailedEventMSG FOREIGN KEY (MsgId) REFERENCES FailedEvents(MsgId);

-- *******************************************
-- create table FailedEventDetail and indexes
-- *******************************************
CREATE TABLE FailedEventDetail
  (MsgId		VARCHAR (255) NOT NULL,
   Message		BLOB(1G),
   Parameters		BLOB(1G),
   ExceptionDetail	BLOB(10M),
   WrapperType          SMALLINT,
   ApplicationName	VARCHAR(255),
   CEITraceControl	VARCHAR(255),
   UserIdentity		VARCHAR(128),
   ExpirationTime	TIMESTAMP);

ALTER TABLE FailedEventDetail
   ADD CONSTRAINT PK_FailedEventDTL PRIMARY KEY (MsgId);

ALTER TABLE FailedEventDetail
   ADD CONSTRAINT FK_FailedEventDTL FOREIGN KEY (MsgId) REFERENCES FailedEvents(MsgId);
