-- BEGIN COPYRIGHT
-- *************************************************************************
-- Licensed Materials - Property of IBM 
-- 5724-L01, 5655-N53, 5724-I82, 5655-R15
-- (C) Copyright IBM Corporation 2008. All rights reserved. 
-- US Government Users Restricted Rights - Use, duplication, or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.
-- *************************************************************************
-- END COPYRIGHT

drop table d2d_message;

drop table d2d_lock;

drop table d2d_metadata;

drop table d2d_content;

drop table d2d_progress;

drop table d2d_item;