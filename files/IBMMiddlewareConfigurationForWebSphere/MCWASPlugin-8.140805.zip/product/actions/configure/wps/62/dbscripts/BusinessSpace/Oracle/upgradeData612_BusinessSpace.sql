-- Licensed Materials - Property of IBM
-- 5724-M24
-- Copyright IBM Corporation 2008, 2009.  All Rights Reserved.
-- US Government Users Restricted Rights - Use, duplication or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.
-- ------------------------------------------------------------------------------------
--
-- Script file to modify data for Business Space during migration from
-- 6.1.2 to 6.2
--
-- Customize the following variable before running this script: 
--   @SCHEMA@ = Database Schema qualifier
--
-- Run the script in SQL*Plus.
-- Example:
--    sqlplus system/passw0rd@orcl @upgradeData612_BusinessSpace.sql
-- ------------------------------------------------------------------------------------

---------------------------------
-- Create, modify, drop tables --
---------------------------------

-- No change to the USER_DATA_T table

	DELETE FROM @SCHEMA@.PAGE WHERE TEMPLATE = 'Y';

	DELETE FROM @SCHEMA@.SPACES WHERE TEMPLATE = 'Y';

-- No change to the NLSINFO table
-- No change to the WIDGET table

	DELETE FROM @SCHEMA@.REGISTERED_WIDGET_NLS;

	DELETE FROM @SCHEMA@.REGISTERED_WIDGET;

	DELETE FROM @SCHEMA@.REGISTERED_CATEGORY_NLS;

	DELETE FROM @SCHEMA@.REGISTERED_CATEGORY;

	DELETE FROM @SCHEMA@.REGISTERED_ENDPOINT;

	DELETE FROM @SCHEMA@.REGISTRY_FILE;
