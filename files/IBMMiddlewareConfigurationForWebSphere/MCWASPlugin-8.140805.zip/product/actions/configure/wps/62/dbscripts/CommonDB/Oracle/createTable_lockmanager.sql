-- BEGIN COPYRIGHT
-- *************************************************************************
-- Licensed Materials - Property of IBM 
-- 5724-L01, 5655-N53, 5724-I82, 5655-R15
-- (C) Copyright IBM Corporation 2006. All rights reserved. 
-- US Government Users Restricted Rights - Use, duplication, or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.
-- *************************************************************************
-- END COPYRIGHT

create table persistentlock (
	lockId integer not null,
	sequenceId integer not null,
	owner integer not null,
	moduleName varchar2 (250),
	compName varchar2 (250),
	method varchar2 (250),
	msgHandleString varchar2 (128),
	primary key (lockId,sequenceId));