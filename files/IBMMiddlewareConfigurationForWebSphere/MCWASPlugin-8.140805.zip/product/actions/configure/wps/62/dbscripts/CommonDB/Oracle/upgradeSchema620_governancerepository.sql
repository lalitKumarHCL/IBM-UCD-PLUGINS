-- --------------------------------------------
-- Licensed Materials - Property of IBM
--
-- 5724-R31, 5655-S30
--
-- (C) Copyright IBM Corp. 2008 All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
-- ---------------------------------------------

--
--  Create temporary tables, copy the original data into them and drop the original tables
--      This is just to make sure all of the indexes on the original table are gone.
--
  CREATE TABLE W_TEMP_URI 
   (	ID NUMBER(*,0), 
	URI VARCHAR2(254) NOT NULL ENABLE, 
	NAMESPACE_ID NUMBER(*,0) NOT NULL ENABLE
   );

  INSERT INTO W_TEMP_URI SELECT * FROM W_URI; 
  DROP TABLE W_URI;

  CREATE TABLE W_TEMP_STATEMENT 
   (	ID NUMBER(*,0), 
	VERSION_FROM NUMBER(*,0) NOT NULL ENABLE, 
	VERSION_TO NUMBER(*,0) NOT NULL ENABLE, 
	SUBJ_ID NUMBER(*,0) NOT NULL ENABLE, 
	PRED_ID NUMBER(*,0) NOT NULL ENABLE, 
	OBJ_ID NUMBER(*,0) NOT NULL ENABLE, 
	OBJ_TYP_CD NUMBER(*,0) NOT NULL ENABLE,
	PARTITION_ID NUMBER(*,0) NOT NULL ENABLE
   );

  INSERT INTO W_TEMP_STATEMENT SELECT * FROM W_STATEMENT;
  DROP TABLE W_STATEMENT;

--
-- Recreate the tables with the new indexes
--

  CREATE TABLE W_URI 
   (	ID NUMBER(*,0), 
	URI VARCHAR2(254) NOT NULL ENABLE, 
	NAMESPACE_ID NUMBER(*,0) NOT NULL ENABLE
   ) ;
  ALTER TABLE W_URI ADD PRIMARY KEY (ID) ENABLE;
  ALTER TABLE W_URI ADD CONSTRAINT W_URI_FK_NAMESP FOREIGN KEY (NAMESPACE_ID)
	  REFERENCES W_NAMESPACE (ID) ENABLE;

  CREATE UNIQUE INDEX IDX_URI ON W_URI (URI);
  CREATE UNIQUE INDEX IDX_URI_BY_NS ON W_URI (NAMESPACE_ID, ID);

  CREATE TABLE W_STATEMENT 
   (	ID NUMBER(*,0), 
	VERSION_FROM NUMBER(*,0) NOT NULL ENABLE, 
	VERSION_TO NUMBER(*,0) NOT NULL ENABLE, 
	SUBJ_ID NUMBER(*,0) NOT NULL ENABLE, 
	PRED_ID NUMBER(*,0) NOT NULL ENABLE, 
	OBJ_ID NUMBER(*,0) NOT NULL ENABLE, 
	OBJ_TYP_CD NUMBER(*,0) NOT NULL ENABLE,
	PARTITION_ID NUMBER(*,0) NOT NULL ENABLE
   ) ;
  ALTER TABLE W_STATEMENT ADD PRIMARY KEY (ID) ENABLE;
  
  CREATE INDEX idx_smt_by_sbj ON w_statement (subj_id, version_from, version_to);
  CREATE INDEX idx_smt_by_fvr ON w_statement (version_from);
  CREATE INDEX idx_sbj_by_prp ON w_statement (pred_id, obj_id);
  CREATE INDEX idx_smt_by_val ON w_statement (obj_id, subj_id);
  CREATE INDEX idx_val_by_prp ON w_statement (subj_id, pred_id);
 
--
--  Copy the data from the temporary tables back into the original tables and drop the temporary tables
--
  INSERT INTO W_STATEMENT SELECT * FROM W_TEMP_STATEMENT;
  DROP TABLE W_TEMP_STATEMENT;

  INSERT INTO W_URI SELECT * FROM W_TEMP_URI;
  DROP TABLE W_TEMP_URI;

