--select comp_name, version, status from dba_registry;

grant select on pending_trans$ to public;  
grant select on dba_2pc_pending to public;  
grant select on dba_pending_transactions to public;  
grant select on V$XATRANS$ TO PUBLIC;  

--drop wps users and schemas
drop user ibmbussp cascade;
drop user orccomm cascade;
drop user orccied cascade;
drop user orcbe00 cascade;
drop user orcbc00 cascade;
drop user orcss00 cascade;
drop user orcsa00 cascade;
drop user orccm00 cascade;
drop user orcbm00 cascade;

--WPCDB user (Common database - Main WebSphere Process Server configuration)
create user orccomm identified by changeme;  
grant connect, resource, unlimited tablespace to orccomm;  
grant execute on dbms_system to orccomm;
grant javauserpriv to orccomm; 
--XA related items
grant select on pending_trans$ to orccomm;  
grant select on dba_2pc_pending to orccomm;  
--the following is required if using jdbc 10.2.0.3.0 or LOWER
grant select on dba_pending_transactions to orccomm; 
--the following is required if using jdbc 10.2.0.4.0 or HIGHER
--grant EXECUTE ON DBMS_XA to orccomm;

--CEIDB (Common Event Infrastructure configuration)
create user orccied identified by changeme;
grant connect, resource, create tablespace, drop tablespace, create view, unlimited tablespace to orccied;  
grant execute on dbms_system to orccied;  
grant javauserpriv to orccied; 
--XA related items
grant select on pending_trans$ to orccied;  
grant select on dba_2pc_pending to orccied;  
--the following is required if using jdbc 10.2.0.3.0 or LOWER
grant select on dba_pending_transactions to orccied; 
--the following is required if using jdbc 10.2.0.4.0 or HIGHER
--grant EXECUTE ON DBMS_XA to orccied;

--CEIMSG user (CEI messaging engine data store configuration)
create user orccm00 identified by changeme;  
grant connect, resource, unlimited tablespace to orccm00;  
grant execute on dbms_system to orccm00;  
grant javauserpriv to orccm00; 
--XA related items
grant select on pending_trans$ to orccm00;  
grant select on dba_2pc_pending to orccm00;  
--the following is required if using jdbc 10.2.0.3.0 or LOWER
grant select on dba_pending_transactions to orccm00; 
--the following is required if using jdbc 10.2.0.4.0 or HIGHER
--grant EXECUTE ON DBMS_XA to orccm00;

--BPCDB user (Business Process Choreographer container configuration)
create user orcbe00 identified by changeme;  
grant connect, resource, create tablespace, drop tablespace, create view, unlimited tablespace to orcbe00;  
grant execute on dbms_system to orcbe00;  
grant javauserpriv to orcbe00; 
--XA related items
grant select on pending_trans$ to orcbe00;  
grant select on dba_2pc_pending to orcbe00;  
--the following is required if using jdbc 10.2.0.3.0 or LOWER
grant select on dba_pending_transactions to orcbe00; 
--the following is required if using jdbc 10.2.0.4.0 or HIGHER
--grant EXECUTE ON DBMS_XA to orcbe00;

--BPCOBS user (Business Process Choreographer Explorer)
create user orcbc00 identified by changeme;  
grant connect, resource, create tablespace, drop tablespace, create view, unlimited tablespace to orcbc00;  
grant execute on dbms_system to orcbc00;  
grant javauserpriv to orcbc00;  
--XA related items
grant select on pending_trans$ to orcbc00;  
grant select on dba_2pc_pending to orcbc00;  
--the following is required if using jdbc 10.2.0.3.0 or LOWER
grant select on dba_pending_transactions to orcbc00; 
--the following is required if using jdbc 10.2.0.4.0 or HIGHER
--grant EXECUTE ON DBMS_XA to orcbc00;

--BPCMSG user (Business Process Choreographer Bus data store configuration)
create user orcbm00 identified by changeme;  
grant connect, resource, unlimited tablespace to orcbm00;  
grant execute on dbms_system to orcbm00;  
grant javauserpriv to orcbm00; 
--XA related items
grant select on pending_trans$ to orcbm00;  
grant select on dba_2pc_pending to orcbm00;  
--the following is required if using jdbc 10.2.0.3.0 or LOWER
grant select on dba_pending_transactions to orcbm00; 
--the following is required if using jdbc 10.2.0.4.0 or HIGHER
--grant EXECUTE ON DBMS_XA to orcbm00;

--IBMBUSSP user (Business Space)
create user ibmbussp identified by changeme;  
grant connect, resource, unlimited tablespace to ibmbussp;  
grant execute on dbms_system to ibmbussp;  
grant javauserpriv to ibmbussp; 
--XA related items
grant select on pending_trans$ to ibmbussp;  
grant select on dba_2pc_pending to ibmbussp;  
--the following is required if using jdbc 10.2.0.3.0 or LOWER
grant select on dba_pending_transactions to ibmbussp; 
--the following is required if using jdbc 10.2.0.4.0 or HIGHER
--grant EXECUTE ON DBMS_XA to ibmbussp;

--SCASYSMSG user (SCA System Bus messaging engine data store configuration)
create user orcss00 identified by changeme;  
grant connect, resource, unlimited tablespace to orcss00;  
grant execute on dbms_system to orcss00;  
grant javauserpriv to orcss00; 
--XA related items
grant select on pending_trans$ to orcss00;  
grant select on dba_2pc_pending to orcss00;  
--the following is required if using jdbc 10.2.0.3.0 or LOWER
grant select on dba_pending_transactions to orcss00; 
--the following is required if using jdbc 10.2.0.4.0 or HIGHER
--grant EXECUTE ON DBMS_XA to orcss00;

--SCAAPPMSG user (SCA Application Bus messaging engine data store configuration)
create user orcsa00 identified by changeme;  
grant connect, resource, unlimited tablespace to orcsa00;  
grant execute on dbms_system to orcsa00;  
grant javauserpriv to orcsa00; 
--XA related items
grant select on pending_trans$ to orcsa00;  
grant select on dba_2pc_pending to orcsa00;  
--the following is required if using jdbc 10.2.0.3.0 or LOWER
grant select on dba_pending_transactions to orcsa00; 
--the following is required if using jdbc 10.2.0.4.0 or HIGHER
--grant EXECUTE ON DBMS_XA to orcsa00;