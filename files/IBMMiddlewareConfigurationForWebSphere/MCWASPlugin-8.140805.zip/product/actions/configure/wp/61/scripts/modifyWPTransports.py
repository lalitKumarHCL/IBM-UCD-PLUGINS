"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: modifyWPTransports.py
	
	TODO: description
"""


import sys
from java.util import Properties
from java.io import FileInputStream



def updateWPTransports(cloneName, nodeName, wpHttpTransport, wpHttpsTransport):

     
     mgrName = AdminControl.getNode( )
     cell = AdminConfig.list("Cell" )
     cellName = AdminConfig.showAttribute(cell, "name" )
     cloneid = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/Server:"+cloneName+"/")
	
     #first, remove the old transports
     print "removing old HTTP(S) transports"
     for id in AdminConfig.list("HTTPTransport", cloneid ).split("\n"):
             AdminConfig.remove(id )
     #endFor 
     
     #now, create new ones with just the ports I want
     webid = AdminConfig.list("WebContainer", cloneid )
     
     ##non-SSL first
     attrib = []
     attrib.append(["sslEnabled", "false"])
     attrib.append(["address", [["host", "*" ], ["port", wpHttpsTransport]]])
     print "setting HTTP port "+ wpHttpTransport
     AdminConfig.create("HTTPTransport", webid, attrib )
     
     ##SSL
     attrib = []
     attrib.append(["sslEnabled", "true"])
     attrib.append(["address", [["host", "*" ], ["port", wpHttpsTransport]]])
     attrib.append(["sslConfig", mgrName+"/DefaultSSLSettings"])
     print "Setting HTTPS port " + wpHttpsTransport 
     AdminConfig.create("HTTPTransport", webid, attrib )


#endDef

propFile=sys.argv[0]
properties=Properties();

try:
    properties.load(FileInputStream(propFile))
    print "Succesfully read property file "+propFile
except:
    raise "Cannot read property file "+propFile

nodeName = str(properties.getProperty("NODE_NAME"))
wpHttpTransport = str(properties.getProperty("WP_HTTP_TRANSPORT"))
wpHttpsTransport = str(properties.getProperty("WP_HTTPS_TRANSPORT"))
cloneName = sys.argv[1]

updateWPTransports(cloneName, nodeName, wpHttpTransport, wpHttpsTransport)

#Syncronize the node
print "Synchronizings Nodes..."
nodeSync = AdminControl.completeObjectName("type=NodeSync,node="+nodeName+",*" )
if (len(nodeSync) == 0):
        print "Error -- NodeSync MBean not found for name "+nodeName
#endIf

print "Invoking synchronization for node "+nodeSync
AdminControl.invoke(nodeSync, "sync" )
print "Done with synchronization."
print "Saving Config..."
AdminConfig.save( )
