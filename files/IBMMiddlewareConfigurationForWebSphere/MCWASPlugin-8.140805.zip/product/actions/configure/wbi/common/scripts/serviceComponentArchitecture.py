"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: serviceComponentArchitecture.py
"""

import sys
from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

serviceComponentArchitectureLogger = _Logger("serviceComponentArchitecture", MessageManager.RB_WEBSPHERE_WP)

class serviceComponentArchitecture:
	def enableRemoteSCACluster(self):
		commandOptions = '-clusterName ' + optDict['clusterName'] + ' -remoteMELocation ' + optDict['remoteMELocation'] + ' -meAuthAlias ' + optDict['meAuthAlias'] + ' -systemBusSchemaName ' + optDict['systemBusSchemaName']
		scaLogger.debug('AdminTask.configSCAAsyncForCluster([' + commandOptions +'])')
		AdminTask.configSCAAsyncForCluster(commandOptions)

	def enableLocalSCACluster(self):
        #+ ' -systemBusId ' + optDict['systemBusId']
		commandOptions = '-clusterName ' + optDict['clusterName'] + ' -meAuthAlias ' + optDict['meAuthAlias'] + ' -systemBusSchemaName ' + optDict['systemBusSchemaName'] + ' -systemBusDataSource ' + optDict['systemBusDataSource'] + ' -createTables ' + optDict['createTables'] 
		scaLogger.debug('AdminTask.configSCAAsyncForCluster([' + commandOptions +'])')
		AdminTask.configSCAAsyncForCluster(commandOptions)

	def enableRemoteSCAJMSCluster(self):
		commandOptions = '-clusterName ' + optDict['clusterName'] + ' -remoteMELocation ' + optDict['remoteMELocation'] + ' -meAuthAlias ' + optDict['meAuthAlias'] + ' -appBusSchemaName ' + optDict['appBusSchemaName']
		scaLogger.debug('AdminTask.configSCAJMSForCluster([' + commandOptions +'])')
		AdminTask.configSCAJMSForCluster(commandOptions)

	def enableLocalSCAJMSCluster(self):
		commandOptions = '-clusterName ' + optDict['clusterName'] + ' -meAuthAlias ' + optDict['meAuthAlias'] + ' -appBusSchemaName ' + optDict['appBusSchemaName']  + ' -appBusDataSource ' + optDict['appBusDataSource'] + ' -createTables ' + optDict['createTables'] 
		scaLogger.debug('AdminTask.configSCAJMSForCluster([' + commandOptions +'])')
		AdminTask.configSCAJMSForCluster(commandOptions)
		
	def enableConfigRecoveryForCluster(self):
		commandOptions = '-clusterName ' + optDict['clusterName'] + ' -remoteMELocation ' + optDict['remoteMELocation']
		scaLogger.debug('AdminTask.configRecoveryForCluster([' + commandOptions + '])')
		AdminTask.configRecoveryForCluster(commandOptions)
							
# parse the options into optDict
optDict, args = SystemUtils.getopt(sys.argv, 'type:;scope:;properties:;action:;clusterName:;scopename:;mode:;remoteMELocation:;meAuthAlias:;systemBusSchemaName:;systemBusId:;:;systemBusDataSource:;appBusSchemaName:;appBusDataSource:;createTables:')

# get scope
scopeType = optDict['scope']
scope = AdminHelper.buildScope( optDict )
xmlFile = optDict['properties']
mode = optDict['mode']
action = optDict['action']

scaLogger = _Logger("serviceComponentArchitecture", MessageManager.RB_WEBSPHERE_BPM)
thisSCA = serviceComponentArchitecture()

if(mode == MODE_EXECUTE):
	#print "Configuring Service Component Architecture on %s" % optDict['clusterName']
	serviceComponentArchitectureLogger.log("CRWBP0204I",[optDict['clusterName']])
	if(action == "ENABLE_LOCAL"):
		thisSCA.enableLocalSCACluster()
	if(action == "ENABLE_REMOTE"):
		thisSCA.enableRemoteSCACluster();
	if(action == "ENABLE_JMS_LOCAL"):
		thisSCA.enableLocalSCAJMSCluster()
	if(action == "ENABLE_JMS_REMOTE"):
		thisSCA.enableRemoteSCAJMSCluster();
	if(action == "ENABLE_RECOVERY"):
		thisSCA.enableConfigRecoveryForCluster();
	AdminHelper.saveAndSyncCell()
else:
	#print "Unsupported MODE supplied: " + mode
	serviceComponentArchitectureLogger.log("CRWBP0205I",[mode])
