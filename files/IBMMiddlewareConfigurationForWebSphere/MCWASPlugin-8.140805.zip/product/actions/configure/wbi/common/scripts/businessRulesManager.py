"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: businessRulesManager.py
"""

import sys
from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

businessRulesManagerLogger = _Logger("businessRulesManager", MessageManager.RB_WEBSPHERE_WP)


class businessRulesManager:
	def deployBusinessRulesManager(self):
		commandOptions = '-clusterName ' + optDict['clusterName'] + ' -contextRoot ' + optDict['contextRoot']
		businessRulesManagerLogger.debug('AdminTask.configBusinessRulesManager(' + commandOptions +')')
		AdminTask.configBusinessRulesManager(commandOptions)

# parse the options into optDict
optDict, args = SystemUtils.getopt(sys.argv, 'type:;scope:;properties:;scopename:;mode:;action:;clusterName:;contextRoot:')

# get scope
scopeType = optDict['scope']
scope = AdminHelper.buildScope( optDict )
xmlFile = optDict['properties']
mode = optDict['mode']
action = optDict['action']

businessRulesManagerLogger = _Logger("businessRulesManager", MessageManager.RB_WEBSPHERE_WP)
thisBusinessRulesManager = businessRulesManager()

if(mode == MODE_EXECUTE):
	#print "Configuring WebSphere Business Rules Manager on: %s" % optDict['clusterName']
	businessRulesManagerLogger.log("CRWWP2000I",[optDict['clusterName']])
	if(action == "DEPLOY"):
		thisBusinessRulesManager.deployBusinessRulesManager();
		AdminHelper.saveAndSyncCell()
else:
	#print "Unsupported MODE supplied: %s" % optDict['mode']
	businessRulesManagerLogger.log("CRWWP2001I",[optDict['mode']])