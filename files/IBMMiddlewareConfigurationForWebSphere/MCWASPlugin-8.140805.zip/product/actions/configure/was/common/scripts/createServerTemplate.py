"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: createServerTemplate.py
	
	This script is to create an server template from a server.
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f createServerTemplate.py -servername <server name> -nodename <node name> -template <jvm template name>  
		-servername <server name>, nodename <node name>: specify the name of the server to be used for creating the template
		-template <jvm template name>: specify the name of the jvm template
"""

from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
import sys

# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'servername:;nodename:;template:' )

cellname = AdminControl.getCell()
nodename = optDict['nodename']
servername = optDict['servername']

createServerTemplateLogger = _Logger("createServerTemplate", MessageManager.RB_WEBSPHERE_WAS)

# Check if it is a valid node
node = AdminConfig.getid( '/Cell:' + cellname + '/Node:' + nodename + '/' )

if node == "":
	raise "\ncreateServerTemplate.py: Error -- Invalid node name: " + nodename 
#endIf

# Check if a server by this name already existing on the node
server = AdminConfig.getid("/Cell:" + cellname + "/Node:" + nodename + "/Server:" + servername + "/")

if server == "":
	raise "\ncreateServerTemplate.py: Error -- Server " + servername + " does not exist on node " + nodename
#endIf

templName = optDict['template']

if templName == "":
	raise "\ncreateServerTemplate.py: Error -- template name is not specified. "
#endif

# Check if a template by this name already existing on the node

templ = AdminConfig.listTemplates('Server', templName)
	
serverType = AdminConfig.showAttribute(server, 'serverType')

if templ.find(templName + '(templates/servertypes/' + serverType + '/servers/' + templName +'|server.xml') >= 0:
	#print "\ncreateServerTemplate.py: Warn -- the template " + templName + " is already created. " 
	createServerTemplateLogger.log("CRWWA1010W",[templName])
else:
	AdminTask.createApplicationServerTemplate(['-serverName', servername, '-nodeName', nodename, '-templateName', templName])
	AdminHelper.saveAndSyncCell()
#endIf
#end main		


