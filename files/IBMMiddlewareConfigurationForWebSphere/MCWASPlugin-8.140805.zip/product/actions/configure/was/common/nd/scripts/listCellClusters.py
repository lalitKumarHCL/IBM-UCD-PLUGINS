"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: listCellClusters.py
	
	TODO: description
"""


from org.python.modules import re

clusterIds = AdminConfig.list( 'ServerCluster' )
if (len(clusterIds) == 0):
	print "There are 0 clusters found in the cell"
for cluster in clusterIds.split( newline ):
	if (len(cluster) > 0):
		print "--## %s ##--" % cluster
		for clustVar in AdminConfig.show( cluster ).split( newline ):
			if ( re.search( "\w \(.*\)",clustVar) ):
				print "\t%s" % clustVar
				map = clustVar.split()[1].replace(']','')
				for mapValue in AdminConfig.show( map ).split( newline ):
					print "\t\t%s" % mapValue
				#endFor
			elif ( re.search( '\[members',clustVar) ):
				StrArr = []
				print "\t%s" % '[ClusterMembers]'
				StrArr = clustVar.split( ' ', 1 )
				memberList = StrArr[1].replace( '[','' )
				memberList = memberList.replace( ']','' )
				memberList = memberList.replace( '"','' )
				for member in memberList.split():
					print "\t\t%s" % member
					for mapValue in AdminConfig.show( member ).split( newline ):
						print "\t\t\t%s" % mapValue
					#endFor
				#endFor
			else:
				print "\t%s" % clustVar
			#endIf
		#endFor
	#endIf
#endFor
