"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: createProxyServer.py
	
	This script is to create a proxy server on the specified node, with the supplied proxy server template.
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f createProxyServer.py -servername <server name> -nodename <node name> -template <proxy server template> 
		-servername <server name>: specify the name of the server to be created
		-nodename <node name>: specify the node name of the server to be created 
		-template <proxy server template>: specify the proxy server template, if not specified or not exist, the default will be used
"""

import sys
from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager


"""
	Creates proxy server
"""
def createServer(node, proxyServer, proxyTemplate):
	## Set default template to 'proxy_server', if not provided by user
	if(proxyTemplate == ""):		
		proxyTemplate = "proxy_server"
		LOGGER.log("CRWWA0161I", ["ProxyServer", proxyTemplate])		
	#endIf
	
	commandOptions = '[-name ' + proxyServer + ' -templateName ' + proxyTemplate +']'
	LOGGER.debug("AdminTask.createProxyServer(" + commandOptions + ")")
	AdminTask.createProxyServer(node, commandOptions)
	
	## Save configuration
	AdminHelper.saveAndSyncCell()
#endDef

"""
	Identifies if the supplied server exists in the WebSphere node configuration.
	If server by the same name already exists returns true, else returns false.
"""
def ifProxyServerExists(cell, node, server):
	serverId = AdminConfig.getid( '/Cell:' + cell + '/Node:' + node + '/Server:' + server + '/' )
	if (serverId == ""):
		return 0
	else:
		return 1
	#endIf	
#endDef

def execute(cell, node, server, template):
	## Validate that topology is network deployment(ND) and not standalone
	## server, since proxy server management is supported only in ND
	
	nodeAgents = AdminConfig.list("NodeAgent")
	if (nodeAgents == ""):
		## zero nodeagents indicates standalone topology
		LOGGER.log("CRWWA0181E", ["createProxyServer not supported on stand-alone application server environment"])
		raise MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, "CRWWA0181E", 
							"createProxyServer not supported on stand-alone application server environment")
	#endIf
	
	## Check if it is a valid node
	nodeId = AdminConfig.getid( '/Cell:' + cell + '/Node:' + node + '/' )
	if nodeId == "":
		LOGGER.log("CRWWA0160E", ["Node", node])
		raise MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, "CRWWA0160E", ["Node", node])
	#endIf
	
	## Create new proxy server, only if server with same name doesn't exist in the WebSphere node
	if(not ifProxyServerExists(cell, node, server)):
		createServer(node, server, template)
		LOGGER.log("CRWWA0159I", [server])
	else:
		LOGGER.log("CRWWA0155W", ["Server", server])
	#endIf
#endDef

## parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'servername:;nodename:;template:' )

cellName = AdminControl.getCell()
nodeName = optDict['nodename']
serverName = optDict['servername']
templateName = optDict['template']

LOGGER = _Logger("createProxyServer", MessageManager.RB_WEBSPHERE_WAS)

## Invoke create proxy server function
execute(cellName, nodeName, serverName, templateName)
