"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: exchangeSSLCerts.py
	
	This script is to create SSL certs in the cell
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f replaceDefaultSelfSignedCerts.py 
		-properties ${SCOPE_HOME}/sslCerts.xml -- 
			xml file containing CertTemplate to be used as inputs on optional 
			arguments when the cert is created 
		-nodes -- comma delimited list of nodes node01,node02
		-basepath ${RAFW_HOME}/work -- directory where extracted certificates will be stored

"""

from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

import sys

#---------
#  Creates the Self Signed Cert in the specified keyStore
#---------

exchangeSSLCertsLogger = _Logger("exchangeSSLCerts", MessageManager.RB_WEBSPHERE_WAS)

def processNode (scopeName, keyStoreName, certName, basePath, xmlCertTemplate) :

	taskAttrs = ['-keyStoreName', keyStoreName]
	taskAttrs = addScope(taskAttrs, scopeName)

	certs = AdminTask.listPersonalCertificates(taskAttrs).split(newline)

	certExists = 0
	certsToDelete = []
	
	## delete the default and certs this target created in the past if they exist
	for cert in certs:
		for certAttr in cert.split('] ['):
			if (certAttr.split(' ', 1)[0] == "alias"):
				existCertName = certAttr.split(' ', 1)[1]
				if (existCertName == certName.lower()):
					certExists = 1
				elif (existCertName == 'default'):
					#print "Self Signed Cert: " + existCertName + " will be deleted."
					exchangeSSLCertsLogger.log("CRWWA1014I",[existCertName])
					taskAttrs = ['-keyStoreName', keyStoreName, '-certificateAlias', existCertName]
					taskAttrs = addScope(taskAttrs, scopeName)
					certsToDelete.append(taskAttrs)
				#endIf
			#endIf
		#endFor
	#endFor
	
	if (certExists == 0):
		## Create the cert
		#print "Creating Self Signed Cert: " + certName
		exchangeSSLCertsLogger.log("CRWWA1015I",[certName])
		taskAttrs = xmlCertTemplate.buildNodeAttrsList()
		taskAttrs = addAttr(taskAttrs, '-keyStoreName', keyStoreName)
		taskAttrs = addAttr(taskAttrs, '-certificateCommonName', certName)
		taskAttrs = addAttr(taskAttrs, '-certificateAlias', certName)
		taskAttrs = addScope(taskAttrs, scopeName)
		AdminTask.createSelfSignedCertificate(taskAttrs)
	#endIf

	## Extract the cert
	certFilePath = basePath + "/" + certName + ".arm"
	#print "Extracting Self Signed Cert: " + certName + " to path: " + certFilePath
	exchangeSSLCertsLogger.log("CRWWA1016I",[certName,certFilePath])
	taskAttrs = ['-keyStoreName', keyStoreName, 
		'-certificateAlias', certName, 
		'-certificateFilePath', certFilePath, 
		'-base64Encoded', 'true']
	taskAttrs = addScope(taskAttrs, scopeName)
	AdminTask.extractCertificate(taskAttrs)
	return (certFilePath, certsToDelete)

#endDef

def importSignerCerts(scopeName, keyStoreName, signerCerts, certAliases) :

	taskAttrs = ['-keyStoreName', keyStoreName]
	taskAttrs = addScope(taskAttrs, scopeName)

	certs = AdminTask.listSignerCertificates(taskAttrs).split(newline)
	
	## delete the default and certs this task creates if they exist
	for cert in certs:
		for certAttr in cert.split('] ['):
			if (certAttr.split(' ', 1)[0] == "alias"):
				existCertName = certAttr.split(' ', 1)[1]
				for certAlias in certAliases:
					if (existCertName == certAlias.lower()):
						#print "Deleting Signer Cert: " + existCertName
						exchangeSSLCertsLogger.log("CRWWA1017I",[existCertName])
						if (re.compile("^\[").search(existCertName)):
							existCertName = existCertName[1:len(existCertName)-1]
						taskAttrs = ['-keyStoreName', keyStoreName, '-certificateAlias', existCertName]
						taskAttrs = addScope(taskAttrs, scopeName)
						AdminTask.deleteSignerCertificate(taskAttrs)
					#endIf
				#endFor
				if (existCertName == 'default'):
					#print "Deleting Signer Cert: " + existCertName
					exchangeSSLCertsLogger.log("CRWWA1017I",[existCertName])
					if (re.compile("^\[").search(existCertName)):
						existCertName = existCertName[1:len(existCertName)-1]
					taskAttrs = ['-keyStoreName', keyStoreName, '-certificateAlias', existCertName]
					taskAttrs = addScope(taskAttrs, scopeName)
					AdminTask.deleteSignerCertificate(taskAttrs)
				#endIf
			#endIf
		#endFor
	#endFor
	
	# save config
	#print "Saving Config After Deleting Previous Certs..."
	exchangeSSLCertsLogger.log("CRWWA1018I")
	AdminConfig.save()

	for certAlias in certAliases:
		signerCertPath = signerCerts[certAlias]
		taskAttrs = ['-keyStoreName', keyStoreName, 
			'-certificateAlias', certAlias, 
			'-certificateFilePath', signerCertPath, 
			'-base64Encoded', 'true']
		taskAttrs = addScope(taskAttrs, scopeName)
		#print "Adding Signer Cert: " + certAlias + " from path: " + signerCertPath
		exchangeSSLCertsLogger.log("CRWWA1019I",[certAlias,signerCertPath])
		AdminTask.addSignerCertificate(taskAttrs)
	#endFor

#endDef

## Adds an attribute name/value to the supplied attrsList
def addAttr(attrsList, attrName, attrValue):
	attrsList.append(attrName)
	attrsList.append(attrValue)
	return attrsList
#endDef

## Adds an attribute keyStoreScope and supplied value to the supplied attrsList
## if the supplied scopeName is set
def addScope(attrsList, scopeName):
	if (scopeName != "") :
		attrsList.append('-keyStoreScope')
		attrsList.append(scopeName)
	#endIf
	return attrsList
#endDef

#print "Creating Default Certificates and exchanging them between nd and each node in the cell"
exchangeSSLCertsLogger.log("CRWWA1100I")

# parse the options into optDict
optDict, args = SystemUtils.getopt(sys.argv, 'properties:;basepath:;mode:;nodes:')

# parse the properties into props
xmlProp = ConfigFileReader.openXmlConfig(optDict['properties'])

## Only use the first CertTemplate in the xml file all others will be ignored
xmlCertTemplate = xmlProp.getFilteredNodeArray('CertTemplate')[0]

basePath  = optDict['basepath'] 
nodes = optDict['nodes']

cellName = AdminControl.getCell()
#print "cellName=" + cellName
exchangeSSLCertsLogger.log("CRWWA1101I",[cellName])

# ALIAS_EXTRA_NAME = "_02"
ALIAS_EXTRA_NAME = ""

certFilePaths = {}
certAliases = []
certFilePath, certsToDelete = processNode ("", "CellDefaultKeyStore", cellName + ALIAS_EXTRA_NAME, basePath, xmlCertTemplate)
certFilePaths[cellName + ALIAS_EXTRA_NAME] = certFilePath
certAliases.append(cellName + ALIAS_EXTRA_NAME)

for nodeName in nodes.split(','):
	#print "nodeName=" + nodeName
	exchangeSSLCertsLogger.log("CRWWA1102I",[nodeName])
	scopeId = "(cell):" + cellName + ":(node):" + nodeName 
	certFilePath, moreCertsToDelete = processNode (scopeId, "NodeDefaultKeyStore", nodeName + ALIAS_EXTRA_NAME, basePath, xmlCertTemplate)
	certsToDelete.extend(moreCertsToDelete)
	certFilePaths[nodeName + ALIAS_EXTRA_NAME]= certFilePath
	certAliases.append(nodeName + ALIAS_EXTRA_NAME)
#endFor

## now import the extracted certs into the trust stores for the cell
importSignerCerts("", "CellDefaultTrustStore", certFilePaths, certAliases) 

## now import the extracted certs into the trust stores for each node
for nodeName in nodes.split(','):
	scopeId = "(cell):" + cellName + ":(node):" + nodeName 
	#print "scopeId=" + scopeId
	exchangeSSLCertsLogger.log("CRWWA1103I",[scopeId])
	importSignerCerts(scopeId, "NodeDefaultTrustStore", certFilePaths, certAliases) 

#endFor

## delete those pesky other certs
for certToDelete in certsToDelete:
	#print "Deleting Certificate:"
	exchangeSSLCertsLogger.log("CRWWA1104I")
	print certToDelete
	AdminTask.deleteCertificate(certToDelete)
#endFor

# save config
#print "Saving Config..."
exchangeSSLCertsLogger.log("CRWWA1107I")
AdminConfig.save()

#Syncronize the Cell
#print "Nodes cannot be synchronized until ClientTrustStores are updated.  "
exchangeSSLCertsLogger.log("CRWWA1105I")
#print "Please run was_common_configure_retrieve_trust_store_signers on all nodes, then synchronize the cell."
exchangeSSLCertsLogger.log("CRWWA1106I")