"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 


	File name: J2CResourceAdapters.py

	This script is used to create Resource Adapters...
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java

from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from ConfigWriter import ConfigWriterException 
from ConfigWriter import ConfigWriter
from AdminHelper import AdminHelper
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

J2CResourceAdaptersLogger = _Logger("J2CConfigWriter", MessageManager.RB_WEBSPHERE_WAS)
class J2CConfigWriter(ConfigWriter):
	def __init__(self):
		ConfigWriter.__init__(self)
		self.LOGGER = _Logger("J2CConfigWriter", MessageManager.RB_WEBSPHERE_WAS)
		self.newline = java.lang.System.getProperty("line.separator")
	#endDef
	
	def _isNonUniqueChild(self,wasType):
		"""
		For certain child types of J2CResourceAdapter, we cannot identify them by key
		or by their attributes (they are identical copies within WAS) so for those 
		types, we need to just grab the first match rather than fail on multiple matches
		This function simply returns True if the given wasType is one of those we
		cannot uniquely identify
		"""
		self.LOGGER.traceEnter(wasType)
		nonUniqueAttrs = ['ActivationSpec','AdminObject','ConnectionDefinition']
		try:
			# we don't care what the index is, just that .index() does not
			# throw an exception means it was found, so return True
			nonUniqueAttrs.index(wasType)
			self.LOGGER.traceExit('1')
			return 1
		except ValueError:
			self.LOGGER.traceExit('0')
			return 0
		#endTry
	#endDef
	
	def getReferenceId(self, xmlNode, scopeId = None):
		"""
		Finds the object id in WebSphere configuration which matches the supplied xmlNode.
		Returns the object id or None if none can be found or if more than 1 match is found.
		Uses the MissingReferenceIdHandler to create missing references if none can be found.
		This method can be overridden in a subclass when necessary
		"""
		self.LOGGER.traceEnter(xmlNode)
		referenceId = None
		discoveredIds = self.configReader.findObjectIds(xmlNode)
		if (len(discoveredIds) == 0 and self.missingReferenceIdHander is not None):
			referenceId = self.missingReferenceIdHander.handleMissingReferenceId(xmlNode)
		elif (len(discoveredIds) > 1):
			J2CResourceAdaptersLogger.log("CRWWA2001I",[str(xmlNode)])
			J2CResourceAdaptersLogger.log("CRWWA2004I",[str(discoveredIds)])
			if (self.initialScopeId is not None):
				J2CResourceAdaptersLogger.log("CRWWA2002I",[str(self.initialScopeId)])
				## try again with tighter scope
				discoveredIds = self.configReader.findObjectIds(xmlNode, self.initialScopeId)
				wasType = xmlNode.getNodeNameFixed()
				if (len(discoveredIds) == 1 or self._isNonUniqueChild(wasType)):
					# J2CResourceAdapters contain a few child objects that cannot be
					# uniquely identified (no key, all attributes identical)
					# so for those lets just grab element 0 from the results
					referenceId = discoveredIds[0]
				else:
					J2CResourceAdaptersLogger.log("CRWWA2003I",[str(self.initialScopeId)])
					J2CResourceAdaptersLogger.log("CRWWA2004I",[str(discoveredIds)])
					referenceId = None
				#endIf
			else:
				self.LOGGER.trace("CRWSE1615I")
				referenceId = None
			#endIf
		elif (len(discoveredIds) == 1):
			referenceId = discoveredIds[0]
		#endIf
		self.LOGGER.traceExit(referenceId)
		return referenceId
	#endDef
	"""
	##--------------------------------------------------------------------
	## Removes configuration data from WAS
	## This method does not remove "builtin" WAS configuration types
	##
	## @param scopeType: cell/node/cluster/server - used to filter out nodes not in scope
	## @param typeName: The WAS configuraton type to remove, usually given by xmi:id in WAS config files
	## @param scopeId: Optional param used to specify the parent id to start search from
	## 
	##--------------------------------------------------------------------
	"""
	def removeJ2CConfig(self, scopeType, typeName, scopeId=None, excludedIds=[]):
		self.LOGGER.traceEnter([scopeType, typeName, scopeId, excludedIds])
		if (scopeId == None):
			existingConfigIds = AdminConfig.list(typeName).split(self.newline)
		else:
			existingConfigIds = AdminConfig.list(typeName, scopeId).split(self.newline)
		#endIf

		for existingId in existingConfigIds:
			## if anything found, is in scope, and not builtin
			if (len(existingId) > 0 and AdminHelper.isInScope(scopeType, existingId) and (existingId.find("builtin") == -1)):
				if (excludedIds != []):
					exclude = 0
					for excludedId in excludedIds:
						if ( excludedId == existingId ):
							exclude = 1
						#endIf
					#endFor
					if (not exclude):
						self.remove(existingId, excludedIds)
					#endIf
				else:
					self.remove(existingId, excludedIds)
				#endIf
			#endIf
		#endFor
		self.LOGGER.traceExit()
	#endDef
#endClass

class ResourceAdapterMediator:
	
	def __init__(self):
		self.LOGGER = _Logger("J2CResourceAdapters", MessageManager.RB_WEBSPHERE_WAS)
		self.myConfigWriter = J2CConfigWriter()
		self.myConfigReader = ConfigReader()
		self.newline = java.lang.System.getProperty("line.separator")
	#endDef
	
	def createConfig(self, scope, scopeType, xmlFile, marker, typeNames, augment):
		
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)

		scopeId = AdminConfig.getid(scope)
		#If my id is empty string, im probably processing ihs, which i dont add stuff to
		if scopeId == '':
			return
		for typeName in typeNames:
			self.LOGGER.debug("processing configType: " + typeName)
			nodeArray = xmlProp.getFilteredNodeArray(typeName)
			
			# For adapters that already exist, just update them in place
			# here we build a list of id's to exclude from removal
			excludedTypes = []
			for xmlNode in nodeArray:
				raName = xmlNode.getAttrValue('name')
				if (raName is None):
					raise ConfigWriterException("Attribute 'name' is required for objects representing type: " + typeName)
				#endIf
				existingAdapter = self._findResourceAdapterByName(raName, scopeId, scopeType)
				if existingAdapter is not None:
					excludedTypes.append(existingAdapter)
				#endIf
			#endIf
			

			# remove all adapters that don't exist in the XML data file
			if (not augment):
				self.myConfigWriter.removeJ2CConfig(scopeType, typeName, scopeId, excludedTypes)
			#endIf
			
			for xmlNode in nodeArray:
				self.LOGGER.debug("processing data from xmlFile: " + str(xmlNode))
				
				resourceAdapterName = xmlNode.getAttrValue('name')
				if (resourceAdapterName is None):
					raise ConfigWriterException("Attribute 'name' is required for objects representing type: " + typeName)
				#endIf
				
				# this should return None for any adapters not in the XML data file
				resourceAdapter = self._findResourceAdapterByName(resourceAdapterName, scopeId, scopeType)
				
				if resourceAdapter is None:
					resourceAdapterRar = xmlNode.getAttrValue('archivePath')
					if (resourceAdapterRar is None):
						raise ConfigWriterException("Attribute 'archivePath' is required for objects representing type: " + typeName)
					#endIf
					J2CResourceAdaptersLogger.log("#######################################################################")
					J2CResourceAdaptersLogger.log('CRWWA0154I',[resourceAdapterName,resourceAdapterRar])
					
					# see if an adapter by this name exists at some other scope
					resourceAdapterSource = self._findResourceAdapterSourceByName(resourceAdapterName)
					
					# in most circumstances we will have found the adapter by name, but if
					# it lives at another scope under a different name, then this should catch it
					if (resourceAdapterSource is None):
						resourceAdapterSource = self._findResourceAdapterByRar(resourceAdapterRar)
					
					if resourceAdapterSource is not None:
						# if rar file already has an adapter associated, copy the config at different scope
						# modify the entry to match the xmlName, and update all the references as per the xmlNode
						J2CResourceAdaptersLogger.log("#######################################################################")
						J2CResourceAdaptersLogger.log('CRWWA0153I',[resourceAdapterName])
						self.LOGGER.trace("AdminTask.copyResourceAdapter(" + resourceAdapterSource + 
										",'[-name '" + resourceAdapterName + "' -scope '" + scopeId + "']')")
						newResourceAdapter = AdminTask.copyResourceAdapter(resourceAdapterSource, 
													'[-name "' + resourceAdapterName + '" -scope "' + scopeId + '"]')
						self.myConfigWriter.modify(newResourceAdapter, xmlNode, [])
						self.myConfigWriter.updateWASReferenceAttributes([xmlNode], scopeId)
					else:
						# if rar file doesn't exist, we cannot manage its config - fail and exit
						J2CResourceAdaptersLogger.log("#######################################################################")
						J2CResourceAdaptersLogger.log('CRWWA0121E', [resourceAdapterName, resourceAdapterRar])
						raise ConfigWriterException("Failed to locate installed RAR file.")
				else:
					# we are now excluding adapters that have only 1 reference to avoid destroying
					if (not augment):
						#update existing adapter
						self.myConfigWriter.modify(resourceAdapter, xmlNode, [])
						self.myConfigWriter.updateWASReferenceAttributes([xmlNode], scopeId)
					else:
						J2CResourceAdaptersLogger.log('CRWWA0155W',[typeName,resourceAdapterName])
					#endIf
				#endIf
			#endFor
		#endFor	
	#endDef
	
	def _findResourceAdapterByName(self, resourceAdapterName, scopeId, scopeType):
		self.LOGGER.traceEnter([resourceAdapterName, scopeId, scopeType])
		resourceAdapters = AdminConfig.list('J2CResourceAdapter', scopeId).split(self.newline)
		for resourceAdapter in resourceAdapters:
			if (len(resourceAdapter) > 0):
				if (AdminHelper.isInScope(scopeType, resourceAdapter)):
					name = AdminConfig.showAttribute(resourceAdapter, 'name')
					if name == resourceAdapterName:
						self.LOGGER.traceExit(str(resourceAdapter))
						return resourceAdapter
					#endIf
				#endIf
			#endIf
		#endFor
		self.LOGGER.traceExit(None)
		return None
	#endDef
	
	def _findResourceAdapterByRar(self, resourceAdapterRar):
		self.LOGGER.traceEnter([resourceAdapterRar])
		resourceAdapters = AdminConfig.list('J2CResourceAdapter').split(self.newline)
		found = ""
		for resourceAdapter in resourceAdapters:
			if (len(resourceAdapter) > 0):
				archivePath = AdminConfig.showAttribute(resourceAdapter, 'archivePath')
				found = found + archivePath + self.newline
				if archivePath == resourceAdapterRar:
					self.LOGGER.traceExit(str(resourceAdapter))
					return resourceAdapter
				#endIf
			#endIf
		#endFor
		J2CResourceAdaptersLogger.log('CRWWA0152I',[found])
		self.LOGGER.traceExit(None)
		return None
	#endDef
	
	def _findResourceAdapterSourceByName(self, resourceAdapterName):
		self.LOGGER.traceEnter([resourceAdapterName])
		resourceAdapters = AdminConfig.list('J2CResourceAdapter').split(self.newline)
		for resourceAdapter in resourceAdapters:
			if (len(resourceAdapter) > 0):
				name = AdminConfig.showAttribute(resourceAdapter, 'name')
				if name == resourceAdapterName:
					self.LOGGER.traceExit(str(resourceAdapter))
					return resourceAdapter
				#endIf
			#endIf
		#endFor
		self.LOGGER.traceExit(None)
		return None
	#endDef
	
#endClass

def export(optDict=None):
	scope = optDict['wasscopetype']
	
	xmlFile = optDict['properties']
#	scriptName = optDict['script_name']
	scopeType=optDict['scope']
	excludedTypes = [optDict['excludedtypes']]
	
	mode = optDict['mode']
	typeNames = [optDict['type']]
	thisMediator = ResourceAdapterMediator()
	marker = optDict['marker']
	
	excludedAttributes = [optDict['excludedattrs']]
	myConfigReader = ConfigReader()
	myConfigReader.setExcludedAttributes(excludedAttributes)
	
	thisMediator.createConfig(scope, scopeType, xmlFile, marker, typeNames, 0)
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'type:;scope:;properties:;nodename:;scopename:;mode:;script_name:' )
	
	# get scope
	scope = AdminHelper.buildScope( optDict )
	
	xmlFile = optDict['properties']
	scriptName = optDict['script_name']
	scopeType=optDict['scope']
	excludedTypes = []
	
	mode = optDict['mode']
	typeNames = ["J2CResourceAdapter"]
	thisMediator = ResourceAdapterMediator()
	marker = "J2CResourceAdapters"
	
	excludedAttributes = ['J2CResourceAdapter.deploymentDescriptor']
	myConfigReader = ConfigReader()
	myConfigReader.setExcludedAttributes(excludedAttributes)
	
	if (mode == MODE_EXECUTE):
	
		#print "Creating resource adapters in scope: " + scope
		J2CResourceAdaptersLogger.log("CRWWA1114I",[scope])
	
		thisMediator.createConfig(scope, scopeType, xmlFile, marker, typeNames, 0)
		AdminHelper.saveAndSyncCell()
	
	elif (mode == MODE_IMPORT):
		#print "Importing resource adapters in scope: " + scope
		J2CResourceAdaptersLogger.log("CRWWA1115I",[scope])
		ConfigMediator.importConfig(scope, scopeType, xmlFile, marker, typeNames, excludedTypes, myConfigReader)
		
	elif (mode == MODE_COMPARE):
		#print "Comparing resource adapters in scope: " + scope
		J2CResourceAdaptersLogger.log("CRWWA1116I",[scope])
		ConfigMediator.compareConfig(scope, scopeType, xmlFile, marker, typeNames, excludedTypes, myConfigReader)
	elif (mode == MODE_AUGMENT):
		#print "Augmenting resource adapters in scope: " + scope
		J2CResourceAdaptersLogger.log("CRWWA1117I",[scope])
		thisMediator.createConfig(scope, scopeType, xmlFile, marker, typeNames, 1)
		AdminHelper.saveAndSyncCell()
		
	else:
		#print "Unsupported MODE supplied: " + mode
		J2CResourceAdaptersLogger.log("CRWWA0008W",[mode])
	#endIf
#endIf
