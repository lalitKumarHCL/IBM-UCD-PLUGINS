'''
Created on Feb 27, 2014

@author: jalva
'''


import java
import traceback
from java.io import File
from java.io import FileFilter
from java.util import HashMap
from java.util import ArrayList
from java.util import Date
from com.ibm.rational.rafw.wsadmin.websphere.config import *
from com.ibm.rational.rafw.wsadmin.websphere.config.xml import *
from com.ibm.rational.rafw.wsadmin.websphere.config.compare import *
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
from com.ibm.rational.rafw.framework.util import Files
from com.ibm.rational.rafw.shared.util import PropertiesUtil

from Logger import _Logger
from ConfigReader import ConfigReader
from ConfigComparor import ConfigComparor
from ServerConfigMediator import ServerConfigMediator
from SystemUtils import SystemUtils

import sys
import Globals
import copy

sys.path.append('product/lib/jython/wsadmin_lib')
#Append scripts to sys.path

logger = _Logger("QuickExport", MessageManager.RB_WEBSPHERE_WAS)

newline = java.lang.System.getProperty("line.separator")

class QuickExport:
	
	def __init__(self, scopelist, environment, rafhome):
		self.LOGGER = _Logger("QuickExport", MessageManager.RB_WEBSPHERE_WAS)	
		tmplist = scopelist.split(',')
		self.scopelist = []
		for scope in tmplist:
			if scope != '':
				self.scopelist.append(rafhome + "/user/environments/" + environment + "/cells/" + scope)
			#endIf
		#endFor
		self.actionscopes = None
		self.scopePropFiles = ['configure.properties', 'install.properties'] 
	#endDef
	
	def getScopeName(self, scope):
		scopePath = scope.split('/')
		scopeName = scopePath[len(scopePath)-1]
		return scopeName
	#endDef

	def getNodeName(self, scope, type):
		scopeName = ""
		if type == 'Server':
			scopePath = scope.split('/')
			scopeName = scopePath[len(scopePath)-3]
		#endIf
		return scopeName
	#endDef
	
	def getCellName(self, scope, type):
		scopeName = ""
		scopePath = scope.split('/')
		if type == 'Server':
			scopeName = scopePath[len(scopePath)-5]
		elif type == 'Cluster' or type == "Node":
			scopeName = scopePath[len(scopePath)-3]
		#endIf
		return scopeName
	#endDef
	
	def getScopeType(self, scope):
		scopePath = scope.split('/')
		scopeType = scopePath[len(scopePath)-2]
		if scopeType.endswith('s'):
			scopeType = scopeType[0:len(scopeType)-1]
		return scopeType.capitalize()
	#endDef
	
	def getActionScopes(self):
		if self.actionscopes==None:
			self.actionscopes = []
			for scope in self.scopelist:
				#if we narrowed down the possible scope to process earlier, then "" will be the first scope
				if scope== "":
					continue
				#Check if windows added \: to the path while saving to props file, if so strip it out.
				if scope.find("\:"):
					scope = scope.replace("\:",":")
				#endif
				aScope = ActionScope()
				aScope.setPath(scope)
				aScope.setName(self.getScopeName(scope))
				aScope.setType(self.getScopeType(scope))
				aScope.setNodeName(self.getNodeName(scope, aScope.getType()))
				aScope.setCellName(self.getCellName(scope, aScope.getType()))
				scopeProps = PropertiesUtil()
				try:
					scopeProps.load(str(scope) + "/scope.properties")
					aScope.setSubType(scopeProps.getProperty("SCOPE_DATA_TYPE"))
				except Exception, e:
					print str(e)
					logger.error("Exception" + str(e))
				#endTry
				'''
				We are currently skipping IHS cause that really causes issues with 
				quick export
				'''
				if aScope.getSubType() != "IHS": 
					self.actionscopes.append(aScope)
				#endIf
				#print aScope.printObject()
			#endFor
		#endIf
		return self.actionscopes
	#endDef

	def executeServer(self, scope, ignoreDifferences, xmlFile):
		messageRecorder = MessageRecorder();
		configMediator = ServerConfigMediator(messageRecorder,"ALL",version)
		configMediator.setIgnoreConfigDifferences(ignoreDifferences)
		
		serverIds = []
		scopeType = str(scope.getType()).lower()
		
		if scope.getType()=="Cluster" or scope.getType()=="Cell":
			serverIds = configMediator.findServersInScope(scope.getName(), scopeType, None)
		else:
			serverIds = [AdminConfig.getid(scope.getWASName())]
		#endIf
		configMediator.executeAllConfigTypes(serverIds, xmlFile, scopeType)
		#return configMediator.readAllConfigTypes(serverIds, scopeType, 1, None)
	#endDef
	
	def getTimeDifference(self, startTime, endTime):
		totalMillis = endTime - startTime
		deltaSecs = totalMillis / 1000 % 60
		deltaMins = totalMillis / 1000 / 60 % 60
		deltaHours = totalMillis / 1000 /60/60%60
		
		seconds = MessageManager.getMessage(MessageManager.RB_WEBSPHERE_WAS, 'CRWWA4024I')
		minutes = MessageManager.getMessage(MessageManager.RB_WEBSPHERE_WAS, 'CRWWA4025I')
		hours = MessageManager.getMessage(MessageManager.RB_WEBSPHERE_WAS, 'CRWWA4026I')
		return  str(deltaHours) + " " + hours + " " + \
				str(deltaMins) + " " + minutes + " " + \
				str(deltaSecs) + " " + seconds
	#endDef
	
	def getJythonFiles(self, directory):
		jythonFiles = []
		myDir = File(directory)
		files = myDir.listFiles()
		for f in files:
			fileName = java.lang.String(f.getName())
			if fileName.endsWith(".py"):
				jythonFiles.append(str(f.getAbsolutePath()))
			#endIf
		#endFor
		return jythonFiles
	#endDef
	
	def processCustomFiles(self, actionScopes, optDict, isPre, shouldFail = 1):
		if isPre:
			logger.log("CRWWA4037I")
		else:
			logger.log("CRWWA4038I")
		#endIf
		for scope in actionScopes:
			custDict = self.createCustomDict(optDict, scope)
			jythonFiles = self.getJythonFiles(scope.getPath())
			for jf in jythonFiles:
				file = File(jf)
				jythonScript = file.getName().split('.')[0]
				try:
					#first lets add the script path to our system path (equivalent to classpath
					sys.path.append(scope.getPath())
					#now lets import the jython script
					logger.log("CRWWA4036I", [jf,scope.getName()])
					#CRWWA4036I Calling custom jython file {0} against scope {1}
					if isPre:
						__import__(jythonScript, globals(), locals(),[], 1).preProcess(custDict)
					else:
						__import__(jythonScript, globals(), locals(),[], 1).postProcess(custDict)
				except Exception, e:
					logger.error("Exception: " + str(e))
					traceback.print_tb(sys.exc_info()[2])
					if (shouldFail):
						raise e
					#endIf
				#endTry
				idx = sys.path.index(scope.getPath())
				foobar = sys.path.pop(idx)
			#endFor
		#endFor
		logger.log("CRWWA4039I")
		logger.log("newline")
	#endDef
	
	def createCustomDict(self, optDict, scope):
		# always execute
		tmpDict = {}
		for key in ['skipserver','serveronly','installtype','rafhome','mode']:
			if key in optDict.keys():
				if key == 'rafhome':
					tmpDict['pluginhome'] = optDict[key]
				else:
					tmpDict[key] = optDict[key]
				#endIf
			#endIf
		#endfor

		tmpDict['scopepath'] =  scope.getPath()
		
		#Lets try to add a bunch of extra properties in there from configure/install.props files
		for file in self.scopePropFiles:
			scopeProps = PropertiesUtil()
			try:
				scopeProps.load(str(scope.getPath()) + "/" + file)
				for key in scopeProps.keySet():
					tmpDict[key] = scopeProps.getProperty(key)
				#endFor
			except :
				'''
				lets do nothing cause the scope doesnt have this file...lets just try the next one
				Also, have this assignment cause otherwise it doesnt really do nothing and fails which
				is not what we want
				'''
				#logger.debug(message, args)
			#endTry
		#endFor
		return tmpDict
	#endDef
#endClass

optDict, args = SystemUtils.getopt( sys.argv, 'scopelist:;mode:;version:;wveversion:;rafhome:;installtype:;serveronly:;skipserver:;environment:' )	
if ( optDict['mode'] == 'execute'):
	skipServer = optDict['skipserver']
	serverOnly = optDict['serveronly']
	scopeListProps = PropertiesUtil()
	scopeList = ""
	try:
		scopeListProps.load(str(optDict['scopelist']))
		# list of fully qualified paths within the user tree separated by comma
		scopelist = scopeListProps.getProperty("SCOPE_LIST")
	except Exception, e:
		print str(e)
		logger.error("Exception" + str(e))
	#endTry
	
	rafhome = optDict['rafhome']
	environment = optDict['environment']
	installType=optDict['installtype']
	
	# always execute
	mode = optDict['mode']
	
	# 61,70,80,85
	#cast the version from a string to an int...so it gets compared correctly later on.
	version = int(optDict['version'])

	wveversion = int(optDict['wveversion'])
	if (wveversion == 0) :
		wveversion = None
	#endif
	
	qe = QuickExport(scopelist, environment, rafhome)
	
	typeMap = DataTypeMap()
	actionScopes = qe.getActionScopes()
	cellScope = None
	clusterServerIds = {}
	
	tmpdict = copy.deepcopy(optDict)
	
	'''
	Calling custom jython before running our export code
	'''
	qe.processCustomFiles(actionScopes, optDict, 1)
	
	
	#We only want to run this code if serverOnly is not true...aka run other config types as well
	if serverOnly != "true":
		for mapping in typeMap.getMappings():
			type = mapping.getType()
			if not type :
				continue
			elif (wveversion != None and wveversion < mapping.getWveVersion()) :
				logger.log('CRWWA4040I', [wasType, str(wveversion)])		
				continue
			elif (version < mapping.getVersion() and wveversion == None) :
				logger.log('CRWWA4027I', [wasType, str(version)])
				continue
			elif (len(mapping.getInstallType()) != 0) and (not installType == mapping.getInstallType()) :
				logger.log('CRWWA4028I', [type, installType])
				continue
			#endIF
		
			excludedTypes = []
			if mapping.getExcludedTypes() != None and mapping.getExcludedTypes() != '':
				excludedTypes = mapping.getExcludedTypes().split(',')
			#endIf
			
			excludedAttrs = []
			if mapping.getExcludedAttributes() != None:
				excludedAttrs = mapping.getExcludedAttributes().split(',')
			#endIf
			supportedScopes = mapping.getSupportedScopes()
			if len(supportedScopes) == 0:
				supportedScopes = None
			#endIf
				
			scopeDataType = mapping.getScopeDataType()
			if scopeDataType == '':
				scopeDataType = None
			#endif
		
			types = type.split(',')
			for wasType in types:
				for scope in actionScopes:
					#printing newline to separate config logs
					isDataTypeSupported = scopeDataType == None or (scopeDataType != None and scope.getSubType() == scopeDataType)
					isScopeSupported = supportedScopes == None or (supportedScopes != None and scope.getType().lower() in supportedScopes)
					if isScopeSupported and isDataTypeSupported:
						file = mapping.getFile()
						tmpdict['properties'] = scope.getPath() + "/" + file
						xmlFile = File(tmpdict['properties'])
						#if the xml file does not exist, do not try to do anything as export will fail due
						#to the lack of an xml file.  lets just keep going
						if not xmlFile.isFile():
							logger.log("CRWWA4035I",[str(xmlFile.getAbsolutePath()), wasType])
							continue
						startTime = Date().getTime()
						jythonScript=mapping.getJythonScript()
						jythonPath=mapping.getJythonPath()
						#first lets add the script path to our system path (equivalent to classpath
						sys.path.append(Globals.getInstallRoot() + "/" + jythonPath)
						#now lets import the jython script
						_tempVar = __import__(jythonScript, globals(), locals(),[], -1)
						#now lets call the export function which they need to provide....need to provide parameters
						#so that the export function has things to run against...like mode, xml file, etc.
						#by default tmpdict always has: mode, scopelist, version, rafhome, installtype
						tmpdict['scope'] = scope.getType().lower()
						tmpdict['scopename'] = scope.getName()
						tmpdict['wasscopetype'] = scope.getWASName()
						tmpdict['scopeHome'] = scope.getPath()
						file = mapping.getFile()
						tmpdict['properties'] = scope.getPath() + "/" + file
						tmpdict['type']= wasType
						tmpdict['marker'] = mapping.getParentNode().split("_")[1]
						tmpdict['excludedtypes'] = excludedTypes
						tmpdict['excludedattrs'] = excludedAttrs
						
						try:
							#CRWWA4020I Exporting {0}s at {1} Scope
							logger.log("CRWWA4022I", [wasType,scope.getWASName()])
							_tempVar.export(tmpdict)
							endTime = Date().getTime()
							logger.log("CRWWA4023I",[wasType, qe.getTimeDifference(startTime, endTime)])
						except Exception, e:
							logger.error("Exception: " + str(e))
							traceback.print_tb(sys.exc_info()[2])
							raise e
						#endTry
					#endIf
				#endFor
			#endFor
		#endFor
	else:
		#Skipping export of non-server data as requested
		logger.log("CRWWA4033I")
	#endIf
	
	#Only run the server code if we're not skipping servers
	if skipServer != "true":
		startTime = Date().getTime()
		for scope in actionScopes:
			if scope.getType()=="Server" or (scope.getType()=="Cluster" and scope.getSubType() != "DYNAMIC_WAS"):
				#The config file for server data is always server.xml
				file = "server.xml"
				xmlFile = File(scope.getPath() + "/" + file)
				#if the xml file does not exist, do not try to do anything as export will fail due
				#to the lack of an xml file.  lets just keep going
				if not xmlFile.isFile():
					continue
				#endIf
				qe.executeServer(scope, 1, xmlFile.getAbsolutePath())
			#endIf
		#endFor
		endTime = Date().getTime()
		logger.log("CRWWA4032I",[wasType, qe.getTimeDifference(startTime, endTime)])
	else:
		#Skipping export of server data as requested
		logger.log("CRWWA4034I")
	#endIf
	
	'''
	Calling custom jython after running our export code
	'''
	qe.processCustomFiles(actionScopes, optDict, 0)
	
	
	'''
	Now that everything has run and was successful (otherwise we should have thrown an exception)
	lets save and sync our cell
	'''
	#This saves assuming there is modified data in wsadmin
	AdminHelper.saveAndSyncCell()
#endIf

