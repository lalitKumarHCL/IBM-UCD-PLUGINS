"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: variables.py
	
	This script is to create shared libraries for the specified scope.
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py 
		-f variables.py 
		-scope ${SCOPE} -scopename <scope name> 
		-properties <name space bindings properties file> 
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java

from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from ConfigWriter import ConfigWriterException 
from ConfigWriter import ConfigWriter
from ConfigMediator import *
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

variablesLogger = _Logger("variables", MessageManager.RB_WEBSPHERE_WAS)

from ConfigValidator import ConfigValidator

class VariableValidator(ConfigValidator):
	
	def __init__(self):
		ConfigValidator.__init__(self)
		self.uniqueAttributeName = "symbolicName"
	#endDef
	
#endClass

def export(optDict=None):
	scopeType=optDict['scope']
	scope = optDict['wasscopetype']
	xmlFile = optDict['properties'] 
	mode = optDict['mode']
	typeNames=[optDict['type']]
	marker = optDict['marker']
	scopeid = AdminConfig.getid( scope+"VariableMap:/" )
	
	ConfigMediator.createConfigUsingParentId(scopeid, scopeType, xmlFile, marker, typeNames)
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'type:;scope:;properties:;nodename:;scopename:;mode:' )
	
	# get scope
	scopeType=optDict['scope']
	scope = AdminHelper.buildScope( optDict )
	xmlFile = optDict['properties'] 
	mode = optDict['mode']
	typeNames=["VariableSubstitutionEntry"]
	marker = "variables"
	
	if (mode == MODE_EXECUTE):
		##print "Creating variables in scope: " + scope
		variablesLogger.log("CRWWA2075I",[scope])
		scopeid = AdminConfig.getid( scope+"VariableMap:/" )
		ConfigMediator.createConfigUsingParentId(scopeid, scopeType, xmlFile, marker, typeNames)
		AdminHelper.saveAndSyncCell()
	elif (mode == MODE_AUGMENT):
		##print "Augmenting variables in scope: " + scope
		variablesLogger.log("CRWSE1680I",[scope])
		scopeid = AdminConfig.getid( scope+"VariableMap:/" )
		ConfigMediator.augmentConfigUsingParentId(scopeid, scopeType, xmlFile, marker, typeNames, [], VariableValidator())
		AdminHelper.saveAndSyncCell()
	elif (mode == MODE_IMPORT):
		#print "Importing variables in scope: " + scope
		variablesLogger.log("CRWWA2077I",[scope])
		ConfigMediator.importConfig(scope, scopeType, xmlFile, marker, typeNames)
	
	elif (mode == MODE_COMPARE):
		##print "Comparing variables in RAFW and WAS in scope: " + scope
		variablesLogger.log("CRWWA2078I",[scope])
		ConfigMediator.compareConfig(scope, scopeType, xmlFile, marker, typeNames)
	
	else:
		##print "Unsupported MODE supplied: " + mode
		variablesLogger.log("CRWWA0008W",[mode])
	#endIf
#endIf
