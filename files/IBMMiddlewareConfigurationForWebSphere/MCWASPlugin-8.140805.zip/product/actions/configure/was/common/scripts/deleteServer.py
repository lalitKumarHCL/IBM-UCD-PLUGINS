"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: deleteServer.py
	
	This script is to delete an server on a node.
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f deleteServer.py -servername <server name> -nodename <node name> 
		-servername <server name>: specify the name of the server to be deleted
		-nodename <node name>: specify the node name of the server to be deleted 
"""

from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

import sys

# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'servername:;nodename:;template:' )

cellname = AdminControl.getCell()
nodename = optDict['nodename']
servername = optDict['servername']

# Check if it is a valid node
node = AdminConfig.getid( '/Cell:' + cellname + '/Node:' + nodename + '/' )

if node == "":
	raise "\ndeleteServer.py: Error -- Invalid node name: " + nodename 
#endIf

# Check if a server by this name already existing on the node
server = AdminConfig.getid("/Cell:" + cellname + "/Node:" + nodename + "/Server:" + servername + "/")

if server == "":
	raise "\ndeleteServer.py: Warn -- Server " + servername + " does not exist on node " + nodename
#endIf

AdminConfig.remove(server)

AdminHelper.saveAndSyncCell()

#end main		


