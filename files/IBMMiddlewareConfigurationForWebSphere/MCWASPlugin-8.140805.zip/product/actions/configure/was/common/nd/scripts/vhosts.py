"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: vhosts.py
	
	This script is to create vhosts
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py 
		-f variables.py 
		-scope ${SCOPE} -scopename <scope name> 
		-properties <name space bindings properties file> 
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java
import Globals

from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from ConfigWriter import ConfigWriterException 
from ConfigWriter import ConfigWriter
from ConfigValidator import ConfigValidator
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

class Vhosts:
	
	def __init__(self, scopeId, scopeType, xmlFile, marker, typeNames):
		self.LOGGER = _Logger("vhosts", MessageManager.RB_WEBSPHERE_WAS)
		self.xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		self.xmlProp = self.xmlProp.findRAFWContainerNode(marker)
		self.scopeId = scopeId
		self.scopeType = scopeType
		self.typeNames = typeNames
		
		self.myConfigWriter = ConfigWriter();
		self.configValidator = ConfigValidator()
		
	#endDef
	
	def createVhosts(self):
	
		if (len(self.scopeId) == 0):
			msg = "unable to find parent scope: " + self.scopeId + " Cannot write WAS config."
			self.LOGGER.error(msg);
			raise ConfigWriterException(msg)
		#endIf
		
		uniqueAttrName = "name"
		
		for typeName in self.typeNames:
			self.myConfigWriter.removeExistingConfig(self.scopeType, typeName, self.scopeId)
			nodeArray = self.xmlProp.getFilteredNodeArray(typeName)	
			for xmlNode in nodeArray:
				print "Info: Creating " + typeName + " with " + uniqueAttrName + " " + xmlNode.getAttrValue(uniqueAttrName, Globals.ATTRIBUTE_VALUE_MISSING)
				vHostId = self.myConfigWriter.createEntity(xmlNode, scopeId)
				self.myConfigWriter.updateWASChildren(xmlNode, vHostId, [])
			#endFor
		#endFor
	#endDef
	
	def augmentVhosts(self):
		
		if (len(self.scopeId) == 0):
			msg = "unable to find parent scope: " + self.scopeId + " Cannot write WAS config."
			self.LOGGER.error(msg);
			raise ConfigWriterException(msg)
		#endIf
		
		for typeName in self.typeNames:
			nodeArray = self.xmlProp.getFilteredNodeArray(typeName)	
			for xmlNode in nodeArray:
				childId = self.configValidator.validate2(xmlNode, self.scopeId)
				uniqueAttrName = self.configValidator.getUniqueAttributeName()
				uniqueAttrValueDisplay = xmlNode.getAttrValue(uniqueAttrName, Globals.ATTRIBUTE_VALUE_MISSING)
				if (childId is None):
					print "Info: Creating " + typeName + " with " + uniqueAttrName + " " + uniqueAttrValueDisplay
					vHostId = self.myConfigWriter.createEntity(xmlNode, scopeId)
					self.myConfigWriter.updateWASChildren(xmlNode, vHostId, [])
				else:
					if (SystemUtils.updateOnAugment()):
						self.myConfigWriter.modify(childId, xmlNode)
					else:
						print ("Warning: " + typeName + " with " + uniqueAttrName + " " 
							+ uniqueAttrValueDisplay + " will not be created.")
				#endIf
			#endFor
		#endFor
	#endDef
#endClass
 
def export(optDict=None):
	global scopeId
	scopeType=optDict['scope']
	scope = optDict['wasscopetype']
	xmlFile = optDict['properties'] 
	mode = optDict['mode']
	typeNames=[optDict['type']]
	marker = optDict['marker']
	
	scopeId = AdminConfig.getid( scope )
	vhosts = Vhosts(scopeId, scopeType, xmlFile, marker, typeNames)
	vhosts.createVhosts()
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'type:;scope:;properties:;nodename:;scopename:;mode:' )
	
	# get scope
	scopeType=optDict['scope']
	scope = AdminHelper.buildScope( optDict )
	xmlFile = optDict['properties'] 
	mode = optDict['mode']
	typeNames=["VirtualHost"]
	marker = "vhosts"
	
	if (mode == MODE_EXECUTE):
		print "Creating virtual hosts in scope: " + scope
		scopeId = AdminConfig.getid( scope )
		vhosts = Vhosts(scopeId, scopeType, xmlFile, marker, typeNames)
		vhosts.createVhosts()
		AdminHelper.saveAndSyncCell()
	
	elif (mode == MODE_AUGMENT):
		print "Augmenting virtual hosts in scope: " + scope
		scopeId = AdminConfig.getid( scope )
		vhosts = Vhosts(scopeId, scopeType, xmlFile, marker, typeNames)
		vhosts.augmentVhosts()
		AdminHelper.saveAndSyncCell()
	
	elif (mode == MODE_IMPORT):
		print "Importing virtual hosts in scope: " + scope
		ConfigMediator.importConfig(scope, scopeType, xmlFile, marker, typeNames)
	
	elif (mode == MODE_COMPARE):
		print "Comparing virtual hosts in RAFW and WAS in scope: " + scope
		ConfigMediator.compareConfig(scope, scopeType, xmlFile, marker, typeNames)
	
	else:
		print "Unsupported MODE supplied: " + mode
	#endIf
#endIf
