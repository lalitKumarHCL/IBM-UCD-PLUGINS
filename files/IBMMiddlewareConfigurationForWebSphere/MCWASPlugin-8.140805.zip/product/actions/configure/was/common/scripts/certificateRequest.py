"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: certificateRequest.py
"""

import java.util as util
import java.io as javaio
from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager


class certificateRequest:
    """ creates a self-signed certificate in the specified key store """
    def createCertificateRequest(self, keyStoreName, certificateAlias, certificateSize, certificateCommonName, certificateRequestFilePath, keyStoreScope):
        # required parameters 
        #keyStoreName
        commandOptions = ['-keyStoreName ']
        commandOptions.append(keyStoreName)
        #certificateAlias
        commandOptions.append('-certificateAlias')
        commandOptions.append(certificateAlias)
        #commandOptions = self.appendCommandOptions(commandOptions, '-certificateVersion')
        #certificateSize
        commandOptions.append('-certificateSize')
        commandOptions.append(certificateSize)
        #certificateCommonName
        commandOptions.append('-certificateCommonName')
        commandOptions.append(certificateCommonName)
        commandOptions.append('-certificateRequestFilePath')
        commandOptions.append(certificateRequestFilePath)
        
        # optional parameters
        if(keyStoreScope != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(keyStoreScope)
        if(self.getProperty('Security.Cert.CertificateOrganization') != None):
            commandOptions.append('-certificateOrganization')
            commandOptions.append(self.getProperty('Security.Cert.CertificateOrganization'))
        if(self.getProperty('Security.Cert.CertificateOrganizationalUnit') != None):
            commandOptions.append('-certificateOrganizationalUnit')
            commandOptions.append(self.getProperty('Security.Cert.CertificateOrganizationalUnit'))
        if(self.getProperty('Security.Cert.CertificateLocality') != None):
            commandOptions.append('-certificateLocality')
            commandOptions.append(self.getProperty('Security.Cert.CertificateLocality'))
        if(self.getProperty('Security.Cert.CertificateState') != None):
            commandOptions.append('-certificateState')
            commandOptions.append(self.getProperty('Security.Cert.CertificateState'))
        if(self.getProperty('Security.Cert.CertificateZip') != None):
            commandOptions.append('-certificateZip')
            commandOptions.append(self.getProperty('Security.Cert.CertificateZip'))
        if(self.getProperty('Security.Cert.CertificateCountry') != None):
            commandOptions.append('-certificateCountry')
            commandOptions.append(self.getProperty('Security.Cert.CertificateCountry'))
        if(self.getProperty('Security.Cert.CertificateValidDays') != None):
            commandOptions.append('-certificateValidDays')
            commandOptions.append(self.getProperty('Security.Cert.CertificateValidDays'))
        
        for option in commandOptions:
            certificateRequestLogger.debug(option)
            
        # Create certificate request if it does not already exist
        certificateRequest = self.getCertificateRequest(keyStoreName, certificateAlias, keyStoreScope)
        if(certificateRequest == None):
            AdminTask.createCertificateRequest(commandOptions)
        else:
            certificateRequestLogger.error("Certificate alias: " + certificateAlias + " already exists in keyStore.")
    
    """ deletes a self-signed certificate from the specified key store """
    def deleteCertificateRequest(self, keyStoreName, certificateAlias, keyStoreScope):
        # required parameters 
        #keyStoreName
        commandOptions = ['-keyStoreName ']
        commandOptions.append(keyStoreName)
        #certificateAlias
        commandOptions.append('-certificateAlias')
        commandOptions.append(certificateAlias)
        
        # optional parameters
        if(keyStoreScope != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(keyStoreScope)
        
        #certificateRequestLogger.info('AdminTask.deleteCertificateRequest(' + commandOptions +')')
        # Delete certificate if it exists
        certificateRequest = self.getCertificateRequest(keyStoreName, certificateAlias, keyStoreScope)
        if(certificateRequest != None):
            AdminTask.deleteCertificateRequest(commandOptions)
        else:
            certificateRequestLogger.info('Certificate request not in keystore.')
        
    def extractCertificateRequest(self, keyStoreName, certificateAlias, certificateRequestFilePath, keyStoreScope):
        # required parameters 
        #keyStoreName
        commandOptions = ['-keyStoreName ']
        commandOptions.append(keyStoreName)
        #certificateAlias
        commandOptions.append('-certificateAlias')
        commandOptions.append(certificateAlias)
        commandOptions.append('-certificateRequestFilePath')
        commandOptions.append(certificateRequestFilePath)
        
        # optional parameters
        if(keyStoreScope != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(keyStoreScope)
        
        #certificateRequestLogger.info('AdminTask.extractCertificateRequest(' + commandOptions +')')
        # Extract certificate request if it exists
        certificateRequest = self.getCertificateRequest(keyStoreName, certificateAlias, keyStoreScope)
        if(certificateRequest != None):
            AdminTask.extractCertificateRequest(commandOptions)
        else:
            certificateRequestLogger.info('Certificate request not in keystore.')
        
    def getCertificateRequest(self, keyStoreName, certificateAlias, keyStoreScope):
        # required parameters 
        #keyStoreName
        commandOptions = ['-keyStoreName ']
        commandOptions.append(keyStoreName)
        #certificateAlias
        commandOptions.append('-certificateAlias')
        commandOptions.append(certificateAlias)
        
        # optional parameters
        if(keyStoreScope != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(keyStoreScope)
        
        #certificateRequestLogger.info('AdminTask.getCertificateRequest(' + commandOptions +')')
        certificateRequest = None
        try:
            certificateRequest = AdminTask.getCertificateRequest(commandOptions)
        except:
            certificateRequestLogger.info("Certificate request " + certificateAlias + " does not exist in keyStore: " + keyStoreName)
        return certificateRequest
        
    """ list personal certificates in the specified key store """
    def listCertificateRequests(self, keyStoreName):
        # required parameters
        commandOptions = '-keyStoreName ' + keyStoreName
        
        # optional parameters
        if(self.getProperty('Security.Cert.KeyStoreScope') != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(self.getProperty('Security.Cert.KeyStoreScope'))
        
        #certificateRequestLogger.info('AdminTask.listCertificateRequest(' + commandOptions +')')
        return AdminTask.listCertificateRequest(commandOptions)

        
    def appendCommandOptions(self, commandString, command, key):
        certificateRequestLogger.debug("commandString: " + commandString + " command: " + command + " key: " + key)
        value = self.getProperty(key)
        
        if(value == None):
            return commandString          
        else:
            commandString = commandString + ' ' + command + ' ' + thisCertificateRequest.getProperty(key)
            return commandString
    
    def getProperty(self, key):
        value = properties.get(key)
        if(value == None):
            return
        else:
            return value
        
    def readProperties(self, aFile):
        certificateRequestLogger.info("Reading certificate properties file.")
        properties = util.Properties()
        propertiesFileInputStream =javaio.FileInputStream(aFile)
        properties.load(propertiesFileInputStream)
        return properties
        
#endClass

# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'type:;scope:;properties:;scopename:;mode:;action:;cellName:;nodeName:' )

# get scope
scope = AdminHelper.buildScope( optDict )
xmlFile = optDict['properties'] 
scopeType = optDict['scope']
action = optDict['action']
mode = optDict['mode']
cellName = optDict['cellName']
nodeName = optDict['nodeName']

certificateRequestLogger = _Logger("certificateRequest", MessageManager.RB_WEBSPHERE_WAS)
thisCertificateRequest = certificateRequest()

properties = thisCertificateRequest.readProperties(xmlFile)

keyStoreName = properties.get('Security.Cert.KeyStoreName')
certificateAlias = properties.get('Security.Cert.CertificateAlias')
keyStoreScope = properties.get('Security.Cert.KeyStoreScope')

if(mode == MODE_EXECUTE):
    if(action == "CREATE_CERTIFICATE_REQUEST"):
        certificateCommonName = properties.get('Security.Cert.CertificateCommonName')
        certificateSize = properties.get('Security.Cert.CertificateSize')
        certificateRequestFilePath = properties.get('Security.Cert.CertificateRequestFilePath')
        thisCertificateRequest.createCertificateRequest(keyStoreName, certificateAlias, certificateSize, certificateCommonName, certificateRequestFilePath, keyStoreScope)
    elif(action == "DELETE_CERTIFICATE_REQUEST"):
        thisCertificateRequest.deleteCertificateRequest(keyStoreName, certificateAlias, keyStoreScope)
    elif(action == "EXTRACT_CERTIFICATE_REQUEST"):
        certificateRequestFilePath = properties.get('Security.Cert.CertificateRequestFilePath')
        thisCertificateRequest.extractCertificateRequest(keyStoreName, certificateAlias, certificateRequestFilePath, keyStoreScope)
    else:
       # print "Unsupported ACTION supplied: %s " % optDict['action']
        logger.log("CRWWA5000I", [optDict['action']])
    AdminHelper.saveAndSyncCell()
else:
    	#print "Unsupported MODE supplied: %s " % optDict['mode']
    	 logger.log("CRWWA5001I", [optDict['action']])