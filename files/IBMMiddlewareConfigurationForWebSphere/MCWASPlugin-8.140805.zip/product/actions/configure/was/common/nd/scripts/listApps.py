"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: listApps.py
	
	TODO: description
"""


import sys
import java.lang.System as Sys

print "{"
for app in AdminApp.list().split( newline ):
	if (len(app) > 0):
		print "\t'%s' : { " % (app)
		for option in AdminApp.options( app ).split( newline ):
			print "\t\t'%s' :  '%s'," % (option,1)
		#endFor
		for module in AdminApp.listModules( app ).split( newline ):
			print "\t\t'%s' :  '%s'," % (module,1)
		#endFor
		print "\t},"
	#endIf
#endFor
print "}"
