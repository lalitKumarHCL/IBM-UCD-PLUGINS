from utilities import Util;
input = [];
output = [];
input.append([['foo','bar'],['ball','baz']])
output.append("""[ ["foo" "bar"] ["ball" "baz"] ]""");

input.append([['foo,bar', 'foo,bar'],['ballbaz','ball"baz']]);
output.append("""[ ["foo,bar" "foo,bar"] ["ballbaz" 'ball"baz'] ]""")

input.append([['foo,bar', 'foo,bar'],["ballbaz","ball'baz"]]);
output.append("""[ ["foo,bar" "foo,bar"] ["ballbaz" "ball'baz"] ]""")

input.append([["foo",['bar','baz','bal']]]);
output.append("""[ ['foo' [bar baz bal]]]""")

input.append([["description","Built-in Relational Resource Adapter for WebSphere Persistence"],["name","WebSphere Relational Resource Adapter"],["deploymentDescriptor",[["vendorName","kensie"]]]]);
output.append("""[ ['description' 'Built-in Relational Resource Adapter for WebSphere Persistence'] ['name' 'WebSphere Relational Resource Adapter'] ['deploymentDescriptor' [['vendorName' 'kensie']]]]""");

for x in range(len(input)):
  args = input[x];
  expected = output[x];
  print "Running test %s" % x;
  print args;
  result = Util._genStringFromProperties(args);
  if result != expected:
    print "Expected != Result";
    print expected;
    print result;