/**
* Licensed Materials - Property of IBM* and/or HCL**
* IBM UrbanCode Deploy
* (c) Copyright IBM Corporation 2011, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/

import com.urbancode.air.AirPluginTool;
import com.ibm.rational.air.plugin.worklight.Util;
import com.ibm.rational.air.plugin.worklight.V8Util;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
final def props = apTool.getStepProperties();

def serverpath = props['serverpath']
def runtime = props['runtime']
def wlappName = props['wlappName']
def env = props['environment']
def version = props['version']
def worklightAntJar = props['worklightAntJar'].trim()
def user = props['user']
def password = props['password']
boolean secure = Boolean.parseBoolean(props['secure']?: "true")

try {
    println "Deleting the Worklight application with the following properties:"
    println "Server Path: ${serverpath}"
    println "Worklight application: ${wlappName}"
    println "Worklight Ant Deployer JAR Path: ${worklightAntJar}"

    File worklightAntJarFile
    if (worklightAntJar) {
        worklightAntJarFile = new File(worklightAntJar)
        if(!worklightAntJarFile.exists() || !worklightAntJarFile.isFile() ||
            !Util.isWorklightDeployerAntJar(worklightAntJarFile)) {
            println "Error: The path to the Worklight Ant Deployer JAR file is invalid: " +
                    "${worklightAntJarFile.getCanonicalPath()}. Change the value of the " +
                    "Worklight Ant JAR File Path attribute to the path to the Worklight " +
                    "Ant Deployer JAR file. For example, use " +
                    "/opt/IBM/Worklight/WorklightServer/worklight-ant-deployer.jar."
            System.exit(-1)
        }
    } else {
        println "[Info] The Worklight Jar is not specified. Connecting to MobileFirst v8 using the REST client."
    }

    def serverVersion = Util.determineServerVersion(worklightAntJarFile, serverpath, user,
        password, secure);
    if ( serverVersion == Util.WL_SERVER_62  ||
         serverVersion == Util.WL_SERVER_63  ||
         serverVersion == Util.WL_SERVER_70  ||
         serverVersion == Util.WL_SERVER_71
    ) {
        def ant = Util.getWLADMAnt(worklightAntJarFile);
        ant.wladm ( url:serverpath, user:user, password:password, secure:secure) {
            'delete-app' ( runtime:runtime, name:wlappName )
        }
    } else if ( serverVersion == Util.WL_SERVER_80 ) {
        if (!env) {
            println "[Error] The Application environment property must be specified on MobileFirst v8+ platforms."
            System.exit(-1)
        }
        if (!version) {
            println "[Error] The Application version property must be specified on MobileFirst v8+ platforms."
            System.exit(-1)
        }
        new V8Util(serverpath,user,password).deleteApplication(runtime, wlappName, env,
                    version, "false", null)
    } else {
        if(serverVersion) {
            println "Error: The Worklight Server version is not supported by this step.";
        } else {
            println "Error: The Worklight Server version could not be determined or there " +
                "is a mismatch between the Worklight Ant Deployer JAR and the server.";
            println "Explanation: This error can occur if the Worklight Server Path specified " +
                "in the Server Path attribute is not correct or the path to the Worklight Ant " +
                "Deployer JAR specified in the Worklight Ant JAR File Path attribute is not " +
                "correct.";
            println "User response: Verify the path specified by the Server Path attribute is " +
                "correct. For example, use http://localhost:9080/worklight on Worklight " +
                "6.0 or 6.1 Servers, or https://localhost:9443/worklightadmin on Worklight " +
                "6.2 Servers. Verify the JAR file specified in the Worklight Ant JAR File " +
                "Path attribute uses the JAR from the corresponding Worklight Server. For " +
                "example, use /opt/IBM/Worklight/WorklightServer/worklight-ant-deployer.jar.";
        }
        System.exit(-1)
    }
} catch (Exception e) {
    println "An error occurred while deleting the Worklight application: ${e.message}"
    System.exit(-1)
}

println "The Delete Worklight Application from Worklight Server step completed successfully."
System.exit(0)
