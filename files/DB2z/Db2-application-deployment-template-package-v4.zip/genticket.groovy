/*****************************************************************************/
/*                                                                           */
/* Licensed Materials - Property of IBM                                      */
/*                                                                           */
/* (C) Copyright IBM Corp. 2018. All Rights Reserved.                        */
/*                                                                           */
/* US Government Users Restricted Rights - Use, duplication or               */
/* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         */
/*                                                                           */
/*                                                                           */
/* Author:  Kendrick Ren                                                     */
/* Purpose: Sample program to generate IBM Security Server (RACF) passticket */
/*          and connection string for use by Db2 CLP on Unix System Services.*/
/* Input:   The following input parameters must be passed in the same order: */
/*          1 - userid used to connect to Db2 server                         */
/*          2 - application name                                             */
/*          3 - server name of Db2 database system                           */
/*          4 - port number assigned to Db2 database system                  */
/*          5 - Db2 location name defined during installation                */
/* Output:  SQL file with connection string.                                 */
/*                                                                           */
/*                                                                           */
/*****************************************************************************/

import com.ibm.eserver.zos.racf.IRRPassTicket;
import com.ibm.eserver.zos.racf.IRRPassTicketGenerationException;
import java.io.File;

class genticket {
    static void main(String[] args) {
        int argcount = args.length/5;
        def ticketGenerator = new IRRPassTicket();
        for (int i = 0; i < argcount; i++) {
            try {
                def passticket = ticketGenerator.generate(args[i*5],
                                                          args[i*5+1]);
                println "Passticket generated for IBM Security Server (RACF)."
                String connString = "connect to " + args[i*5+2] + ":" +
                    args[i*5+3] + "/" + args[i*5+4] + " user " + args[i*5] +
                    " using " + passticket + ";" +
                    System.getProperty("line.separator");
                String fname = "./clp" + Integer.toString(i) + ".sql";
                File file = new File(fname);
                file.write connString;
            }
            catch (IRRPassTicketGenerationException e) {
                e.printStackTrace();
            }
        }
        System.exit(0);
    }
}
