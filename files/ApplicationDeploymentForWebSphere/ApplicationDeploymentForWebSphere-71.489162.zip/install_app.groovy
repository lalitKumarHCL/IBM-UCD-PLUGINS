/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import java.io.*;
import java.util.*;

final def isWindows = (System.getProperty('os.name') =~ /(?i)windows/).find()
out = System.out;
def wsadmin = isWindows ? "wsadmin.bat" : "wsadmin.sh"

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
final def inputPropsStream = null;
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

def cell = props['cell']
def server = props['server']
def commandPath = (props['commandPath']!=null?props['commandPath']:"");
def node = props['node']
def user = props['user']
def password = (props['password'] != null && props['password'] != "")? props['password'] : props['passScript']
def cluster = props['cluster']

def connType = props['connType']
def host = props['host'];
def port = props['port'];
def additionalArgs = props['additionalArgs'];
def appName = props['appName']
def context = props['context']
def location = props['location']
def path = props['path']
def argString = props['argString']
def deleteTempFileOnFailure = Boolean.valueOf(props['deleteTempFileOnFailure'])

File tempFile = File.createTempFile("temp", ".py", new File("."))
if (deleteTempFileOnFailure) {
    tempFile.deleteOnExit();
}
BufferedWriter temp = new BufferedWriter(new FileWriter(tempFile))
def cellarg = cell ? " -cell " + cell : ""
def installdir = path ? " -installed.ear.destination " + path : ""



def invokeArgs ;
if (server == null || server.startsWith('${p:') || server.trim() == "") {
    invokeArgs = '[ -cluster ' + cluster;
    if (context) {
       invokeArgs = invokeArgs + ' -contextroot ' + context;
    }
    invokeArgs = invokeArgs + ' -appname \"' + appName + '\"' + installdir + ' ' + (argString ? argString :'-usedefaultbindings') + ']';
}
else {
    invokeArgs = '[ -server ' + server + ' -node ' + node + cellarg
    if (context) {
        invokeArgs = invokeArgs + ' -contextroot ' + context; 
    }
    invokeArgs = invokeArgs + ' -appname \"' + appName + '\"' + installdir + ' ' + (argString ? argString :'-usedefaultbindings') + ']'
}


def invoke = "AdminApp.install('" + location + "', '" + invokeArgs + "')"
temp.write(invoke, 0, invoke.length())
System.out.println invoke
temp.write("\nAdminConfig.save()", 0, 19)
System.out.println "AdminConfig.save()"
temp.close()

def commandArgs = [commandPath + wsadmin, "-lang", "jython"];
commandArgs << "-conntype"
commandArgs << connType.trim();

if (host) {
    commandArgs << "-host";
    commandArgs << host;
}

if (port) {
    commandArgs << "-port";
    commandArgs << port;
}

if (user) {
    commandArgs << "-user"
    commandArgs <<  user
    commandArgs << "-password"
    commandArgs << password
}

commandArgs << "-f";
commandArgs << tempFile.getName();

if (additionalArgs) {
    additionalArgs.split('\n').each { arg ->
        commandArgs << arg;
    }
}

println commandArgs.join(' ');
def procBuilder = new ProcessBuilder(commandArgs);

if (isWindows) {
    def envMap = procBuilder.environment();
    envMap.put("PROFILE_CONFIG_ACTION","true");
}

def statusProc = procBuilder.start();
def outPrint = new PrintStream(out, true);
statusProc.waitForProcessOutput(outPrint, outPrint);
def exitVal =statusProc.exitValue() 
if (exitVal == 0){ 
    tempFile.delete();
}
System.exit(exitVal);
