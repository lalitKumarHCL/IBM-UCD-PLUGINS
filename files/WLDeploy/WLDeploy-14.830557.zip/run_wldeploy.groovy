

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
final def inputPropsStream = null;
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}
final def url = props['url'];
final def jmxUrl = props['jmxUrl'];
final def user = props['user'];
final def pass = props['password'];
final def configfile = props['configFile'];
final def keyfile = props['keyFile'];
def targets = props['targets'];
final def path = props['path'];
final def appName = props['appName'];
final def source = props['source'];
final def operation = props['operation'];
final def retiretimeout = props['retiretimout'];
final def plan = props['plan'];
final def planver = props['planver'];
final def altappdd = props['altappdd'];
final def altwlsappdd = props['altwlsappdd'];
final def appver = props['appver'];
final def id = props['id'];
final def remote = props['remote'];
def additionalProps = props['additionalProps'];
if (additionalProps != null && additionalProps != "") {
    additionalProps = additionalProps.split('\n');
}

def ant = new AntBuilder();
def propsMap = [:];

propsMap.put('verbose', "true");
propsMap.put('debug', "true");

propsMap.put('action', operation);
propsMap.put('name', appName);
propsMap.put('targets', targets);
propsMap.put('adminurl', url);

if (user) {
    propsMap.put('user', user);
    propsMap.put('password', pass);
}
else {
    propsMap.put('userconfigfile', configfile);
    propsMap.put('userkeyfile', keyfile);
}
if (source != null && source != "") {
    propsMap.put('source', source);
}
if (retiretimeout != null && retiretimout != "") {
    propsMap.put('retiretimout', retiretimeout);
}
if (plan != null && plan != "") {
    propsMap.put('plan', plan);
}
if (planver != null && planver != "") {
    propsMap.put('planversion', planver);
}
if (appver != null && appver != "") {
    propsMap.put('appversion', appver);
}
if (altappdd != null && altappdd != "") {
    propsMap.put('altappdd', altappdd);
}
if (altwlsappdd != null && altwlsappdd != "") {
    propsMap.put('altwlsappdd', altwlsappdd);
}
if (id != null && id != "") {
    propsMap.put('id', id);
}

if (remote != null && remote != "" && !remote.equals("false")) {
    propsMap.put('remote', 'true');
}
additionalProps.each { additionalProp ->
    def splitUp = additionalProp.split('=', 2);
    if (splitUp.length == 2) {
        propsMap.put(splitUp[0], splitUp[1]);
    }
}

System.out.println(propsMap);
ant.sequential {
    taskdef name:"wldeploy", classname:"weblogic.ant.taskdefs.management.WLDeploy", classpath:"${path}"
    wldeploy(propsMap)
}
