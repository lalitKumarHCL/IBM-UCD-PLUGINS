#!/usr/bin/env groovy
/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

import org.apache.log4j.BasicConfigurator
import org.apache.log4j.Level
import org.apache.log4j.Logger

import com.urbancode.air.AirPluginTool
import com.urbancode.air.integration.*
import com.urbancode.air.XTrustProvider;
import com.urbancode.anthill3.integration.*;

final AirPluginTool airPluginTool = new AirPluginTool(this.args[0], this.args[1])
final Properties props = airPluginTool.getStepProperties()

XTrustProvider.install();

BasicConfigurator.resetConfiguration()
BasicConfigurator.configure()
Logger.getRootLogger().setLevel(Level.ERROR)

final def workDir = new File('.').canonicalFile

final def anthillUrl      = props['anthillUrl']
final def proxyHost = props['proxyHost']
final def proxyPort = props['proxyPort']
final def proxyUserName = props['proxyUserName']
final def proxyUserPassword = props['proxyUserPassword']
final def anthillUser     = props['anthillUser']
final def anthillPassword = props['anthillPassword']
final def projectName     = props['projectName']
final def workflowName    = props['workflowName']
final def envName         = props['envName']
final def buildLifeId     = props['buildLifeId']
final def properties      = props['properties']

if (!proxyPort.equals("") && !proxyHost.equals("")) {
    try{
        Integer.parseInt(proxyPort);
        System.setProperty("http.proxyHost", proxyHost);
        System.setProperty("http.proxyPort", proxyPort);
        println("Connection using a proxy : "+proxyHost+" / "+proxyPort);

        if (!proxyUserName.equals("") && !proxyUserPassword.equals("")) {
            //Authentication required
            println("Proxy Authentication required with user "+proxyUserName);
            System.setProperty("http.proxyUserName", proxyUserName);
            System.setProperty("http.proxyUser", proxyUserName);
            System.setProperty("http.proxyPassword", proxyUserPassword);
        }
    }
    catch (NumberFormatException ex) {
        println "Warning: The proxy port must be a number !";
        println "Error: "+ex.toString();
    }
}

// parse the additional fields into a Properties object
def workflowProps = new Properties()
if (properties) {
    try {
        workflowProps.load(new ByteArrayInputStream(properties.getBytes()))
    }
    catch (Exception e) {
        throw new Exception("Workflow properties formatted incorrectly: " + e.getMessage())
    }
}
def propertyFacadeArray = new PropertyFacade[workflowProps.size()]
def propertyIndex = 0
workflowProps.each() { workflowProp ->
    propertyFacadeArray[propertyIndex++] = new PropertyFacade(workflowProp.key, workflowProp.value)
}

println "Connecting to ${anthillUrl}"

def locator = new DashboardServiceLocator()

def dashboard = locator.getDashboard(new URL("${anthillUrl}/services/Dashboard"))

def requestFacade = null
if (buildLifeId) {
    println "Running secondary workflow '${workflowName}' on build life ${buildLifeId} in environment '${envName}'."
    requestFacade = dashboard.runWorkflowWithPropertiesByName(
        anthillUser, anthillPassword, buildLifeId, workflowName, envName, propertyFacadeArray)
}
else {
    println "Running build workflow '${workflowName}' for project '${projectName}'."
    requestFacade = dashboard.buildProjectWithPropertiesByName(
        anthillUser, anthillPassword, projectName, workflowName, true, propertyFacadeArray)
}

println "Created request ${requestFacade.id}"
